"""Frozen analytic variable construction."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .config import StudyConfig


def _numeric(frame: pd.DataFrame, column: str) -> pd.Series:
    return pd.to_numeric(frame[column], errors="coerce")


def _add_spline_basis(frame: pd.DataFrame, column: str, knots: tuple[int, ...]) -> None:
    values = _numeric(frame, column)
    for knot in knots:
        frame[f"{column}_spline_{knot}"] = (values - knot).clip(lower=0)


def add_game_state_features(df: pd.DataFrame, config: StudyConfig) -> pd.DataFrame:
    result = df.copy()
    home_margin = _numeric(result, "pre_score_home") - _numeric(result, "pre_score_away")
    result["home_pre_shot_margin"] = home_margin
    result["offense_signed_pre_shot_margin"] = np.where(
        _numeric(result, "is_home_offense").eq(1), home_margin, -home_margin
    )
    result["absolute_pre_shot_margin"] = home_margin.abs()
    result["remaining_period_seconds"] = _numeric(result, "clock_seconds")
    result["critical"] = (
        _numeric(result, "period").eq(config.critical_period)
        & result["remaining_period_seconds"].le(config.critical_clock_seconds_max)
        & result["absolute_pre_shot_margin"].le(config.critical_abs_margin_max)
    ).astype("Int8")

    previous_home_margin = _numeric(result, "previous_personal_pre_score_home") - _numeric(
        result, "previous_personal_pre_score_away"
    )
    result["previous_personal_home_margin"] = previous_home_margin
    result["previous_personal_absolute_margin"] = previous_home_margin.abs()
    has_previous = _numeric(result, "previous_personal_action_number").notna()
    result["previous_personal_critical"] = (
        has_previous
        & _numeric(result, "period").eq(config.critical_period)
        & _numeric(result, "previous_personal_clock_seconds").le(config.critical_clock_seconds_max)
        & result["previous_personal_absolute_margin"].le(config.critical_abs_margin_max)
    ).astype("Int8")
    result["stable_critical_status"] = (
        result["critical"].eq(result["previous_personal_critical"]) & has_previous
    )

    if "previous_personal_miss" not in result:
        previous_made = _numeric(result, "previous_personal_shot_made")
        result["previous_personal_miss"] = (1.0 - previous_made).where(previous_made.notna())
    result["post_miss_x_critical"] = _numeric(result, "previous_personal_miss") * _numeric(
        result, "critical"
    )

    period = _numeric(result, "period")
    remaining_game_seconds = (4 - period) * 720.0 + result["remaining_period_seconds"]
    result["remaining_game_seconds"] = remaining_game_seconds.where(period.between(1, 4))
    result["continuous_criticality"] = (
        np.exp(-result["remaining_game_seconds"] / config.continuous_criticality_clock_scale)
        * np.exp(-result["absolute_pre_shot_margin"] / config.continuous_criticality_margin_scale)
    ).where(period.between(1, 4))
    result["post_miss_x_continuous_criticality"] = _numeric(
        result, "previous_personal_miss"
    ) * result["continuous_criticality"]

    result["heave_proxy"] = (
        period.isin(config.heave_periods)
        & result["remaining_period_seconds"].le(config.heave_clock_seconds_max)
        & _numeric(result, "shot_distance_feet").ge(config.heave_distance_feet_min)
    )
    if "same_stint" not in result:
        result["same_stint"] = pd.Series(pd.NA, index=result.index, dtype="boolean")
    if "no_timeout_between_personal_shots" not in result:
        result["no_timeout_between_personal_shots"] = pd.Series(
            pd.NA, index=result.index, dtype="boolean"
        )

    _add_spline_basis(
        result, "remaining_period_seconds", config.remaining_period_seconds_knots
    )
    _add_spline_basis(result, "absolute_pre_shot_margin", config.absolute_margin_knots)
    _add_spline_basis(
        result, "personal_interval_seconds", config.personal_interval_seconds_knots
    )
    return result

