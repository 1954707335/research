"""Post-confirmation supplementary analyses for the major manuscript revision.

This module is deliberately outside the original analysis freeze.  It reads
the sealed configuration and validated inputs but never overwrites the two
confirmation artifacts.  Every fitted model is labelled post-confirmation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np
import pandas as pd

from .analyses import _build_enriched_season
from .config import StudyConfig, load_config
from .estimators import absorb_fixed_effects, cluster_covariance, two_way_cluster_covariance
from .pipeline import assert_confirmation_allowed, primary_predictors, validate_raw_manifest
from .samples import build_main_sample


ANALYSIS_STATUS = "post_confirmation_supplementary"
REQUIRED_MODEL_IDS = {
    "sealed_refit_covariance",
    "critical_2min_margin3",
    "critical_5min_margin3",
    "critical_5min_margin8",
    "continuous_criticality",
    "win_probability_leverage",
    "interval_le_120",
    "same_stint",
    "no_timeout",
    "timeout_heterogeneity",
    "three_point_secondary",
    "period_fixed_effects",
    "fourth_quarter_only",
    "nonlinear_previous_distance",
}


@dataclass(frozen=True, slots=True)
class CovarianceModel:
    outcome: str
    predictors: tuple[str, ...]
    estimates: np.ndarray
    covariance: np.ndarray
    standard_errors: np.ndarray
    p_values: np.ndarray
    n_obs: int
    cluster_counts: dict[str, int]
    fixed_effect_counts: dict[str, int]
    within_r_squared: float
    converged: bool
    absorption_iterations: int
    sample_hash: str

    def to_dict(self) -> dict[str, object]:
        return {
            "outcome": self.outcome,
            "predictors": list(self.predictors),
            "estimates": dict(zip(self.predictors, map(float, self.estimates))),
            "covariance": self.covariance.tolist(),
            "standard_errors": dict(zip(self.predictors, map(float, self.standard_errors))),
            "p_values_normal": dict(zip(self.predictors, map(float, self.p_values))),
            "n_obs": self.n_obs,
            "cluster_counts": self.cluster_counts,
            "fixed_effect_counts": self.fixed_effect_counts,
            "within_r_squared": self.within_r_squared,
            "converged": self.converged,
            "absorption_iterations": self.absorption_iterations,
            "sample_hash": self.sample_hash,
        }


def linear_contrast(
    names: Sequence[str],
    estimates: np.ndarray,
    covariance: np.ndarray,
    weights: Mapping[str, float],
) -> dict[str, float]:
    index = {name: i for i, name in enumerate(names)}
    vector = np.zeros(len(names), dtype=float)
    for name, value in weights.items():
        if name not in index:
            raise KeyError(f"contrast term not estimated: {name}")
        vector[index[name]] = float(value)
    estimate = float(vector @ np.asarray(estimates, dtype=float))
    variance = float(vector @ np.asarray(covariance, dtype=float) @ vector)
    standard_error = math.sqrt(max(variance, 0.0))
    z_value = estimate / standard_error if standard_error > 0 else float("inf")
    return {
        "estimate": estimate,
        "standard_error": standard_error,
        "ci_low": estimate - 1.96 * standard_error,
        "ci_high": estimate + 1.96 * standard_error,
        "p_normal": math.erfc(abs(z_value) / math.sqrt(2)),
    }


def timeout_design(data: pd.DataFrame) -> pd.DataFrame:
    result = data.copy()
    miss = pd.to_numeric(result["previous_personal_miss"], errors="coerce").astype(float)
    critical = pd.to_numeric(result["critical"], errors="coerce").astype(float)
    timeout = (~result["no_timeout_between_personal_shots"].astype("boolean")).astype(float)
    result["intervening_timeout"] = timeout
    result["miss_x_timeout"] = miss * timeout
    result["critical_x_timeout"] = critical * timeout
    result["miss_x_critical_x_timeout"] = miss * critical * timeout
    return result


def shot_zone_indicators(data: pd.DataFrame) -> pd.DataFrame:
    result = data.copy()
    distance = pd.to_numeric(result["shot_distance_feet"], errors="coerce")
    three = pd.to_numeric(result["is_three_point_attempt"], errors="coerce").eq(1)
    two = ~three
    result["zone_at_rim"] = (two & distance.le(4)).astype(float)
    result["zone_short_two"] = (two & distance.gt(4) & distance.lt(14)).astype(float)
    result["zone_long_two"] = (two & distance.ge(14)).astype(float)
    result["zone_three"] = three.astype(float)
    return result


def _win_probability_basis(margin: np.ndarray, seconds: np.ndarray) -> np.ndarray:
    margin = np.asarray(margin, dtype=float)
    seconds = np.asarray(seconds, dtype=float)
    logged_time = np.log1p(np.clip(seconds, 0.0, None))
    return np.column_stack(
        [
            np.ones(len(margin)),
            margin,
            margin**3 / 100.0,
            logged_time,
            logged_time**2,
            margin * logged_time,
            margin / np.sqrt(np.clip(seconds, 0.0, None) + 1.0),
        ]
    )


def _logistic(values: np.ndarray) -> np.ndarray:
    values = np.clip(np.asarray(values, dtype=float), -35.0, 35.0)
    return 1.0 / (1.0 + np.exp(-values))


def probability_diagnostics(
    outcome: Sequence[float], prediction: Sequence[float]
) -> dict[str, float | int]:
    """Return proper-score and logistic-calibration diagnostics for held-out rows."""
    y = np.asarray(outcome, dtype=float)
    p = np.asarray(prediction, dtype=float)
    valid = np.isfinite(y) & np.isfinite(p)
    y = y[valid]
    p = np.clip(p[valid], 1e-8, 1.0 - 1e-8)
    if len(y) == 0:
        raise ValueError("probability diagnostics require at least one valid row")
    logits = np.log(p / (1.0 - p))
    calibration = _fit_logistic_irls(
        np.column_stack([np.ones(len(y)), logits]),
        y,
        ridge=1e-3,
        max_iter=200,
        tol=1e-8,
    )
    return {
        "rows": int(len(y)),
        "observed_rate": float(np.mean(y)),
        "mean_prediction": float(np.mean(p)),
        "brier_score": float(np.mean((p - y) ** 2)),
        "log_loss": float(-np.mean(y * np.log(p) + (1.0 - y) * np.log(1.0 - p))),
        "calibration_intercept": float(calibration[0]),
        "calibration_slope": float(calibration[1]),
    }


def holm_adjust(p_values: Sequence[float]) -> list[float]:
    """Holm step-down family-wise-error adjustment, returned in original order."""
    values = np.asarray(p_values, dtype=float)
    if np.any((values < 0.0) | (values > 1.0) | ~np.isfinite(values)):
        raise ValueError("p-values must be finite and between zero and one")
    order = np.argsort(values)
    ranked = values[order]
    adjusted_ranked = np.maximum.accumulate(
        np.array([(len(values) - i) * value for i, value in enumerate(ranked)])
    )
    adjusted = np.empty(len(values), dtype=float)
    adjusted[order] = np.minimum(adjusted_ranked, 1.0)
    return adjusted.tolist()


def win_probability_leverage(data: pd.DataFrame, beta: np.ndarray) -> pd.Series:
    margin = pd.to_numeric(data["home_pre_shot_margin"], errors="coerce").to_numpy(float)
    seconds = pd.to_numeric(data["remaining_game_seconds"], errors="coerce").to_numpy(float)
    home_offense = pd.to_numeric(data["is_home_offense"], errors="coerce").to_numpy(float)
    if len(beta) != _win_probability_basis(margin[:1], seconds[:1]).shape[1]:
        raise ValueError("win-probability coefficient vector has the wrong length")
    score_shift = np.where(home_offense == 1.0, 2.0, -2.0)
    baseline = _logistic(_win_probability_basis(margin, seconds) @ beta)
    made = _logistic(_win_probability_basis(margin + score_shift, seconds) @ beta)
    return pd.Series(np.abs(made - baseline), index=data.index, dtype=float)


def fit_hdfe_covariance(
    data: pd.DataFrame,
    outcome: str,
    predictors: Sequence[str],
    fe_groups: Sequence[str],
    cluster_groups: Sequence[str] = ("game_id", "player_id"),
    tol: float = 1e-9,
    max_iter: int = 10_000,
) -> CovarianceModel:
    required = list(dict.fromkeys([outcome, *predictors, *fe_groups, *cluster_groups]))
    model_data = data.loc[:, required].replace([np.inf, -np.inf], np.nan).dropna().copy()
    absorbed = absorb_fixed_effects(
        model_data[outcome],
        model_data.loc[:, list(predictors)],
        [model_data[group] for group in fe_groups],
        tol=tol,
        max_iter=max_iter,
    )
    scale = np.nanstd(absorbed.X, axis=0)
    keep = scale > max(tol * 10, 1e-12)
    names = tuple(name for name, retained in zip(absorbed.predictor_names, keep) if retained)
    design = absorbed.X[:, keep]
    beta = np.linalg.lstsq(design, absorbed.y, rcond=None)[0]
    residuals = absorbed.y - design @ beta
    total_within = float(absorbed.y @ absorbed.y)
    within_r_squared = (
        1.0 - float(residuals @ residuals) / total_within
        if total_within > 0
        else float("nan")
    )
    if len(cluster_groups) == 1:
        covariance = cluster_covariance(
            design, residuals, model_data[cluster_groups[0]].to_numpy()
        )
    elif len(cluster_groups) == 2:
        covariance = two_way_cluster_covariance(
            design,
            residuals,
            model_data[cluster_groups[0]].to_numpy(),
            model_data[cluster_groups[1]].to_numpy(),
        )
    else:
        raise ValueError("one or two cluster dimensions are supported")
    standard_errors = np.sqrt(np.clip(np.diag(covariance), 0.0, None))
    p_values = np.array(
        [
            math.erfc(abs(value / se) / math.sqrt(2)) if se > 0 else 1.0
            for value, se in zip(beta, standard_errors)
        ]
    )
    hashes = pd.util.hash_pandas_object(model_data, index=False).to_numpy(dtype=np.uint64)
    return CovarianceModel(
        outcome=outcome,
        predictors=names,
        estimates=beta,
        covariance=covariance,
        standard_errors=standard_errors,
        p_values=p_values,
        n_obs=len(model_data),
        cluster_counts={group: int(model_data[group].nunique()) for group in cluster_groups},
        fixed_effect_counts={group: int(model_data[group].nunique()) for group in fe_groups},
        within_r_squared=within_r_squared,
        converged=absorbed.converged,
        absorption_iterations=absorbed.iterations,
        sample_hash=hashlib.sha256(hashes.tobytes()).hexdigest(),
    )


def validate_supplement_payload(payload: Mapping[str, object]) -> None:
    if payload.get("analysis_status") != ANALYSIS_STATUS:
        raise ValueError("supplement must be labelled post-confirmation")
    models = payload.get("models")
    if not isinstance(models, Mapping):
        raise ValueError("supplement models must be a mapping")
    missing = REQUIRED_MODEL_IDS - set(models)
    if missing:
        raise ValueError(f"supplement is missing required models: {sorted(missing)}")
    parity = payload.get("sealed_parity")
    if not isinstance(parity, Mapping):
        raise ValueError("sealed parity record is required")
    tolerance = float(parity.get("tolerance", 0.0))
    if abs(float(parity.get("h1_difference", float("inf")))) > tolerance:
        raise ValueError("refitted H1 does not match sealed confirmation")
    if abs(float(parity.get("h2_difference", float("inf")))) > tolerance:
        raise ValueError("refitted H2 does not match sealed confirmation")
    for required in (
        "analysis_flow",
        "win_probability_definition",
        "software_versions",
        "no_timeout_pooled_parity",
    ):
        if not isinstance(payload.get(required), Mapping):
            raise ValueError(f"supplement requires a {required} audit record")
    no_timeout = payload["no_timeout_pooled_parity"]
    no_timeout_tolerance = float(no_timeout.get("tolerance", 0.0))
    if abs(float(no_timeout.get("estimate_difference", float("inf")))) > no_timeout_tolerance:
        raise ValueError("pooled no-timeout estimate does not match the original result")
    if int(no_timeout.get("reference_n_obs", -1)) != int(no_timeout.get("refit_n_obs", -2)):
        raise ValueError("pooled no-timeout sample size does not match the original result")


def _fit_logistic_irls(
    design: np.ndarray,
    outcome: np.ndarray,
    ridge: float = 1e-6,
    max_iter: int = 100,
    tol: float = 1e-10,
) -> np.ndarray:
    x = np.asarray(design, dtype=float)
    y = np.asarray(outcome, dtype=float)
    beta = np.zeros(x.shape[1], dtype=float)
    penalty = np.eye(x.shape[1]) * ridge
    penalty[0, 0] = 0.0
    for _ in range(max_iter):
        fitted = _logistic(x @ beta)
        weights = np.clip(fitted * (1.0 - fitted), 1e-6, None)
        working = x @ beta + (y - fitted) / weights
        updated = np.linalg.solve(x.T @ (weights[:, None] * x) + penalty, x.T @ (weights * working))
        if float(np.max(np.abs(updated - beta))) < tol:
            return updated
        beta = updated
    raise RuntimeError("win-probability IRLS did not converge")


def _final_home_win(raw_dir: Path, seasons: Sequence[int]) -> pd.Series:
    records = []
    for season in seasons:
        pbp = pd.read_csv(
            raw_dir / f"nbastatsv3_{season}.csv",
            usecols=["gameId", "scoreHome", "scoreAway"],
        )
        scores = pbp.assign(
            scoreHome=pd.to_numeric(pbp["scoreHome"], errors="coerce"),
            scoreAway=pd.to_numeric(pbp["scoreAway"], errors="coerce"),
        ).groupby("gameId", sort=False)[["scoreHome", "scoreAway"]].max()
        scores["home_win"] = scores["scoreHome"].gt(scores["scoreAway"]).astype(float)
        scores["season"] = int(season)
        records.append(scores.reset_index()[["gameId", "home_win", "season"]])
    final = pd.concat(records, ignore_index=True)
    return final.set_index(["season", "gameId"])["home_win"]


def _add_crossfit_leverage(
    main: pd.DataFrame, raw_dir: Path, seasons: Sequence[int]
) -> tuple[pd.DataFrame, list[dict[str, object]], dict[str, object]]:
    result = main.copy()
    final = _final_home_win(raw_dir, seasons)
    keys = pd.MultiIndex.from_arrays(
        [result["season"].astype(int), pd.to_numeric(result["game_id"]).astype(int)]
    )
    result["home_win"] = final.reindex(keys).to_numpy()
    result["win_probability_leverage"] = np.nan
    diagnostics = []
    all_holdout_outcomes: list[np.ndarray] = []
    all_holdout_predictions: list[np.ndarray] = []
    for target in seasons:
        train_mask = result["season"].ne(target) & result["remaining_game_seconds"].notna()
        test_mask = result["season"].eq(target) & result["remaining_game_seconds"].notna()
        train = result.loc[train_mask]
        design = _win_probability_basis(
            train["home_pre_shot_margin"].to_numpy(float),
            train["remaining_game_seconds"].to_numpy(float),
        )
        beta = _fit_logistic_irls(design, train["home_win"].to_numpy(float))
        test = result.loc[test_mask]
        test_design = _win_probability_basis(
            test["home_pre_shot_margin"].to_numpy(float),
            test["remaining_game_seconds"].to_numpy(float),
        )
        holdout_predictions = _logistic(test_design @ beta)
        holdout_outcomes = test["home_win"].to_numpy(float)
        result.loc[test_mask, "win_probability_leverage"] = win_probability_leverage(test, beta)
        holdout_diagnostics = probability_diagnostics(holdout_outcomes, holdout_predictions)
        all_holdout_outcomes.append(holdout_outcomes)
        all_holdout_predictions.append(holdout_predictions)
        diagnostics.append(
            {
                "target_season": int(target),
                "training_seasons": [int(s) for s in seasons if s != target],
                "training_rows": int(train_mask.sum()),
                "test_rows": int(test_mask.sum()),
                "validation_scope": "held-out target-season shot states",
                **holdout_diagnostics,
                "coefficients": beta.tolist(),
            }
        )
    result["post_miss_x_win_probability_leverage"] = (
        result["previous_personal_miss"] * result["win_probability_leverage"]
    )
    pooled = probability_diagnostics(
        np.concatenate(all_holdout_outcomes), np.concatenate(all_holdout_predictions)
    )
    metadata = {
        "outcome": "final home-team win",
        "prediction_target": "pre-shot home-win probability",
        "basis_terms": [
            "intercept",
            "home_pre_shot_margin",
            "home_pre_shot_margin_cubed_div_100",
            "log1p_remaining_regulation_seconds",
            "log1p_remaining_regulation_seconds_squared",
            "margin_x_log1p_remaining_regulation_seconds",
            "margin_div_sqrt_remaining_regulation_seconds_plus_1",
        ],
        "cross_fitting": "each target season predicted from the other five confirmation seasons",
        "two_point_counterfactual": (
            "+2 home-margin points when the shooting team is home; "
            "-2 home-margin points when the shooting team is away"
        ),
        "leverage_definition": (
            "absolute difference between predicted home-win probability after the "
            "two-point counterfactual and baseline pre-shot probability"
        ),
        "validation_scope": "held-out target-season shot states only",
        "pooled_holdout_diagnostics": pooled,
    }
    return result, diagnostics, metadata


def _base_controls(config: StudyConfig) -> list[str]:
    return primary_predictors(config)[3:]


def _model_record(
    model_id: str,
    model: CovarianceModel,
    target_terms: Sequence[str],
    *,
    sample: str,
    moderator_summary: Mapping[str, float] | None = None,
) -> dict[str, object]:
    index = {name: i for i, name in enumerate(model.predictors)}
    targets = {}
    for term in target_terms:
        i = index[term]
        estimate = float(model.estimates[i])
        se = float(model.standard_errors[i])
        targets[term] = {
            "estimate": estimate,
            "standard_error": se,
            "ci_low": estimate - 1.96 * se,
            "ci_high": estimate + 1.96 * se,
            "p_normal": float(model.p_values[i]),
        }
    return {
        "model_id": model_id,
        "analysis_status": ANALYSIS_STATUS,
        "sample": sample,
        "target_terms": list(target_terms),
        "targets": targets,
        "moderator_summary": dict(moderator_summary or {}),
        "model": model.to_dict(),
        "n_obs": model.n_obs,
    }


def _fit_primary(
    data: pd.DataFrame,
    config: StudyConfig,
    *,
    outcome: str = "shot_distance_feet",
    fe_groups: Sequence[str] | None = None,
    predictors: Sequence[str] | None = None,
) -> CovarianceModel:
    return fit_hdfe_covariance(
        data,
        outcome,
        list(predictors or primary_predictors(config)),
        list(fe_groups or config.fixed_effects),
        list(config.cluster_groups),
    )


def _critical_indicator(data: pd.DataFrame, seconds: float, margin: float) -> pd.Series:
    return (
        data["period"].eq(4)
        & data["remaining_period_seconds"].le(seconds)
        & data["absolute_pre_shot_margin"].le(margin)
    ).astype(float)


def _target_rows(records: Mapping[str, dict[str, object]]) -> pd.DataFrame:
    rows = []
    for model_id, record in records.items():
        for term, target in record.get("targets", {}).items():
            rows.append(
                {
                    "model_id": model_id,
                    "analysis_status": record["analysis_status"],
                    "sample": record["sample"],
                    "outcome": record["model"]["outcome"],
                    "term": term,
                    **target,
                    "n_obs": record["n_obs"],
                }
            )
    return pd.DataFrame.from_records(rows)


def moderator_effect_scale(summary: Mapping[str, float], *, binary: bool) -> float:
    if binary:
        return 1.0
    return float(summary.get("q75", 1.0)) - float(summary.get("q25", 0.0))


def moderator_high_low_scale(summary: Mapping[str, float], *, binary: bool) -> float:
    if binary:
        return 1.0
    return float(summary.get("q95", 1.0)) - float(summary.get("q05", 0.0))


def moderator_change_spec(
    summary: Mapping[str, float], *, binary: bool
) -> dict[str, float | str]:
    if binary:
        low, high, label = 0.0, 1.0, "binary 0→1"
    else:
        low = float(summary["q05"])
        high = float(summary["q95"])
        label = "continuous P5→P95"
    return {
        "effect_scale": label,
        "scale_low": low,
        "scale_high": high,
        "scale_change": high - low,
    }


def _software_versions() -> dict[str, str]:
    return {
        "python": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
    }


def _add_holm_columns(
    rows: pd.DataFrame,
    families: Mapping[str, Sequence[tuple[str, str]]],
) -> pd.DataFrame:
    """Attach multiplicity family and Holm p-value to selected model-term rows."""
    result = rows.copy()
    result["multiplicity_family"] = "focused_or_descriptive"
    result["adjustment_method"] = "none"
    result["p_raw"] = pd.to_numeric(result["p_normal"], errors="coerce")
    result["p_holm"] = np.nan
    for family, keys in families.items():
        indices = []
        for model_id, term in keys:
            match = result.index[
                result["model_id"].eq(model_id) & result["term"].eq(term)
            ].tolist()
            if len(match) != 1:
                raise ValueError(f"expected one multiplicity row for {(model_id, term)}")
            indices.extend(match)
        result.loc[indices, "multiplicity_family"] = family
        result.loc[indices, "adjustment_method"] = "Holm"
        result.loc[indices, "p_holm"] = holm_adjust(result.loc[indices, "p_raw"].tolist())
    return result


def _no_timeout_decomposition(
    by_season: Mapping[int, pd.DataFrame],
    config: StudyConfig,
    confirmation_seasons: Sequence[int],
    pilot_seasons: Sequence[int],
) -> tuple[list[dict[str, object]], CovarianceModel, CovarianceModel]:
    rows: list[dict[str, object]] = []

    def fit(label: str, seasons: Sequence[int]) -> CovarianceModel:
        data = pd.concat([by_season[int(season)] for season in seasons], ignore_index=True)
        restricted = data.loc[data["no_timeout_between_personal_shots"].fillna(False)]
        model = _fit_primary(restricted, config)
        index = {name: i for i, name in enumerate(model.predictors)}
        i = index["post_miss_x_critical"]
        estimate = float(model.estimates[i])
        se = float(model.standard_errors[i])
        rows.append(
            {
                "analysis_status": ANALYSIS_STATUS,
                "sample": label,
                "seasons": ",".join(map(str, seasons)),
                "estimate": estimate,
                "standard_error": se,
                "ci_low": estimate - 1.96 * se,
                "ci_high": estimate + 1.96 * se,
                "p_raw": float(model.p_values[i]),
                "n_obs": model.n_obs,
                "sample_hash": model.sample_hash,
            }
        )
        return model

    for season in (*confirmation_seasons, *pilot_seasons):
        fit(f"season {season}-{str(season + 1)[-2:]}", [season])
    fit("six confirmation seasons", confirmation_seasons)
    fit("two pilot seasons", pilot_seasons)
    pooled = fit("pooled eight seasons", [*confirmation_seasons, *pilot_seasons])
    pooled_data = pd.concat(
        [by_season[int(season)] for season in (*confirmation_seasons, *pilot_seasons)],
        ignore_index=True,
    )
    pooled_data = pooled_data.loc[
        pooled_data["no_timeout_between_personal_shots"].fillna(False)
    ].copy()
    pilot = pooled_data["season"].isin(pilot_seasons).astype(float)
    pooled_data["post_miss_x_pilot"] = pooled_data["previous_personal_miss"] * pilot
    pooled_data["critical_x_pilot"] = pooled_data["critical"] * pilot
    pooled_data["post_miss_x_critical_x_pilot"] = (
        pooled_data["previous_personal_miss"] * pooled_data["critical"] * pilot
    )
    difference = _fit_primary(
        pooled_data,
        config,
        predictors=[
            "previous_personal_miss",
            "critical",
            "post_miss_x_critical",
            "post_miss_x_pilot",
            "critical_x_pilot",
            "post_miss_x_critical_x_pilot",
            *_base_controls(config),
        ],
    )
    i = {name: index for index, name in enumerate(difference.predictors)}[
        "post_miss_x_critical_x_pilot"
    ]
    estimate = float(difference.estimates[i])
    se = float(difference.standard_errors[i])
    rows.append(
        {
            "analysis_status": ANALYSIS_STATUS,
            "sample": "pilot minus confirmation difference",
            "seasons": ",".join(map(str, (*confirmation_seasons, *pilot_seasons))),
            "estimate": estimate,
            "standard_error": se,
            "ci_low": estimate - 1.96 * se,
            "ci_high": estimate + 1.96 * se,
            "p_raw": float(difference.p_values[i]),
            "n_obs": difference.n_obs,
            "sample_hash": difference.sample_hash,
        }
    )
    return rows, pooled, difference


def run_post_confirmation(
    study_root: Path, raw_dir: Path, cache_dir: Path
) -> dict[str, object]:
    study_root = Path(study_root).resolve()
    raw_dir = Path(raw_dir).resolve()
    cache_dir = Path(cache_dir).resolve()
    assert_confirmation_allowed(study_root)
    validate_raw_manifest(study_root, raw_dir)
    config = load_config(study_root / "study_config.json")
    seasons = tuple(config.confirmation_seasons)
    pilot_seasons = tuple(config.pilot_seasons)
    all_seasons = (*seasons, *pilot_seasons)

    print("post-confirmation 1/6: loading six confirmation and two pilot seasons", flush=True)
    by_season: dict[int, pd.DataFrame] = {}
    for season in all_seasons:
        enriched = _build_enriched_season(season, config, raw_dir, cache_dir)
        sample, _ = build_main_sample(enriched, config)
        by_season[int(season)] = sample
    main = pd.concat([by_season[season] for season in seasons], ignore_index=True)
    main, wp_diagnostics, wp_metadata = _add_crossfit_leverage(main, raw_dir, seasons)
    for season in seasons:
        by_season[season] = main.loc[main["season"].eq(season)].copy()
    regulation_rows = int(main["remaining_game_seconds"].notna().sum())
    overtime_rows = int(main["remaining_game_seconds"].isna().sum())
    analysis_flow = {
        "six_season_primary_rows": int(len(main)),
        "six_season_regulation_rows": regulation_rows,
        "continuous_and_win_probability_rows": regulation_rows,
        "rows_excluded_from_regulation_only_moderators": overtime_rows,
        "exclusion_reason": "overtime attempts have no remaining regulation-game seconds",
        "excluded_period_counts": {
            str(int(period)): int(count)
            for period, count in main.loc[
                main["remaining_game_seconds"].isna(), "period"
            ].value_counts().sort_index().items()
        },
    }
    records: dict[str, dict[str, object]] = {}

    print("post-confirmation 2/6: covariance refit and six-season sensitivities", flush=True)
    sealed_refit = _fit_primary(main, config)
    records["sealed_refit_covariance"] = _model_record(
        "sealed_refit_covariance",
        sealed_refit,
        ("previous_personal_miss", "post_miss_x_critical"),
        sample="six held-out seasons",
    )
    critical_contrast = linear_contrast(
        sealed_refit.predictors,
        sealed_refit.estimates,
        sealed_refit.covariance,
        {"previous_personal_miss": 1.0, "post_miss_x_critical": 1.0},
    )

    for model_id, seconds, margin in (
        ("critical_2min_margin3", 120.0, 3.0),
        ("critical_5min_margin3", 300.0, 3.0),
        ("critical_5min_margin8", 300.0, 8.0),
    ):
        data = main.copy(deep=False)
        alt = _critical_indicator(main, seconds, margin)
        column = f"{model_id}_indicator"
        interaction = f"post_miss_x_{model_id}"
        data = data.assign(**{column: alt, interaction: main["previous_personal_miss"] * alt})
        predictors = ["previous_personal_miss", column, interaction, *_base_controls(config)]
        model = _fit_primary(data, config, predictors=predictors)
        records[model_id] = _model_record(
            model_id,
            model,
            (interaction,),
            sample="six held-out seasons",
            moderator_summary={
                "mean": float(alt.mean()),
                "standard_deviation": float(alt.std()),
                "q05": float(alt.quantile(.05)),
                "q25": float(alt.quantile(.25)),
                "q50": float(alt.quantile(.50)),
                "q75": float(alt.quantile(.75)),
                "q95": float(alt.quantile(.95)),
            },
        )

    continuous_model = _fit_primary(
        main,
        config,
        predictors=[
            "previous_personal_miss",
            "continuous_criticality",
            "post_miss_x_continuous_criticality",
            *_base_controls(config),
        ],
    )
    continuous = main["continuous_criticality"].dropna()
    records["continuous_criticality"] = _model_record(
        "continuous_criticality",
        continuous_model,
        ("post_miss_x_continuous_criticality",),
        sample="six held-out regulation seasons",
        moderator_summary={
            "mean": float(continuous.mean()),
            "standard_deviation": float(continuous.std()),
            "q05": float(continuous.quantile(.05)),
            "q25": float(continuous.quantile(.25)),
            "q50": float(continuous.quantile(.50)),
            "q75": float(continuous.quantile(.75)),
            "q95": float(continuous.quantile(.95)),
        },
    )

    leverage_model = _fit_primary(
        main,
        config,
        predictors=[
            "previous_personal_miss",
            "win_probability_leverage",
            "post_miss_x_win_probability_leverage",
            *_base_controls(config),
        ],
    )
    leverage = main["win_probability_leverage"].dropna()
    records["win_probability_leverage"] = _model_record(
        "win_probability_leverage",
        leverage_model,
        ("post_miss_x_win_probability_leverage",),
        sample="six held-out regulation seasons; out-of-season win model",
        moderator_summary={
            "mean": float(leverage.mean()),
            "standard_deviation": float(leverage.std()),
            "q05": float(leverage.quantile(.05)),
            "q25": float(leverage.quantile(.25)),
            "q50": float(leverage.quantile(.50)),
            "q75": float(leverage.quantile(.75)),
            "q95": float(leverage.quantile(.95)),
        },
    )

    for model_id, mask in (
        ("interval_le_120", main["personal_interval_seconds"].le(120)),
        ("same_stint", main["same_stint"].fillna(False)),
        ("no_timeout", main["no_timeout_between_personal_shots"].fillna(False)),
    ):
        model = _fit_primary(main.loc[mask], config)
        records[model_id] = _model_record(
            model_id,
            model,
            ("previous_personal_miss", "post_miss_x_critical"),
            sample=f"six held-out seasons; {model_id}",
        )

    three_model = _fit_primary(main, config, outcome="is_three_point_attempt")
    records["three_point_secondary"] = _model_record(
        "three_point_secondary",
        three_model,
        ("previous_personal_miss", "post_miss_x_critical"),
        sample="six held-out seasons",
    )

    print("post-confirmation 3/6: timeout, period, quarter, and nonlinear checks", flush=True)
    timeout_data = timeout_design(main)
    timeout_predictors = [
        "previous_personal_miss",
        "critical",
        "post_miss_x_critical",
        "intervening_timeout",
        "miss_x_timeout",
        "critical_x_timeout",
        "miss_x_critical_x_timeout",
        *_base_controls(config),
    ]
    timeout_model = _fit_primary(timeout_data, config, predictors=timeout_predictors)
    records["timeout_heterogeneity"] = _model_record(
        "timeout_heterogeneity",
        timeout_model,
        ("post_miss_x_critical", "miss_x_critical_x_timeout"),
        sample="six held-out seasons; fully interacted timeout model",
    )
    timeout_yes = linear_contrast(
        timeout_model.predictors,
        timeout_model.estimates,
        timeout_model.covariance,
        {"post_miss_x_critical": 1.0, "miss_x_critical_x_timeout": 1.0},
    )
    timeout_difference = linear_contrast(
        timeout_model.predictors,
        timeout_model.estimates,
        timeout_model.covariance,
        {"miss_x_critical_x_timeout": 1.0},
    )

    period_model = _fit_primary(
        main,
        config,
        fe_groups=["player_id_x_season", "game_id", "period"],
    )
    records["period_fixed_effects"] = _model_record(
        "period_fixed_effects",
        period_model,
        ("previous_personal_miss", "post_miss_x_critical"),
        sample="six held-out seasons; period fixed effects",
    )
    q4_model = _fit_primary(main.loc[main["period"].eq(4)], config)
    records["fourth_quarter_only"] = _model_record(
        "fourth_quarter_only",
        q4_model,
        ("previous_personal_miss", "post_miss_x_critical"),
        sample="six held-out seasons; fourth quarter only",
    )
    nonlinear = main.copy(deep=False)
    spline_names = []
    assignments = {}
    for knot in (4, 14, 24, 30):
        name = f"previous_distance_spline_{knot}"
        assignments[name] = (main["previous_personal_shot_distance_feet"] - knot).clip(lower=0)
        spline_names.append(name)
    nonlinear = nonlinear.assign(**assignments)
    nonlinear_model = _fit_primary(
        nonlinear,
        config,
        predictors=[*primary_predictors(config), *spline_names],
    )
    records["nonlinear_previous_distance"] = _model_record(
        "nonlinear_previous_distance",
        nonlinear_model,
        ("previous_personal_miss", "post_miss_x_critical"),
        sample="six held-out seasons; nonlinear previous-shot distance",
    )

    print("post-confirmation 4/6: shot-zone outcomes and cell counts", flush=True)
    zones = shot_zone_indicators(main)
    for outcome in ("zone_at_rim", "zone_short_two", "zone_long_two", "zone_three"):
        model = _fit_primary(zones, config, outcome=outcome)
        model_id = f"shot_zone_{outcome.removeprefix('zone_')}"
        records[model_id] = _model_record(
            model_id,
            model,
            ("previous_personal_miss", "post_miss_x_critical"),
            sample="six held-out seasons",
        )

    cell_counts = (
        timeout_data.assign(
            previous_personal_miss=timeout_data["previous_personal_miss"].astype(int),
            critical=timeout_data["critical"].astype(int),
            intervening_timeout=timeout_data["intervening_timeout"].astype(int),
        )
        .groupby(["critical", "previous_personal_miss", "intervening_timeout"], dropna=False)
        .size()
        .rename("n")
        .reset_index()
        .to_dict(orient="records")
    )

    print("post-confirmation 5/6: decomposing six- versus eight-season no-timeout result", flush=True)
    no_timeout_rows, pooled_no_timeout, no_timeout_period_difference = _no_timeout_decomposition(
        by_season, config, seasons, pilot_seasons
    )
    pooled_index = {name: i for i, name in enumerate(pooled_no_timeout.predictors)}
    pooled_i = pooled_index["post_miss_x_critical"]
    original_no_timeout = pd.read_csv(
        study_root / "tables" / "table_4_secondary_robustness.csv"
    )
    original_no_timeout = original_no_timeout.loc[
        original_no_timeout["model_id"].eq("no_timeout")
        & original_no_timeout["term"].eq("post_miss_x_critical")
    ].iloc[0]
    no_timeout_parity = {
        "reference_scope": "original pooled eight-season Table 3 robustness analysis",
        "reference_estimate": float(original_no_timeout["estimate"]),
        "refit_estimate": float(pooled_no_timeout.estimates[pooled_i]),
        "estimate_difference": float(
            pooled_no_timeout.estimates[pooled_i] - float(original_no_timeout["estimate"])
        ),
        "reference_n_obs": int(original_no_timeout["n_obs"]),
        "refit_n_obs": int(pooled_no_timeout.n_obs),
        "tolerance": 1e-10,
    }
    if abs(no_timeout_parity["estimate_difference"]) > no_timeout_parity["tolerance"]:
        raise ValueError("pooled eight-season no-timeout refit does not match the original result")
    if no_timeout_parity["reference_n_obs"] != no_timeout_parity["refit_n_obs"]:
        raise ValueError("pooled eight-season no-timeout sample size does not match")

    sealed = json.loads(
        (study_root / "results" / "confirmation_primary.json").read_text(encoding="utf-8")
    )
    sealed_h1 = float(sealed["hypotheses"]["h1"]["estimate"])
    sealed_h2 = float(sealed["hypotheses"]["h2"]["estimate"])
    refit_map = dict(zip(sealed_refit.predictors, sealed_refit.estimates))
    payload = {
        "analysis_status": ANALYSIS_STATUS,
        "confirmation_seasons": list(seasons),
        "models": records,
        "critical_state_post_miss_contrast": critical_contrast,
        "timeout_interaction_with_timeout": timeout_yes,
        "timeout_interaction_difference": timeout_difference,
        "cell_counts": cell_counts,
        "win_probability_crossfit": wp_diagnostics,
        "win_probability_definition": wp_metadata,
        "analysis_flow": analysis_flow,
        "no_timeout_decomposition": no_timeout_rows,
        "no_timeout_pilot_vs_confirmation_model": no_timeout_period_difference.to_dict(),
        "no_timeout_pooled_parity": no_timeout_parity,
        "software_versions": _software_versions(),
        "sealed_parity": {
            "h1_difference": float(refit_map["previous_personal_miss"] - sealed_h1),
            "h2_difference": float(refit_map["post_miss_x_critical"] - sealed_h2),
            "tolerance": 1e-10,
        },
    }
    validate_supplement_payload(payload)

    print("post-confirmation 6/6: writing versioned artifacts", flush=True)
    results_dir = study_root / "results"
    tables_dir = study_root / "tables"
    supplement_dir = study_root / "supplement"
    for directory in (results_dir, tables_dir, supplement_dir):
        directory.mkdir(parents=True, exist_ok=True)
    (results_dir / "post_confirmation_six_season.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8"
    )
    targets = _target_rows(records)
    targets = _add_holm_columns(
        targets,
        {
            "criticality_constructs": [
                ("critical_2min_margin3", "post_miss_x_critical_2min_margin3"),
                ("critical_5min_margin3", "post_miss_x_critical_5min_margin3"),
                ("critical_5min_margin8", "post_miss_x_critical_5min_margin8"),
                ("continuous_criticality", "post_miss_x_continuous_criticality"),
                ("win_probability_leverage", "post_miss_x_win_probability_leverage"),
            ],
            "sequence_and_specification": [
                ("interval_le_120", "post_miss_x_critical"),
                ("same_stint", "post_miss_x_critical"),
                ("no_timeout", "post_miss_x_critical"),
                ("three_point_secondary", "post_miss_x_critical"),
                ("period_fixed_effects", "post_miss_x_critical"),
                ("fourth_quarter_only", "post_miss_x_critical"),
                ("nonlinear_previous_distance", "post_miss_x_critical"),
            ],
            "shot_zone_interactions": [
                ("shot_zone_at_rim", "post_miss_x_critical"),
                ("shot_zone_short_two", "post_miss_x_critical"),
                ("shot_zone_long_two", "post_miss_x_critical"),
                ("shot_zone_three", "post_miss_x_critical"),
            ],
        },
    )
    targets.to_csv(
        tables_dir / "table_5_six_season_supplementary.csv",
        index=False,
        float_format="%.17g",
        lineterminator="\n",
    )

    construct_ids = [
        "sealed_refit_covariance",
        "critical_2min_margin3",
        "critical_5min_margin3",
        "critical_5min_margin8",
        "continuous_criticality",
        "win_probability_leverage",
    ]
    construct_rows = []
    for model_id in construct_ids:
        record = records[model_id]
        target_name = record["target_terms"][-1]
        target = record["targets"][target_name]
        summary = record.get("moderator_summary", {})
        binary = model_id in {
            "sealed_refit_covariance",
            "critical_2min_margin3",
            "critical_5min_margin3",
            "critical_5min_margin8",
        }
        iqr = moderator_effect_scale(summary, binary=binary)
        change = moderator_change_spec(summary, binary=binary)
        target_row = targets.loc[
            targets["model_id"].eq(model_id) & targets["term"].eq(target_name)
        ].iloc[0]
        construct_rows.append(
            {
                "model_id": model_id,
                "analysis_status": ANALYSIS_STATUS,
                "moderator": target_name,
                **target,
                "p_raw": float(target_row["p_raw"]),
                "p_holm": target_row["p_holm"],
                "multiplicity_family": target_row["multiplicity_family"],
                "adjustment_method": target_row["adjustment_method"],
                "moderator_mean": summary.get("mean", np.nan),
                "moderator_sd": summary.get("standard_deviation", np.nan),
                "moderator_q05": summary.get("q05", np.nan),
                "moderator_q25": summary.get("q25", np.nan),
                "moderator_q50": summary.get("q50", np.nan),
                "moderator_q75": summary.get("q75", np.nan),
                "moderator_q95": summary.get("q95", np.nan),
                "effect_per_iqr": float(target["estimate"]) * iqr,
                **change,
                "effect_over_reported_scale": float(target["estimate"])
                * float(change["scale_change"]),
                "n_obs": record["n_obs"],
            }
        )
    pd.DataFrame.from_records(construct_rows).to_csv(
        tables_dir / "table_6_criticality_constructs.csv",
        index=False,
        float_format="%.17g",
        lineterminator="\n",
    )

    timeout_rows = [
        {"row_type": "effect", "label": "no_timeout_interaction", **records["timeout_heterogeneity"]["targets"]["post_miss_x_critical"]},
        {"row_type": "effect", "label": "with_timeout_interaction", **timeout_yes},
        {"row_type": "effect", "label": "with_minus_without_timeout", **timeout_difference},
    ]
    timeout_rows.extend({"row_type": "count", "label": "cell", **row} for row in cell_counts)
    pd.DataFrame.from_records(timeout_rows).to_csv(
        tables_dir / "table_7_timeout_heterogeneity.csv",
        index=False,
        float_format="%.17g",
        lineterminator="\n",
    )
    zone_ids = [model_id for model_id in records if model_id.startswith("shot_zone_")]
    zone_rows = targets.loc[targets["model_id"].isin(zone_ids)].copy()
    zone_rows["estimate_percentage_points"] = zone_rows["estimate"] * 100.0
    zone_rows["ci_low_percentage_points"] = zone_rows["ci_low"] * 100.0
    zone_rows["ci_high_percentage_points"] = zone_rows["ci_high"] * 100.0
    zone_rows.to_csv(
        tables_dir / "table_8_shot_zone_outcomes.csv",
        index=False,
        float_format="%.17g",
        lineterminator="\n",
    )
    pd.DataFrame.from_records(no_timeout_rows).to_csv(
        tables_dir / "table_9_no_timeout_decomposition.csv",
        index=False,
        float_format="%.17g",
        lineterminator="\n",
    )
    wp_rows = []
    for row in wp_diagnostics:
        wp_rows.append({key: value for key, value in row.items() if key not in {"coefficients", "training_seasons"}})
    wp_rows.append(
        {
            "target_season": "pooled held-out predictions",
            "validation_scope": wp_metadata["validation_scope"],
            **wp_metadata["pooled_holdout_diagnostics"],
        }
    )
    pd.DataFrame.from_records(wp_rows).to_csv(
        tables_dir / "table_10_win_probability_validation.csv",
        index=False,
        float_format="%.17g",
        lineterminator="\n",
    )
    reproducibility_dir = study_root / "reproducibility"
    reproducibility_dir.mkdir(parents=True, exist_ok=True)
    (reproducibility_dir / "software_versions.json").write_text(
        json.dumps(payload["software_versions"], indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--raw-dir", type=Path, default=Path("work/data/raw"))
    parser.add_argument("--cache-dir", type=Path, default=Path("work/data/analysis_cache"))
    args = parser.parse_args()
    run_post_confirmation(args.study_root, args.raw_dir, args.cache_dir)


if __name__ == "__main__":
    main()
