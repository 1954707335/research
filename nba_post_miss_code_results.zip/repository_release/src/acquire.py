"""Acquire exactly the raw files named by the frozen study contract."""

from __future__ import annotations

import argparse
import hashlib
import shutil
import tarfile
import urllib.request
from pathlib import Path, PurePosixPath

import pandas as pd

from .config import StudyConfig, load_config


DEFAULT_LIST_URL = "https://raw.githubusercontent.com/shufinskiy/nba_data/main/list_data.txt"


def calculate_sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def select_dataset_urls(list_text: str, config: StudyConfig) -> dict[str, str]:
    available: dict[str, str] = {}
    for raw_line in list_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, url = line.split("=", 1)
        available[name.strip()] = url.strip()

    expected = {
        f"{family}_{season}"
        for season in config.all_seasons
        for family in config.data_families
    }
    missing = sorted(expected - set(available))
    if missing:
        raise ValueError(f"dataset list is missing required entries: {missing}")
    return {name: available[name] for name in sorted(expected)}


def validate_tar_members(archive_path: Path) -> list[tarfile.TarInfo]:
    valid: list[tarfile.TarInfo] = []
    with tarfile.open(archive_path, "r:xz") as archive:
        for member in archive.getmembers():
            member_path = PurePosixPath(member.name)
            if member_path.is_absolute() or ".." in member_path.parts:
                raise ValueError(f"unsafe archive path: {member.name}")
            if not member.isfile():
                raise ValueError(f"unsupported non-file archive member: {member.name}")
            valid.append(member)
    return valid


def _download(url: str, destination: Path, attempts: int = 3, timeout: int = 600) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_suffix(destination.suffix + ".part")
    request = urllib.request.Request(url, headers={"User-Agent": "nba-post-miss-study/1.0"})
    last_error: BaseException | None = None
    for _ in range(attempts):
        partial.unlink(missing_ok=True)
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response, partial.open("wb") as output:
                shutil.copyfileobj(response, output, length=1024 * 1024)
            partial.replace(destination)
            return
        except (TimeoutError, OSError) as error:
            last_error = error
    partial.unlink(missing_ok=True)
    if last_error is not None:
        raise last_error
    raise RuntimeError("download attempts must be positive")


def _extract_single_csv(archive_path: Path, raw_dir: Path, expected_name: str) -> Path:
    members = validate_tar_members(archive_path)
    matching = [member for member in members if PurePosixPath(member.name).name == expected_name]
    if len(matching) != 1:
        raise ValueError(
            f"{archive_path.name} must contain exactly one {expected_name}; found {len(matching)}"
        )
    destination = raw_dir / expected_name
    with tarfile.open(archive_path, "r:xz") as archive:
        source = archive.extractfile(matching[0])
        if source is None:
            raise ValueError(f"could not read {matching[0].name}")
        partial = destination.with_suffix(destination.suffix + ".part")
        with source, partial.open("wb") as output:
            shutil.copyfileobj(source, output, length=1024 * 1024)
        partial.replace(destination)
    return destination


def download_files(config: StudyConfig, list_url: str, raw_dir: Path) -> pd.DataFrame:
    raw_dir = Path(raw_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(list_url, timeout=120) as response:
        list_text = response.read().decode("utf-8")
    selected = select_dataset_urls(list_text, config)

    records: list[dict[str, object]] = []
    for name, url in selected.items():
        family, season_text = name.rsplit("_", 1)
        season = int(season_text)
        archive_path = raw_dir / f"{name}.tar.xz"
        csv_path = raw_dir / f"{name}.csv"
        if not archive_path.exists():
            _download(url, archive_path)
        if not csv_path.exists():
            _extract_single_csv(archive_path, raw_dir, csv_path.name)
        role = "confirmation" if season in config.confirmation_seasons else "exploratory_pilot"
        records.append(
            {
                "season_start": season,
                "season_label": f"{season}-{str(season + 1)[-2:]}",
                "sample_role": role,
                "data_family": family,
                "archive_name": archive_path.name,
                "source_url": url,
                "archive_bytes": archive_path.stat().st_size,
                "archive_sha256": calculate_sha256(archive_path),
                "extracted_name": csv_path.name,
                "extracted_bytes": csv_path.stat().st_size,
                "extracted_sha256": calculate_sha256(csv_path),
                "status": "complete",
            }
        )
    return pd.DataFrame.from_records(records).sort_values(["season_start", "data_family"])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--list-url", default=DEFAULT_LIST_URL)
    parser.add_argument("--manifest", type=Path)
    args = parser.parse_args()
    config = load_config(args.config)
    manifest = download_files(config, args.list_url, args.raw_dir)
    manifest_path = args.manifest or args.config.with_name("data_manifest.csv")
    manifest.to_csv(manifest_path, index=False)
    print(f"Acquired {len(manifest)} files; manifest: {manifest_path}")


if __name__ == "__main__":
    main()

