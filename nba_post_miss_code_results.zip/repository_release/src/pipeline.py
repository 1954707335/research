"""Stage-ordered analysis pipeline with a confirmation-result firewall."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd

from .acquire import calculate_sha256
from .audit import audit_season
from .config import StudyConfig, load_config
from .estimators import ModelResult, fit_hdfe_ols
from .events import build_shot_events, canonicalize_pbp_events
from .features import add_game_state_features
from .samples import ExclusionFlow, build_main_sample
from .sequences import add_global_interval_flags, add_personal_lag


class ConfirmationFirewallError(RuntimeError):
    """Raised when confirmation output is requested without an intact freeze."""


_STAGE_OUTPUTS = {
    "audit": {"data_audit.csv", "data_anomalies.csv"},
    "pilot": {"pilot_pipeline_dry_run.json", "pilot_by_season.csv"},
    "freeze": {"analysis_freeze.json"},
    "confirm": {"confirmation_primary.json", "confirmation_by_season.csv"},
    "pooled": {"all_models.json", "meta_analysis.csv"},
    "robustness": {"all_models.json", "multiplicity_adjusted.csv"},
    "report": {"supplementary_results.md"},
}


def stage_output_names(stage: str) -> set[str]:
    if stage not in _STAGE_OUTPUTS:
        raise ValueError(f"unknown stage: {stage}")
    return set(_STAGE_OUTPUTS[stage])


def _default_tracked_paths(study_root: Path) -> list[Path]:
    paths = [study_root / "study_config.json", study_root / "data_manifest.csv"]
    paths.extend(sorted((study_root / "src").glob("*.py")))
    paths.extend(sorted((study_root / "tests").glob("test_*.py")))
    spec = study_root.parent / "SCI_research_design_post_miss_criticality_zh.md"
    if spec.exists():
        paths.append(spec)
    return paths


def _primary_formula(config: StudyConfig) -> dict[str, object]:
    return {
        "outcome": "shot_distance_feet",
        "predictors": primary_predictors(config),
        "fixed_effects": list(config.fixed_effects),
        "clusters": list(config.cluster_groups),
        "h1": config.hypothesis_h1_direction,
        "h2": config.hypothesis_h2_direction,
    }


def create_freeze_manifest(
    study_root: Path,
    tracked_paths: Sequence[Path] | None = None,
    overwrite: bool = False,
) -> Path:
    study_root = Path(study_root).resolve()
    freeze_path = study_root / "analysis_freeze.json"
    if freeze_path.exists() and not overwrite:
        raise ConfirmationFirewallError(f"freeze already exists: {freeze_path}")
    explicit_paths = tracked_paths is not None
    paths = [Path(path).resolve() for path in (tracked_paths or _default_tracked_paths(study_root))]
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise ConfirmationFirewallError(f"cannot freeze missing files: {missing}")
    base = study_root.parent
    records = []
    for path in sorted(paths, key=str):
        try:
            relative = path.relative_to(base)
        except ValueError as error:
            raise ConfirmationFirewallError(f"tracked path must be under {base}: {path}") from error
        records.append(
            {"path": relative.as_posix(), "bytes": path.stat().st_size, "sha256": calculate_sha256(path)}
        )
    config_path = study_root / "study_config.json"
    if not explicit_paths and config_path in paths:
        config = load_config(config_path)
        formula = _primary_formula(config)
    else:
        formula = {"outcome": "shot_distance_feet", "scope": "test fixture"}
    payload = {
        "status": "frozen_pre_confirmation",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "base_anchor": "study_root_parent",
        "tracked_files": records,
        "primary_model": formula,
        "runtime": {
            "python": platform.python_version(),
            "pandas": pd.__version__,
            "numpy": np.__version__,
        },
    }
    freeze_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return freeze_path


def assert_confirmation_allowed(study_root: Path) -> dict[str, object]:
    study_root = Path(study_root).resolve()
    freeze_path = study_root / "analysis_freeze.json"
    if not freeze_path.is_file():
        raise ConfirmationFirewallError("confirmation analysis requires analysis_freeze.json")
    payload = json.loads(freeze_path.read_text(encoding="utf-8"))
    if payload.get("status") != "frozen_pre_confirmation":
        raise ConfirmationFirewallError("freeze manifest has an invalid status")
    base = study_root.parent
    failures: list[str] = []
    for record in payload.get("tracked_files", []):
        path = base / record["path"]
        if not path.is_file():
            failures.append(f"missing:{record['path']}")
            continue
        actual = calculate_sha256(path)
        if actual != record["sha256"]:
            failures.append(f"changed:{record['path']}")
    if failures:
        raise ConfirmationFirewallError("freeze validation failed: " + ", ".join(failures))
    return payload


def validate_raw_manifest(study_root: Path, raw_dir: Path) -> None:
    manifest = pd.read_csv(study_root / "data_manifest.csv")
    incomplete = manifest.loc[manifest["status"].ne("complete")]
    if not incomplete.empty:
        raise ConfirmationFirewallError("data manifest contains incomplete rows")
    failures: list[str] = []
    for row in manifest.itertuples(index=False):
        path = Path(raw_dir) / row.extracted_name
        if not path.is_file():
            failures.append(f"missing:{row.extracted_name}")
        elif path.stat().st_size != int(row.extracted_bytes):
            failures.append(f"size:{row.extracted_name}")
        elif calculate_sha256(path) != row.extracted_sha256:
            failures.append(f"hash:{row.extracted_name}")
    if failures:
        raise ConfirmationFirewallError("raw-data validation failed: " + ", ".join(failures))


def primary_predictors(config: StudyConfig) -> list[str]:
    predictors = [
        "previous_personal_miss",
        "critical",
        "post_miss_x_critical",
        "previous_personal_shot_distance_feet",
        "offense_signed_pre_shot_margin",
        "absolute_pre_shot_margin",
        "remaining_period_seconds",
        "personal_interval_seconds",
        "is_home_offense",
    ]
    predictors.extend(
        f"remaining_period_seconds_spline_{k}" for k in config.remaining_period_seconds_knots
    )
    predictors.extend(
        f"absolute_pre_shot_margin_spline_{k}" for k in config.absolute_margin_knots
    )
    predictors.extend(
        f"personal_interval_seconds_spline_{k}" for k in config.personal_interval_seconds_knots
    )
    return predictors


def _build_season_main(
    season: int, config: StudyConfig, raw_dir: Path
) -> tuple[pd.DataFrame, ExclusionFlow, int]:
    pbp = pd.read_csv(Path(raw_dir) / f"nbastatsv3_{season}.csv", low_memory=False)
    details = pd.read_csv(Path(raw_dir) / f"shotdetail_{season}.csv", low_memory=False)
    shots, anomalies = build_shot_events(pbp, details)
    events = canonicalize_pbp_events(pbp)
    shots = add_global_interval_flags(shots, events)
    shots = add_personal_lag(shots)
    shots["season"] = season
    shots["player_id_x_season"] = shots["player_id"].astype("Int64").astype(str) + f":{season}"
    featured = add_game_state_features(shots, config)
    sample, flow = build_main_sample(featured, config)
    return sample, flow, len(anomalies)


def _fit_primary(data: pd.DataFrame, config: StudyConfig, config_hash: str) -> ModelResult:
    return fit_hdfe_ols(
        data,
        outcome="shot_distance_feet",
        predictors=primary_predictors(config),
        fe_groups=list(config.fixed_effects),
        cluster_groups=list(config.cluster_groups),
        tol=1e-9,
        max_iter=10_000,
        config_hash=config_hash,
    )


def _flow_record(season: int, flow: ExclusionFlow, anomalies: int) -> dict[str, object]:
    return {
        "season": season,
        "initial_n": flow.initial_n,
        "retained_n": flow.retained_n,
        "event_anomalies": anomalies,
        "steps": flow.to_frame().to_dict(orient="records"),
    }


def run_primary_analysis(
    seasons: Sequence[int], config: StudyConfig, study_root: Path, raw_dir: Path, label: str
) -> tuple[dict[str, object], pd.DataFrame]:
    config_hash = calculate_sha256(study_root / "study_config.json")
    frames: list[pd.DataFrame] = []
    flows: list[dict[str, object]] = []
    season_rows: list[dict[str, object]] = []
    predictors = primary_predictors(config)
    model_columns = list(
        dict.fromkeys(
            [
                "season",
                "shot_distance_feet",
                *predictors,
                *config.fixed_effects,
                *config.cluster_groups,
            ]
        )
    )
    for season in seasons:
        sample, flow, anomaly_count = _build_season_main(season, config, raw_dir)
        model_frame = sample.loc[:, model_columns].copy()
        season_model = _fit_primary(model_frame, config, config_hash)
        frames.append(model_frame)
        flows.append(_flow_record(season, flow, anomaly_count))
        h1 = "previous_personal_miss"
        h2 = "post_miss_x_critical"
        season_rows.append(
            {
                "season": season,
                "n": season_model.n_obs,
                "h1_estimate": season_model.estimates[h1],
                "h1_se_two_way": season_model.two_way_standard_errors[h1],
                "h1_p_normal": season_model.p_values_normal[h1],
                "h1_direction_supported": season_model.estimates[h1] < 0,
                "h2_estimate": season_model.estimates[h2],
                "h2_se_two_way": season_model.two_way_standard_errors[h2],
                "h2_p_normal": season_model.p_values_normal[h2],
                "h2_direction_supported": season_model.estimates[h2] > 0,
                "sample_hash": season_model.sample_hash,
                "formula_hash": season_model.formula_hash,
            }
        )
    pooled_data = pd.concat(frames, ignore_index=True)
    pooled_model = _fit_primary(pooled_data, config, config_hash)
    h1 = "previous_personal_miss"
    h2 = "post_miss_x_critical"
    payload = {
        "analysis_label": label,
        "seasons": list(seasons),
        "formula": _primary_formula(config),
        "sample_flow": flows,
        "pooled_model": pooled_model.to_dict(),
        "hypotheses": {
            "h1": {
                "estimate": pooled_model.estimates[h1],
                "standard_error_two_way": pooled_model.two_way_standard_errors[h1],
                "confidence_interval": pooled_model.confidence_intervals[h1],
                "p_normal": pooled_model.p_values_normal[h1],
                "direction_supported": pooled_model.estimates[h1] < 0,
            },
            "h2": {
                "estimate": pooled_model.estimates[h2],
                "standard_error_two_way": pooled_model.two_way_standard_errors[h2],
                "confidence_interval": pooled_model.confidence_intervals[h2],
                "p_normal": pooled_model.p_values_normal[h2],
                "direction_supported": pooled_model.estimates[h2] > 0,
            },
        },
    }
    return payload, pd.DataFrame.from_records(season_rows)


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def run_audit_stage(config: StudyConfig, raw_dir: Path, out_dir: Path) -> None:
    results = [
        audit_season(
            Path(raw_dir) / f"nbastatsv3_{season}.csv",
            Path(raw_dir) / f"shotdetail_{season}.csv",
            season,
        )
        for season in config.all_seasons
    ]
    out_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([result.to_record() for result in results]).to_csv(
        out_dir / "data_audit.csv", index=False, lineterminator="\n"
    )
    anomalies = [result.anomalies for result in results if not result.anomalies.empty]
    pd.concat(anomalies, ignore_index=True).to_csv(
        out_dir / "data_anomalies.csv", index=False, lineterminator="\n"
    )


def run_pilot_stage(config: StudyConfig, study_root: Path, raw_dir: Path, out_dir: Path) -> None:
    payload, seasons = run_primary_analysis(
        config.pilot_seasons, config, study_root, raw_dir, "exploratory_pilot"
    )
    _write_json(out_dir / "pilot_pipeline_dry_run.json", payload)
    seasons.to_csv(
        out_dir / "pilot_by_season.csv", index=False, float_format="%.17g", lineterminator="\n"
    )


def run_confirm_stage(config: StudyConfig, study_root: Path, raw_dir: Path, out_dir: Path) -> None:
    assert_confirmation_allowed(study_root)
    validate_raw_manifest(study_root, raw_dir)
    primary_path = out_dir / "confirmation_primary.json"
    seasons_path = out_dir / "confirmation_by_season.csv"
    existing = [path for path in (primary_path, seasons_path) if path.exists()]
    if existing:
        raise ConfirmationFirewallError(f"refusing to overwrite confirmation output: {existing}")
    payload, seasons = run_primary_analysis(
        config.confirmation_seasons, config, study_root, raw_dir, "held_out_confirmation"
    )
    _write_json(primary_path, payload)
    seasons.to_csv(seasons_path, index=False, float_format="%.17g", lineterminator="\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "stage", choices=["audit", "pilot", "freeze", "confirm", "pooled", "robustness", "report"]
    )
    parser.add_argument("--study-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--raw-dir", type=Path, default=Path("work/data/raw"))
    parser.add_argument("--out-dir", type=Path)
    args = parser.parse_args()
    study_root = args.study_root.resolve()
    config = load_config(study_root / "study_config.json")
    out_dir = args.out_dir or study_root / "results"
    if args.stage == "audit":
        validate_raw_manifest(study_root, args.raw_dir)
        run_audit_stage(config, args.raw_dir, out_dir)
    elif args.stage == "pilot":
        validate_raw_manifest(study_root, args.raw_dir)
        run_pilot_stage(config, study_root, args.raw_dir, out_dir)
    elif args.stage == "freeze":
        path = create_freeze_manifest(study_root)
        print(f"Created analysis freeze: {path}")
    elif args.stage == "confirm":
        run_confirm_stage(config, study_root, args.raw_dir, out_dir)
    else:
        raise NotImplementedError(f"stage {args.stage} is implemented in Task 7 or 8")


if __name__ == "__main__":
    main()
