"""High-dimensional fixed-effect OLS with multi-way clustered uncertainty."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass
from typing import Sequence

import numpy as np
import pandas as pd


class AbsorptionConvergenceError(RuntimeError):
    """Raised when alternating fixed-effect projections do not converge."""


@dataclass(frozen=True, slots=True)
class AbsorbedData:
    y: np.ndarray
    X: np.ndarray
    predictor_names: tuple[str, ...]
    converged: bool
    iterations: int
    max_change: float


@dataclass(frozen=True, slots=True)
class ModelResult:
    outcome: str
    predictors: tuple[str, ...]
    estimates: dict[str, float]
    two_way_standard_errors: dict[str, float]
    one_way_standard_errors: dict[str, dict[str, float]]
    confidence_intervals: dict[str, tuple[float, float]]
    p_values_normal: dict[str, float]
    n_obs: int
    cluster_counts: dict[str, int]
    fixed_effect_counts: dict[str, int]
    within_r_squared: float
    converged: bool
    absorption_iterations: int
    absorption_max_change: float
    formula_hash: str
    config_hash: str
    sample_hash: str
    dropped_predictors: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _factor_codes(values: Sequence[object] | pd.Series) -> np.ndarray:
    series = pd.Series(values, copy=False)
    if series.isna().any():
        raise ValueError("fixed-effect and cluster groups cannot contain missing values")
    codes, _ = pd.factorize(series, sort=False)
    return codes.astype(np.int64, copy=False)


def _demean(matrix: np.ndarray, codes: np.ndarray) -> float:
    counts = np.bincount(codes).astype(float)
    largest = 0.0
    for column in range(matrix.shape[1]):
        sums = np.bincount(codes, weights=matrix[:, column], minlength=len(counts))
        means = sums / counts
        largest = max(largest, float(np.max(np.abs(means))))
        matrix[:, column] -= means[codes]
    return largest


def absorb_fixed_effects(
    y: pd.Series | np.ndarray,
    X: pd.DataFrame | np.ndarray,
    groups: Sequence[pd.Series | np.ndarray],
    tol: float = 1e-10,
    max_iter: int = 10_000,
) -> AbsorbedData:
    y_values = np.asarray(y, dtype=float).reshape(-1)
    x_values = np.asarray(X, dtype=float)
    if x_values.ndim == 1:
        x_values = x_values[:, None]
    if len(y_values) != len(x_values):
        raise ValueError("y and X must have equal row counts")
    if not np.isfinite(y_values).all() or not np.isfinite(x_values).all():
        raise ValueError("y and X must be finite before absorption")
    if not groups:
        names = tuple(X.columns) if isinstance(X, pd.DataFrame) else tuple(f"x{i}" for i in range(x_values.shape[1]))
        return AbsorbedData(y_values.copy(), x_values.copy(), names, True, 0, 0.0)

    codes = [_factor_codes(group) for group in groups]
    if any(len(code) != len(y_values) for code in codes):
        raise ValueError("fixed-effect groups must match y length")
    matrix = np.column_stack([y_values, x_values]).astype(float, copy=True)
    predictor_names = (
        tuple(str(column) for column in X.columns)
        if isinstance(X, pd.DataFrame)
        else tuple(f"x{i}" for i in range(x_values.shape[1]))
    )
    max_change = float("inf")
    for iteration in range(1, max_iter + 1):
        max_change = 0.0
        for group_codes in codes:
            max_change = max(max_change, _demean(matrix, group_codes))
        if max_change < tol:
            return AbsorbedData(
                y=matrix[:, 0],
                X=matrix[:, 1:],
                predictor_names=predictor_names,
                converged=True,
                iterations=iteration,
                max_change=max_change,
            )
    raise AbsorptionConvergenceError(
        f"fixed-effect absorption did not converge after {max_iter} iterations; "
        f"last maximum group mean={max_change:.6g}"
    )


def cluster_covariance(
    X: np.ndarray, residuals: np.ndarray, clusters: Sequence[object] | np.ndarray
) -> np.ndarray:
    design = np.asarray(X, dtype=float)
    errors = np.asarray(residuals, dtype=float).reshape(-1)
    if len(design) != len(errors):
        raise ValueError("X and residuals must have equal row counts")
    codes = _factor_codes(clusters)
    group_count = int(codes.max()) + 1 if len(codes) else 0
    n_obs, n_parameters = design.shape
    if group_count <= 1:
        raise ValueError("cluster covariance requires at least two clusters")
    if n_obs <= n_parameters:
        raise ValueError("cluster covariance requires more observations than parameters")
    score_rows = design * errors[:, None]
    group_scores = np.zeros((group_count, n_parameters), dtype=float)
    np.add.at(group_scores, codes, score_rows)
    meat = group_scores.T @ group_scores
    bread = np.linalg.pinv(design.T @ design)
    correction = (group_count / (group_count - 1)) * ((n_obs - 1) / (n_obs - n_parameters))
    return correction * bread @ meat @ bread


def two_way_cluster_covariance(
    X: np.ndarray,
    residuals: np.ndarray,
    first_clusters: Sequence[object] | np.ndarray,
    second_clusters: Sequence[object] | np.ndarray,
) -> np.ndarray:
    first = np.asarray(first_clusters, dtype=object)
    second = np.asarray(second_clusters, dtype=object)
    if len(first) != len(second):
        raise ValueError("two cluster vectors must have equal lengths")
    intersection = np.empty(len(first), dtype=object)
    intersection[:] = list(zip(first.tolist(), second.tolist()))
    return (
        cluster_covariance(X, residuals, first)
        + cluster_covariance(X, residuals, second)
        - cluster_covariance(X, residuals, intersection)
    )


def _sha256_json(value: object) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sample_hash(data: pd.DataFrame) -> str:
    row_hashes = pd.util.hash_pandas_object(data, index=False).to_numpy(dtype=np.uint64)
    return hashlib.sha256(row_hashes.tobytes()).hexdigest()


def fit_hdfe_ols(
    data: pd.DataFrame,
    outcome: str,
    predictors: Sequence[str],
    fe_groups: Sequence[str],
    cluster_groups: Sequence[str],
    tol: float = 1e-10,
    max_iter: int = 10_000,
    config_hash: str = "",
) -> ModelResult:
    required = list(dict.fromkeys([outcome, *predictors, *fe_groups, *cluster_groups]))
    model_data = data.loc[:, required].replace([np.inf, -np.inf], np.nan).dropna().copy()
    if model_data.empty:
        raise ValueError("model has no complete observations")
    absorbed = absorb_fixed_effects(
        model_data[outcome],
        model_data.loc[:, list(predictors)],
        [model_data[group] for group in fe_groups],
        tol=tol,
        max_iter=max_iter,
    )
    scale = np.nanstd(absorbed.X, axis=0)
    keep = scale > max(tol * 10, 1e-12)
    names = tuple(name for name, retained in zip(absorbed.predictor_names, keep) if retained)
    dropped = tuple(name for name, retained in zip(absorbed.predictor_names, keep) if not retained)
    if not names:
        raise ValueError("all predictors were absorbed by fixed effects")
    design = absorbed.X[:, keep]
    beta = np.linalg.lstsq(design, absorbed.y, rcond=None)[0]
    residuals = absorbed.y - design @ beta

    one_way_covariances = {
        group: cluster_covariance(design, residuals, model_data[group].to_numpy())
        for group in cluster_groups
    }
    if len(cluster_groups) == 1:
        covariance = one_way_covariances[cluster_groups[0]]
    elif len(cluster_groups) == 2:
        covariance = two_way_cluster_covariance(
            design,
            residuals,
            model_data[cluster_groups[0]].to_numpy(),
            model_data[cluster_groups[1]].to_numpy(),
        )
    else:
        raise ValueError("fit_hdfe_ols supports one or two cluster dimensions")
    standard_errors = np.sqrt(np.clip(np.diag(covariance), 0.0, None))
    one_way_standard_errors = {
        group: {
            name: float(value)
            for name, value in zip(names, np.sqrt(np.clip(np.diag(matrix), 0.0, None)))
        }
        for group, matrix in one_way_covariances.items()
    }
    estimates = {name: float(value) for name, value in zip(names, beta)}
    se_map = {name: float(value) for name, value in zip(names, standard_errors)}
    confidence_intervals = {
        name: (estimates[name] - 1.96 * se_map[name], estimates[name] + 1.96 * se_map[name])
        for name in names
    }
    p_values = {
        name: math.erfc(abs(estimates[name] / se_map[name]) / math.sqrt(2))
        if se_map[name] > 0
        else (0.0 if estimates[name] != 0 else 1.0)
        for name in names
    }
    total_within = float(absorbed.y @ absorbed.y)
    within_r_squared = 1.0 - float(residuals @ residuals) / total_within if total_within > 0 else float("nan")
    formula = {
        "outcome": outcome,
        "predictors": list(predictors),
        "fixed_effects": list(fe_groups),
        "clusters": list(cluster_groups),
        "tolerance": tol,
        "max_iterations": max_iter,
    }
    return ModelResult(
        outcome=outcome,
        predictors=names,
        estimates=estimates,
        two_way_standard_errors=se_map,
        one_way_standard_errors=one_way_standard_errors,
        confidence_intervals=confidence_intervals,
        p_values_normal=p_values,
        n_obs=len(model_data),
        cluster_counts={group: int(model_data[group].nunique()) for group in cluster_groups},
        fixed_effect_counts={group: int(model_data[group].nunique()) for group in fe_groups},
        within_r_squared=within_r_squared,
        converged=absorbed.converged,
        absorption_iterations=absorbed.iterations,
        absorption_max_change=absorbed.max_change,
        formula_hash=_sha256_json(formula),
        config_hash=config_hash,
        sample_hash=_sample_hash(model_data),
        dropped_predictors=dropped,
    )

