"""Deterministic helpers for PLOS ONE submission and repository artifacts."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Mapping, Sequence

import pandas as pd

from .config import StudyConfig
from .pipeline import primary_predictors
from .samples import build_main_sample


DERIVED_BASE_COLUMNS = (
    "season",
    "game_id",
    "action_number",
    "period",
    "clock_seconds",
    "team_id",
    "player_id",
    "player_id_x_season",
    "pre_score_home",
    "pre_score_away",
    "shot_distance_feet",
    "loc_x",
    "loc_y",
    "is_home_offense",
    "shot_made",
    "previous_personal_action_number",
    "previous_personal_shot_distance_feet",
    "previous_personal_miss",
    "previous_personal_critical",
    "stable_critical_status",
    "personal_interval_seconds",
    "same_stint",
    "no_timeout_between_personal_shots",
    "offensive_rebound_continuation",
    "putback_within_one_second",
    "heave_proxy",
    "home_pre_shot_margin",
    "offense_signed_pre_shot_margin",
    "absolute_pre_shot_margin",
    "remaining_period_seconds",
    "remaining_game_seconds",
    "critical",
    "post_miss_x_critical",
    "continuous_criticality",
    "post_miss_x_continuous_criticality",
    "is_three_point_attempt",
    "previous_team_miss",
    "post_team_miss_x_critical",
    "previous_global_miss",
    "previous_global_relation",
    "global_rel_teammate",
    "global_rel_opponent",
    "global_miss_x_teammate",
    "global_miss_x_opponent",
    "global_miss_x_critical",
    "teammate_x_critical",
    "opponent_x_critical",
    "global_miss_x_teammate_x_critical",
    "global_miss_x_opponent_x_critical",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def coefficient_rows(
    model_id: str,
    model: Mapping[str, object],
    status: str,
    sample: str,
) -> list[dict[str, object]]:
    """Flatten a stored HDFE model into complete coefficient rows."""
    estimates = model.get("estimates")
    if not isinstance(estimates, Mapping):
        raise ValueError(f"model {model_id} has no coefficient mapping")
    standard_errors = model.get("two_way_standard_errors", model.get("standard_errors"))
    p_values = model.get("p_values_normal")
    confidence = model.get("confidence_intervals")
    if not isinstance(standard_errors, Mapping) or not isinstance(p_values, Mapping):
        raise ValueError(f"model {model_id} lacks complete inference")
    fixed_effect_counts = model.get("fixed_effect_counts", {})
    cluster_counts = model.get("cluster_counts", {})
    fixed_effects = "|".join(sorted(str(key) for key in fixed_effect_counts))
    clusters = "|".join(sorted(str(key) for key in cluster_counts))
    result = []
    for term in model.get("predictors", estimates.keys()):
        if term not in estimates:
            continue
        estimate = float(estimates[term])
        standard_error = float(standard_errors[term])
        if isinstance(confidence, Mapping) and term in confidence:
            ci_low, ci_high = map(float, confidence[term])
        else:
            ci_low = estimate - 1.96 * standard_error
            ci_high = estimate + 1.96 * standard_error
        result.append(
            {
                "model_id": model_id,
                "analysis_status": status,
                "sample": sample,
                "outcome": model.get("outcome", ""),
                "term": str(term),
                "estimate": estimate,
                "standard_error": standard_error,
                "p_value_two_sided": float(p_values[term]),
                "ci_low": ci_low,
                "ci_high": ci_high,
                "n_obs": int(model.get("n_obs", 0)),
                "within_r_squared": model.get("within_r_squared", ""),
                "fixed_effects": fixed_effects,
                "fixed_effect_counts": "|".join(
                    f"{key}:{value}" for key, value in sorted(fixed_effect_counts.items())
                ),
                "clusters": clusters,
                "cluster_counts": "|".join(
                    f"{key}:{value}" for key, value in sorted(cluster_counts.items())
                ),
                "converged": bool(model.get("converged", True)),
                "sample_hash": model.get("sample_hash", ""),
                "formula_hash": model.get("formula_hash", ""),
            }
        )
    return result


def derived_analysis_columns(config: StudyConfig) -> list[str]:
    columns = list(DERIVED_BASE_COLUMNS)
    for name in primary_predictors(config):
        if name not in columns:
            columns.append(name)
    return columns


def required_derived_columns(config: StudyConfig) -> list[str]:
    return list(
        dict.fromkeys(
            [
                "season",
                "game_id",
                "action_number",
                "period",
                "clock_seconds",
                "team_id",
                "player_id",
                "player_id_x_season",
                "pre_score_home",
                "pre_score_away",
                "shot_distance_feet",
                "loc_x",
                "loc_y",
                "is_home_offense",
                "shot_made",
                "previous_personal_action_number",
                "previous_personal_shot_distance_feet",
                "offensive_rebound_continuation",
                "putback_within_one_second",
                "heave_proxy",
                *primary_predictors(config),
            ]
        )
    )


def export_cached_derived_data(
    cache_dir: Path,
    output_dir: Path,
    config: StudyConfig,
    seasons: Sequence[int],
    *,
    home_win_by_season_game: pd.Series | None = None,
) -> list[dict[str, object]]:
    """Export the frozen main sample as deterministic season-level CSV.GZ files."""
    cache_dir = Path(cache_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    requested_columns = derived_analysis_columns(config)
    required_columns = required_derived_columns(config)
    records: list[dict[str, object]] = []
    for season in seasons:
        cached = cache_dir / f"enriched_{season}.pkl"
        if not cached.is_file():
            raise FileNotFoundError(cached)
        enriched = pd.read_pickle(cached)
        sample, _ = build_main_sample(enriched, config)
        missing = [name for name in required_columns if name not in sample.columns]
        if missing:
            raise ValueError(f"cached season {season} lacks derived columns: {missing}")
        columns = [name for name in requested_columns if name in sample.columns]
        export = sample.loc[:, columns].copy()
        if home_win_by_season_game is not None:
            keys = pd.MultiIndex.from_arrays(
                [export["season"].astype(int), export["game_id"].astype(int)]
            )
            export["home_win"] = home_win_by_season_game.reindex(keys).to_numpy()
            if export["home_win"].isna().any():
                raise ValueError(f"missing final-game outcome for season {season}")
        export = export.sort_values(["game_id", "period", "action_number"], kind="stable")
        file_name = f"derived_confirmation_{season}.csv.gz"
        path = output_dir / file_name
        export.to_csv(
            path,
            index=False,
            float_format="%.12g",
            compression={"method": "gzip", "compresslevel": 9, "mtime": 0},
        )
        records.append(
            {
                "season": int(season),
                "file": file_name,
                "rows": int(len(export)),
                "columns": int(len(export.columns)),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    return records


def find_forbidden_release_files(root: Path) -> list[str]:
    """Return provider raw archives/CSVs that must not enter the release bundle."""
    root = Path(root)
    forbidden = []
    prefixes = ("nbastatsv3_", "shotdetail_")
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        name = path.name.lower()
        if name.startswith(prefixes) and name.endswith((".csv", ".tar.xz", ".zip")):
            forbidden.append(path.relative_to(root).as_posix())
    return forbidden
