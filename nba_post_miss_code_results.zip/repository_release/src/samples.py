"""Auditable main and sensitivity sample construction."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from .config import StudyConfig


@dataclass(frozen=True, slots=True)
class ExclusionStep:
    reason: str
    excluded_n: int
    remaining_n: int


@dataclass(frozen=True, slots=True)
class ExclusionFlow:
    initial_n: int
    retained_n: int
    steps: tuple[ExclusionStep, ...]

    def to_frame(self) -> pd.DataFrame:
        return pd.DataFrame(
            [
                {
                    "reason": step.reason,
                    "excluded_n": step.excluded_n,
                    "remaining_n": step.remaining_n,
                }
                for step in self.steps
            ]
        )


def _masks(df: pd.DataFrame) -> dict[str, pd.Series]:
    required_key = ["game_id", "action_number", "period", "clock_seconds", "team_id", "player_id"]
    return {
        "missing_event_key": df[required_key].isna().any(axis=1),
        "missing_pre_shot_state": df[["pre_score_home", "pre_score_away"]].isna().any(axis=1),
        "missing_shot_location": df[
            ["shot_distance_feet", "loc_x", "loc_y", "is_home_offense"]
        ].isna().any(axis=1),
        "no_same_period_personal_lag": df["previous_personal_action_number"].isna(),
        "missing_previous_personal_shot_distance": df[
            "previous_personal_shot_distance_feet"
        ].isna(),
        "offensive_rebound_continuation": df["offensive_rebound_continuation"].fillna(False).astype(bool),
        "putback_within_one_second": df["putback_within_one_second"].fillna(False).astype(bool),
        "heave_proxy": df["heave_proxy"].fillna(False).astype(bool),
    }


def _apply_exclusions(
    df: pd.DataFrame, reasons: tuple[str, ...]
) -> tuple[pd.DataFrame, ExclusionFlow]:
    masks = _masks(df)
    remaining = pd.Series(True, index=df.index)
    assigned = pd.Series("", index=df.index, dtype="string")
    steps: list[ExclusionStep] = []
    for reason in reasons:
        newly_excluded = remaining & masks[reason]
        assigned.loc[newly_excluded] = reason
        remaining &= ~newly_excluded
        steps.append(
            ExclusionStep(
                reason=reason,
                excluded_n=int(newly_excluded.sum()),
                remaining_n=int(remaining.sum()),
            )
        )
    assigned.loc[remaining] = "retained"
    if assigned.eq("").any():
        raise RuntimeError("every row must receive an exclusion status")
    sample = df.loc[remaining].copy()
    sample["exclusion_reason"] = "retained"
    flow = ExclusionFlow(initial_n=len(df), retained_n=len(sample), steps=tuple(steps))
    if sum(step.excluded_n for step in steps) + flow.retained_n != flow.initial_n:
        raise RuntimeError("exclusion flow does not reconcile")
    return sample, flow


def build_main_sample(df: pd.DataFrame, config: StudyConfig) -> tuple[pd.DataFrame, ExclusionFlow]:
    return _apply_exclusions(df, config.main_exclusions)


def build_sensitivity_samples(df: pd.DataFrame, config: StudyConfig) -> dict[str, pd.DataFrame]:
    main, _ = build_main_sample(df, config)
    without_continuation_rule = tuple(
        reason for reason in config.main_exclusions if reason != "offensive_rebound_continuation"
    )
    putback_only = tuple(
        "putback_within_one_second" if reason == "offensive_rebound_continuation" else reason
        for reason in config.main_exclusions
    )
    include_rebounds, _ = _apply_exclusions(df, without_continuation_rule)
    exclude_putbacks, _ = _apply_exclusions(df, putback_only)
    return {
        "main": main,
        "include_offensive_rebounds": include_rebounds,
        "exclude_putbacks_only": exclude_putbacks,
    }
