"""Immutable configuration contract for the NBA post-miss study."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class ConfigError(ValueError):
    """Raised when a study configuration violates the frozen contract."""


def _tuple_int(values: Any, field: str) -> tuple[int, ...]:
    if not isinstance(values, list) or not all(isinstance(value, int) for value in values):
        raise ConfigError(f"{field} must be a list of integers")
    return tuple(values)


def _tuple_str(values: Any, field: str) -> tuple[str, ...]:
    if not isinstance(values, list) or not all(isinstance(value, str) for value in values):
        raise ConfigError(f"{field} must be a list of strings")
    return tuple(values)


@dataclass(frozen=True, slots=True)
class StudyConfig:
    study_id: str
    version: str
    freeze_status: str
    confirmation_seasons: tuple[int, ...]
    pilot_seasons: tuple[int, ...]
    data_families: tuple[str, ...]
    regular_season_only: bool
    critical_period: int
    critical_clock_seconds_max: float
    critical_abs_margin_max: int
    continuous_criticality_clock_scale: float
    continuous_criticality_margin_scale: float
    heave_periods: tuple[int, ...]
    heave_clock_seconds_max: float
    heave_distance_feet_min: float
    main_lag_definition: str
    allow_cross_period_personal_lag: bool
    main_exclusions: tuple[str, ...]
    primary_outcomes: tuple[str, ...]
    secondary_outcomes: tuple[str, ...]
    baseline_controls: tuple[str, ...]
    remaining_period_seconds_knots: tuple[int, ...]
    absolute_margin_knots: tuple[int, ...]
    personal_interval_seconds_knots: tuple[int, ...]
    fixed_effects: tuple[str, ...]
    cluster_groups: tuple[str, ...]
    hypothesis_h1_direction: str
    hypothesis_h2_direction: str
    audit_allowed_before_freeze: bool
    pilot_models_allowed_before_freeze: bool
    confirmation_models_allowed_before_freeze: bool
    confirmation_models_allowed_after_freeze: bool

    @property
    def all_seasons(self) -> tuple[int, ...]:
        return self.confirmation_seasons + self.pilot_seasons


def load_config(path: Path) -> StudyConfig:
    """Load and validate the preregistered JSON configuration."""

    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    seasons = raw["seasons"]
    source = raw["data_source"]
    critical = raw["criticality"]
    heave = raw["heave_proxy"]
    lag = raw["main_lag"]
    outcomes = raw["outcomes"]
    controls = raw["controls"]
    model = raw["main_model"]
    permissions = raw["stage_permissions"]

    config = StudyConfig(
        study_id=str(raw["study_id"]),
        version=str(raw["version"]),
        freeze_status=str(raw["freeze_status"]),
        confirmation_seasons=_tuple_int(seasons["confirmation"], "seasons.confirmation"),
        pilot_seasons=_tuple_int(seasons["pilot"], "seasons.pilot"),
        data_families=_tuple_str(source["families"], "data_source.families"),
        regular_season_only=bool(source["regular_season_only"]),
        critical_period=int(critical["period"]),
        critical_clock_seconds_max=float(critical["clock_seconds_max"]),
        critical_abs_margin_max=int(critical["absolute_pre_shot_margin_max"]),
        continuous_criticality_clock_scale=float(critical["continuous_clock_scale"]),
        continuous_criticality_margin_scale=float(critical["continuous_margin_scale"]),
        heave_periods=_tuple_int(heave["periods"], "heave_proxy.periods"),
        heave_clock_seconds_max=float(heave["clock_seconds_max"]),
        heave_distance_feet_min=float(heave["distance_feet_min"]),
        main_lag_definition=str(lag["definition"]),
        allow_cross_period_personal_lag=bool(lag["allow_cross_period"]),
        main_exclusions=_tuple_str(raw["main_exclusions"], "main_exclusions"),
        primary_outcomes=_tuple_str(outcomes["primary"], "outcomes.primary"),
        secondary_outcomes=_tuple_str(outcomes["secondary"], "outcomes.secondary"),
        baseline_controls=_tuple_str(controls["baseline"], "controls.baseline"),
        remaining_period_seconds_knots=_tuple_int(
            controls["nonlinear_knots"]["remaining_period_seconds"],
            "controls.nonlinear_knots.remaining_period_seconds",
        ),
        absolute_margin_knots=_tuple_int(
            controls["nonlinear_knots"]["absolute_margin"],
            "controls.nonlinear_knots.absolute_margin",
        ),
        personal_interval_seconds_knots=_tuple_int(
            controls["nonlinear_knots"]["personal_interval_seconds"],
            "controls.nonlinear_knots.personal_interval_seconds",
        ),
        fixed_effects=_tuple_str(model["fixed_effects"], "main_model.fixed_effects"),
        cluster_groups=_tuple_str(model["cluster_groups"], "main_model.cluster_groups"),
        hypothesis_h1_direction=str(model["hypotheses"]["h1"]),
        hypothesis_h2_direction=str(model["hypotheses"]["h2"]),
        audit_allowed_before_freeze=bool(permissions["audit_before_freeze"]),
        pilot_models_allowed_before_freeze=bool(permissions["pilot_models_before_freeze"]),
        confirmation_models_allowed_before_freeze=bool(
            permissions["confirmation_h1_h2_before_freeze"]
        ),
        confirmation_models_allowed_after_freeze=bool(
            permissions["confirmation_h1_h2_after_freeze"]
        ),
    )
    _validate(config)
    return config


def _validate(config: StudyConfig) -> None:
    overlap = set(config.confirmation_seasons) & set(config.pilot_seasons)
    if overlap:
        raise ConfigError(f"pilot and confirmation seasons overlap: {sorted(overlap)}")
    if config.primary_outcomes != ("shot_distance_feet",):
        raise ConfigError("shot_distance_feet must be the sole confirmatory primary outcome")
    if config.allow_cross_period_personal_lag:
        raise ConfigError("cross-period personal lags are forbidden")
    if config.main_lag_definition != "same_player_same_game_same_period_prior_fga":
        raise ConfigError("main personal-lag definition has changed")
    if (config.critical_period, config.critical_clock_seconds_max, config.critical_abs_margin_max) != (
        4,
        300.0,
        5,
    ):
        raise ConfigError("primary criticality thresholds have changed")
    if config.confirmation_models_allowed_before_freeze:
        raise ConfigError("confirmation H1/H2 models cannot run before freeze")
    if not config.confirmation_models_allowed_after_freeze:
        raise ConfigError("confirmation H1/H2 models must be enabled after a valid freeze")

