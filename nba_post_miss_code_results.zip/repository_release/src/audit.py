"""Outcome-blind integrity audits for NBA play-by-play and shot-detail files."""

from __future__ import annotations

import argparse
from dataclasses import dataclass, fields
from pathlib import Path

import numpy as np
import pandas as pd

from .config import load_config


@dataclass(frozen=True, slots=True)
class AuditResult:
    season_start: int
    pbp_rows: int
    pbp_fga_rows: int
    shot_rows: int
    pbp_games: int
    shot_games: int
    game_date_min: str
    game_date_max: str
    duplicate_pbp_fga_key_rows: int
    duplicate_shot_key_rows: int
    matched_unique_keys: int
    pbp_only_unique_keys: int
    shot_only_unique_keys: int
    unique_key_join_rate: float
    player_id_disagreement_rows: int
    team_id_disagreement_rows: int
    missing_clock_rows: int
    missing_score_rows: int
    missing_location_rows: int
    score_nonmonotonic_rows: int
    score_jump_gt4_rows: int
    anomalies: pd.DataFrame

    def to_record(self) -> dict[str, object]:
        return {field.name: getattr(self, field.name) for field in fields(self) if field.name != "anomalies"}


def _anomaly_rows(
    frame: pd.DataFrame,
    category: str,
    game_col: str,
    action_col: str,
    detail: str,
    season: int,
) -> list[dict[str, object]]:
    return [
        {
            "season_start": season,
            "category": category,
            "game_id": row[game_col],
            "action_number": row[action_col],
            "detail": detail,
        }
        for _, row in frame.iterrows()
    ]


def _score_consistency(pbp: pd.DataFrame) -> tuple[int, int]:
    required = {"gameId", "scoreHome", "scoreAway"}
    if not required.issubset(pbp.columns):
        return 0, 0
    if "pointsTotal" in pbp.columns:
        scoring_mask = pd.to_numeric(pbp["pointsTotal"], errors="coerce").gt(0)
    else:
        scoring_mask = pd.Series(True, index=pbp.index)
    scored = pbp.loc[scoring_mask, ["gameId", "scoreHome", "scoreAway"]].copy()
    scored[["scoreHome", "scoreAway"]] = scored[["scoreHome", "scoreAway"]].apply(
        pd.to_numeric, errors="coerce"
    )
    scored = scored.dropna(subset=["scoreHome", "scoreAway"])
    deltas = scored.groupby("gameId", sort=False)[["scoreHome", "scoreAway"]].diff()
    nonmonotonic = int((deltas < 0).any(axis=1).sum())
    jump_gt4 = int((deltas > 4).any(axis=1).sum())
    return nonmonotonic, jump_gt4


def audit_season(pbp_path: Path, shot_path: Path, season: int) -> AuditResult:
    pbp = pd.read_csv(pbp_path, low_memory=False)
    shots = pd.read_csv(shot_path, low_memory=False)
    pbp_fga = pbp.loc[pd.to_numeric(pbp["isFieldGoal"], errors="coerce").eq(1)].copy()
    if "SHOT_ATTEMPTED_FLAG" in shots:
        shots = shots.loc[pd.to_numeric(shots["SHOT_ATTEMPTED_FLAG"], errors="coerce").eq(1)].copy()

    pbp_key = ["gameId", "actionNumber"]
    shot_key = ["GAME_ID", "GAME_EVENT_ID"]
    dup_pbp_mask = pbp_fga.duplicated(pbp_key, keep=False)
    dup_shot_mask = shots.duplicated(shot_key, keep=False)
    anomalies: list[dict[str, object]] = []
    anomalies.extend(
        _anomaly_rows(
            pbp_fga.loc[dup_pbp_mask],
            "duplicate_pbp_fga_key",
            "gameId",
            "actionNumber",
            "duplicate play-by-play field-goal key",
            season,
        )
    )
    anomalies.extend(
        _anomaly_rows(
            shots.loc[dup_shot_mask],
            "duplicate_shot_key",
            "GAME_ID",
            "GAME_EVENT_ID",
            "duplicate shot-detail key",
            season,
        )
    )

    pbp_distinct_keys = pbp_fga.loc[:, pbp_key].drop_duplicates().copy()
    shot_distinct_keys = shots.loc[:, shot_key].drop_duplicates().copy()
    joined = pbp_distinct_keys.merge(
        shot_distinct_keys,
        how="outer",
        left_on=pbp_key,
        right_on=shot_key,
        indicator=True,
    )
    pbp_only = joined.loc[joined["_merge"].eq("left_only")]
    shot_only = joined.loc[joined["_merge"].eq("right_only")]
    matched_keys = joined.loc[joined["_merge"].eq("both")].copy()
    anomalies.extend(
        _anomaly_rows(
            pbp_only,
            "pbp_only_key",
            "gameId",
            "actionNumber",
            "field-goal key absent from shot detail",
            season,
        )
    )
    anomalies.extend(
        _anomaly_rows(
            shot_only,
            "shot_only_key",
            "GAME_ID",
            "GAME_EVENT_ID",
            "shot-detail key absent from play-by-play field goals",
            season,
        )
    )

    pbp_one_to_one = pbp_fga.drop_duplicates(pbp_key, keep=False).copy()
    shot_one_to_one = shots.drop_duplicates(shot_key, keep=False).copy()
    matched = pbp_one_to_one.merge(
        shot_one_to_one,
        how="inner",
        left_on=pbp_key,
        right_on=shot_key,
        suffixes=("_pbp", "_shot"),
    )
    player_disagree = matched["personId"].astype("Int64").ne(matched["PLAYER_ID"].astype("Int64"))
    team_disagree = matched["teamId"].astype("Int64").ne(matched["TEAM_ID"].astype("Int64"))
    for mask, category, detail in (
        (player_disagree, "player_id_disagreement", "player identifiers disagree"),
        (team_disagree, "team_id_disagreement", "team identifiers disagree"),
    ):
        anomalies.extend(
            _anomaly_rows(matched.loc[mask.fillna(True)], category, "gameId", "actionNumber", detail, season)
        )

    denominator = len(pbp_distinct_keys) + len(shot_distinct_keys) - len(matched_keys)
    join_rate = float(len(matched_keys) / denominator) if denominator else float("nan")
    nonmonotonic, jump_gt4 = _score_consistency(pbp)
    date_values = pd.to_datetime(shots.get("GAME_DATE"), format="%Y%m%d", errors="coerce")
    anomaly_frame = pd.DataFrame.from_records(
        anomalies,
        columns=["season_start", "category", "game_id", "action_number", "detail"],
    )

    return AuditResult(
        season_start=season,
        pbp_rows=len(pbp),
        pbp_fga_rows=len(pbp_fga),
        shot_rows=len(shots),
        pbp_games=int(pbp["gameId"].nunique()),
        shot_games=int(shots["GAME_ID"].nunique()),
        game_date_min=date_values.min().date().isoformat() if date_values.notna().any() else "",
        game_date_max=date_values.max().date().isoformat() if date_values.notna().any() else "",
        duplicate_pbp_fga_key_rows=int(dup_pbp_mask.sum()),
        duplicate_shot_key_rows=int(dup_shot_mask.sum()),
        matched_unique_keys=len(matched_keys),
        pbp_only_unique_keys=len(pbp_only),
        shot_only_unique_keys=len(shot_only),
        unique_key_join_rate=join_rate,
        player_id_disagreement_rows=int(player_disagree.fillna(True).sum()),
        team_id_disagreement_rows=int(team_disagree.fillna(True).sum()),
        missing_clock_rows=int(pbp_fga["clock"].isna().sum()),
        missing_score_rows=int(pbp_fga[["scoreHome", "scoreAway"]].isna().any(axis=1).sum()),
        missing_location_rows=int(shots[["LOC_X", "LOC_Y", "SHOT_DISTANCE"]].isna().any(axis=1).sum()),
        score_nonmonotonic_rows=nonmonotonic,
        score_jump_gt4_rows=jump_gt4,
        anomalies=anomaly_frame,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    results: list[AuditResult] = []
    for season in config.all_seasons:
        results.append(
            audit_season(
                args.raw_dir / f"nbastatsv3_{season}.csv",
                args.raw_dir / f"shotdetail_{season}.csv",
                season,
            )
        )
    pd.DataFrame([result.to_record() for result in results]).to_csv(
        args.out_dir / "data_audit.csv", index=False
    )
    anomaly_frames = [result.anomalies for result in results if not result.anomalies.empty]
    anomalies = (
        pd.concat(anomaly_frames, ignore_index=True)
        if anomaly_frames
        else pd.DataFrame(columns=["season_start", "category", "game_id", "action_number", "detail"])
    )
    anomalies.to_csv(args.out_dir / "data_anomalies.csv", index=False)
    print(f"Audited {len(results)} seasons; anomalies: {len(anomalies)}")


if __name__ == "__main__":
    main()
