"""Personal, team, and global shot lags plus between-shot event flags."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


def _ordered(shots: pd.DataFrame) -> pd.DataFrame:
    return shots.sort_values(
        ["game_id", "period", "clock_seconds", "event_order", "action_number"],
        ascending=[True, True, False, True, True],
        kind="stable",
    ).reset_index(drop=True)


def add_personal_lag(shots: pd.DataFrame) -> pd.DataFrame:
    result = _ordered(shots)
    groups = result.groupby(["game_id", "period", "player_id"], sort=False, dropna=False)
    result["previous_personal_action_number"] = groups["action_number"].shift()
    result["previous_personal_shot_made"] = groups["shot_made"].shift()
    result["previous_personal_shot_distance_feet"] = groups["shot_distance_feet"].shift()
    previous_clock = groups["clock_seconds"].shift()
    result["previous_personal_clock_seconds"] = previous_clock
    result["previous_personal_event_order"] = groups["event_order"].shift()
    for source, target in (
        ("pre_score_home", "previous_personal_pre_score_home"),
        ("pre_score_away", "previous_personal_pre_score_away"),
        ("is_home_offense", "previous_personal_is_home_offense"),
    ):
        if source in result:
            result[target] = groups[source].shift()
    result["personal_interval_seconds"] = previous_clock - result["clock_seconds"]
    result["previous_personal_miss"] = (1.0 - result["previous_personal_shot_made"]).where(
        result["previous_personal_shot_made"].notna()
    )
    return result


def add_personal_interval_flags(shots: pd.DataFrame, events: pd.DataFrame) -> pd.DataFrame:
    """Flag timeouts and bench intervals between each player's same-period shots."""

    result = _ordered(shots)
    result["_shot_row"] = np.arange(len(result), dtype=np.int64)
    ordered_events = events.sort_values(["game_id", "event_order"], kind="stable").copy()
    action = ordered_events["action_type"].fillna("").astype(str).str.casefold()
    ordered_events["_timeout_count"] = action.eq("timeout").groupby(
        ordered_events["game_id"], sort=False
    ).cumsum()
    fga_events = ordered_events.loc[
        pd.to_numeric(ordered_events["is_field_goal"], errors="coerce").eq(1),
        ["game_id", "event_order", "_timeout_count"],
    ]
    result = result.merge(
        fga_events,
        how="left",
        on=["game_id", "event_order"],
        validate="one_to_one",
    )

    shot_activity = result.loc[:, ["game_id", "player_id", "event_order", "_shot_row"]].copy()
    shot_activity["_is_subout"] = 0
    shot_activity["_activity_kind"] = 1
    substitutions = ordered_events.loc[
        action.eq("substitution") & pd.to_numeric(ordered_events["player_id"], errors="coerce").gt(0),
        ["game_id", "player_id", "event_order"],
    ].copy()
    substitutions["_shot_row"] = np.nan
    substitutions["_is_subout"] = 1
    substitutions["_activity_kind"] = 0
    activity = pd.concat([shot_activity, substitutions], ignore_index=True, sort=False)
    activity = activity.sort_values(
        ["game_id", "player_id", "event_order", "_activity_kind"], kind="stable"
    )
    activity["_subout_count"] = activity.groupby(
        ["game_id", "player_id"], sort=False, dropna=False
    )["_is_subout"].cumsum()
    shot_counts = activity.loc[activity["_shot_row"].notna(), ["_shot_row", "_subout_count"]].copy()
    shot_counts["_shot_row"] = shot_counts["_shot_row"].astype(np.int64)
    result = result.merge(shot_counts, how="left", on="_shot_row", validate="one_to_one")

    groups = result.groupby(["game_id", "period", "player_id"], sort=False, dropna=False)
    previous_timeout_count = groups["_timeout_count"].shift()
    previous_subout_count = groups["_subout_count"].shift()
    has_previous = groups["action_number"].shift().notna()
    timeout_between = result["_timeout_count"].sub(previous_timeout_count).gt(0) & has_previous
    subout_between = result["_subout_count"].sub(previous_subout_count).gt(0) & has_previous
    result["timeout_between_personal_shots"] = timeout_between
    result["substitution_out_between_personal_shots"] = subout_between
    result["bench_return"] = subout_between
    result["same_stint"] = (~subout_between).where(has_previous)
    result["no_timeout_between_personal_shots"] = (~timeout_between).where(has_previous)
    return result.drop(columns=["_shot_row", "_timeout_count", "_subout_count"])


def add_team_lag(shots: pd.DataFrame) -> pd.DataFrame:
    result = _ordered(shots)
    groups = result.groupby(["game_id", "period", "team_id"], sort=False, dropna=False)
    result["previous_team_action_number"] = groups["action_number"].shift()
    result["previous_team_shot_made"] = groups["shot_made"].shift()
    result["previous_team_player_id"] = groups["player_id"].shift()
    result["previous_team_event_order"] = groups["event_order"].shift()
    return result


def add_global_lag(shots: pd.DataFrame) -> pd.DataFrame:
    result = _ordered(shots)
    groups = result.groupby("game_id", sort=False, dropna=False)
    result["previous_global_action_number"] = groups["action_number"].shift()
    result["previous_global_shot_made"] = groups["shot_made"].shift()
    result["previous_global_player_id"] = groups["player_id"].shift()
    result["previous_global_team_id"] = groups["team_id"].shift()
    relation = np.select(
        [
            result["previous_global_player_id"].eq(result["player_id"]),
            result["previous_global_team_id"].eq(result["team_id"]),
            result["previous_global_action_number"].notna(),
        ],
        ["self", "teammate", "opponent"],
        default=None,
    )
    result["previous_global_relation"] = relation
    return result


def add_global_interval_flags(shots: pd.DataFrame, events: pd.DataFrame) -> pd.DataFrame:
    """Annotate each shot from events since the immediately preceding FGA."""

    ordered_events = events.sort_values(["game_id", "event_order"], kind="stable").copy()
    is_fga = pd.to_numeric(ordered_events["is_field_goal"], errors="coerce").eq(1)
    ordered_events["_interval_id"] = is_fga.groupby(ordered_events["game_id"], sort=False).cumsum()
    between = ordered_events.loc[~is_fga].copy()
    action = between["action_type"].fillna("").astype(str).str.casefold()
    between["_rebound_team"] = pd.to_numeric(between["team_id"], errors="coerce").where(
        action.eq("rebound")
    )
    between["_rebound_clock"] = between["clock_seconds"].where(action.eq("rebound"))
    between["_timeout"] = action.eq("timeout")
    between["_turnover"] = action.eq("turnover")
    interval = (
        between.groupby(["game_id", "_interval_id"], sort=False, as_index=False)
        .agg(
            first_rebound_team=("_rebound_team", "first"),
            first_rebound_clock=("_rebound_clock", "first"),
            timeout_between_global_shots=("_timeout", "max"),
            turnover_between_global_shots=("_turnover", "max"),
        )
    )

    result = _ordered(shots)
    game_groups = result.groupby("game_id", sort=False, dropna=False)
    result["_interval_id"] = game_groups.cumcount()
    result["previous_global_team_id"] = game_groups["team_id"].shift()
    result["previous_global_shot_made"] = game_groups["shot_made"].shift()
    result["previous_global_period"] = game_groups["period"].shift()
    result = result.merge(interval, how="left", on=["game_id", "_interval_id"], validate="many_to_one")
    has_previous = result["previous_global_team_id"].notna()
    same_team = result["team_id"].eq(result["previous_global_team_id"])
    same_period = result["period"].eq(result["previous_global_period"])
    previous_miss = result["previous_global_shot_made"].eq(0)
    result["offensive_rebound_continuation"] = (
        has_previous
        & same_period
        & same_team
        & previous_miss
        & result["first_rebound_team"].eq(result["previous_global_team_id"])
    )
    rebound_to_shot = result["first_rebound_clock"] - result["clock_seconds"]
    result["putback_within_one_second"] = result["offensive_rebound_continuation"] & rebound_to_shot.between(
        0, 1, inclusive="both"
    )
    result["timeout_between_global_shots"] = (
        result["timeout_between_global_shots"].fillna(False).astype(bool) & has_previous
    )
    result["turnover_between_global_shots"] = (
        result["turnover_between_global_shots"].fillna(False).astype(bool) & has_previous
    )
    result["possession_reset"] = has_previous & (
        ~same_period
        | ~same_team
        | result["previous_global_shot_made"].eq(1)
        | result["turnover_between_global_shots"]
        | ~result["offensive_rebound_continuation"]
    )
    return result.drop(columns=["_interval_id"])


@dataclass(frozen=True, slots=True)
class IntervalFlags:
    offensive_rebound_continuation: bool
    putback_within_one_second: bool
    possession_reset: bool
    timeout_between: bool
    substitution_out_between: bool
    substitution_in_between: bool
    bench_return: bool
    same_stint: bool
    elapsed_game_seconds: float
    events_between: int


def _event_elapsed(period: int, clock_seconds: float) -> float:
    elapsed = 0.0
    for earlier_period in range(1, int(period)):
        elapsed += 720.0 if earlier_period <= 4 else 300.0
    duration = 720.0 if int(period) <= 4 else 300.0
    return elapsed + duration - float(clock_seconds)


def classify_interval(
    events: pd.DataFrame,
    previous_shot: pd.Series | dict[str, object],
    current_shot: pd.Series | dict[str, object],
) -> IntervalFlags:
    previous = pd.Series(previous_shot)
    current = pd.Series(current_shot)
    if previous["game_id"] != current["game_id"]:
        raise ValueError("shots must belong to the same game")
    elapsed = _event_elapsed(int(current["period"]), float(current["clock_seconds"])) - _event_elapsed(
        int(previous["period"]), float(previous["clock_seconds"])
    )
    if elapsed < 0:
        raise ValueError("current shot precedes previous shot")

    between = events.loc[
        events["game_id"].eq(current["game_id"])
        & events["event_order"].gt(previous["event_order"])
        & events["event_order"].lt(current["event_order"])
    ].copy()
    action = between["action_type"].fillna("").astype(str).str.casefold()
    description = between["description"].fillna("").astype(str).str.casefold()
    team = pd.to_numeric(between["team_id"], errors="coerce")
    prior_team = int(previous["team_id"])
    player_id = int(current["player_id"])
    player_name = str(current.get("player_name", "")).strip().casefold()

    offensive_rebound = action.eq("rebound") & description.str.contains("off:1", regex=False) & team.eq(
        prior_team
    )
    defensive_rebound_by_opponent = (
        action.eq("rebound")
        & description.str.contains("def:1", regex=False)
        & team.ne(prior_team)
        & team.notna()
    )
    turnover_by_prior_team = action.eq("turnover") & team.eq(prior_team)
    opponent_fga = (
        pd.to_numeric(between["is_field_goal"], errors="coerce").eq(1)
        & team.ne(prior_team)
        & team.notna()
    )
    substitutions = action.eq("substitution")
    substitution_out = substitutions & pd.to_numeric(between["player_id"], errors="coerce").eq(player_id)
    substitution_in = substitutions & description.str.startswith(f"sub: {player_name} for")

    continuation = bool(offensive_rebound.any()) and not bool(
        (defensive_rebound_by_opponent | turnover_by_prior_team | opponent_fga).any()
    )
    timeout = bool(action.eq("timeout").any())
    sub_out = bool(substitution_out.any())
    sub_in = bool(substitution_in.any())
    reset = bool((defensive_rebound_by_opponent | turnover_by_prior_team | opponent_fga).any())
    return IntervalFlags(
        offensive_rebound_continuation=continuation,
        putback_within_one_second=continuation and elapsed <= 1.0,
        possession_reset=reset,
        timeout_between=timeout,
        substitution_out_between=sub_out,
        substitution_in_between=sub_in,
        bench_return=sub_out and sub_in,
        same_stint=not sub_out,
        elapsed_game_seconds=float(elapsed),
        events_between=len(between),
    )
