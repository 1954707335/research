"""Registered post-freeze pooled, robustness, social-context, and meta analyses.

This module was added after the sealed confirmation run.  It validates the
pre-confirmation freeze and treats the two confirmation artifacts as immutable
inputs; it never overwrites them or changes any frozen dependency.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

from .acquire import calculate_sha256
from .config import StudyConfig, load_config
from .estimators import ModelResult, fit_hdfe_ols
from .events import build_shot_events, canonicalize_pbp_events
from .features import add_game_state_features
from .meta import reml_meta
from .pipeline import assert_confirmation_allowed, primary_predictors, validate_raw_manifest
from .samples import build_main_sample
from .sequences import (
    add_global_interval_flags,
    add_global_lag,
    add_personal_interval_flags,
    add_personal_lag,
    add_team_lag,
)


@dataclass(frozen=True, slots=True)
class AnalysisSpec:
    analysis_id: str
    status: str
    sample: str
    outcome: str
    target_terms: tuple[str, ...]
    fixed_effects: tuple[str, ...] = ("player_id_x_season", "game_id")
    clusters: tuple[str, ...] = ("game_id", "player_id")
    multiplicity_family: str = "none"
    description: str = ""


def _spec(
    analysis_id: str,
    status: str,
    sample: str,
    outcome: str = "shot_distance_feet",
    target_terms: tuple[str, ...] = ("previous_personal_miss", "post_miss_x_critical"),
    family: str = "none",
    description: str = "",
) -> AnalysisSpec:
    return AnalysisSpec(
        analysis_id=analysis_id,
        status=status,
        sample=sample,
        outcome=outcome,
        target_terms=target_terms,
        multiplicity_family=family,
        description=description,
    )


ANALYSIS_REGISTRY: tuple[AnalysisSpec, ...] = (
    _spec("confirmation_h1", "confirmatory", "held-out 2016-2021 sealed result", target_terms=("previous_personal_miss",)),
    _spec("confirmation_h2", "confirmatory", "held-out 2016-2021 sealed result", target_terms=("post_miss_x_critical",)),
    _spec("pooled_eight_season", "secondary", "all eight seasons", family="pooled_secondary"),
    _spec("season_specific", "secondary", "one model per season", family="seasonal_secondary"),
    _spec("critical_2min_margin3", "secondary", "main sample", target_terms=("post_miss_x_critical_alt",), family="criticality_secondary"),
    _spec("critical_5min_margin3", "secondary", "main sample", target_terms=("post_miss_x_critical_alt",), family="criticality_secondary"),
    _spec("critical_5min_margin8", "secondary", "main sample", target_terms=("post_miss_x_critical_alt",), family="criticality_secondary"),
    _spec("continuous_criticality", "secondary", "main sample", target_terms=("post_miss_x_continuous_criticality",), family="criticality_secondary"),
    _spec("previous_shot_criticality", "secondary", "main sample", target_terms=("post_miss_x_previous_critical",), family="classification_secondary"),
    _spec("stable_critical_status", "secondary", "current and previous personal shots share critical status", family="classification_secondary"),
    _spec("interval_le_120", "secondary", "personal-shot interval at most 120 seconds", family="interval_secondary"),
    _spec("same_stint", "secondary", "no recorded substitution-out between personal shots", family="interval_secondary"),
    _spec("no_timeout", "secondary", "no timeout between personal shots", family="interval_secondary"),
    _spec("no_pandemic", "secondary", "exclude 2019-20 and 2020-21", family="season_secondary"),
    _spec("include_offensive_rebounds", "secondary", "include offensive-rebound continuations", family="putback_secondary"),
    _spec("exclude_putbacks_only", "secondary", "exclude only putbacks within one second", family="putback_secondary"),
    _spec("period_end_2s", "secondary", "exclude every period's last 2 seconds", family="period_end_secondary"),
    _spec("period_end_5s", "secondary", "exclude every period's last 5 seconds", family="period_end_secondary"),
    _spec("margin_leading", "exploratory", "offense leading before current shot", family="game_state_exploratory"),
    _spec("margin_tied", "exploratory", "score tied before current shot", family="game_state_exploratory"),
    _spec("margin_trailing", "exploratory", "offense trailing before current shot", family="game_state_exploratory"),
    _spec("q3_placebo", "exploratory", "third-quarter matched window", target_terms=("post_miss_x_q3_placebo",), family="placebo_exploratory"),
    _spec("team_lag", "secondary", "same-team previous FGA", target_terms=("previous_team_miss", "post_team_miss_x_critical"), family="social_secondary"),
    _spec(
        "global_social_replication",
        "secondary",
        "immediately preceding global FGA in same period",
        target_terms=("previous_global_miss", "global_miss_x_teammate", "global_miss_x_opponent", "global_miss_x_critical", "global_miss_x_teammate_x_critical"),
        family="social_secondary",
        description="Joint self/teammate/opponent model; teammate coefficients are direct differences from self.",
    ),
    _spec("three_point_secondary", "secondary", "main sample", outcome="is_three_point_attempt", family="outcome_secondary"),
    _spec("leave_one_season_out", "exploratory", "eight leave-one-season-out models", target_terms=("post_miss_x_critical",), family="influence_exploratory"),
    _spec("leave_one_team_out", "exploratory", "one model excluding each offense team", target_terms=("post_miss_x_critical",), family="influence_exploratory"),
    _spec("high_volume_player_influence", "exploratory", "one model excluding each of ten highest-volume players", target_terms=("post_miss_x_critical",), family="influence_exploratory"),
)


def analysis_required_columns() -> tuple[str, ...]:
    """Columns retained in the post-freeze cache to cap peak memory use."""

    return (
        "game_id", "action_number", "period", "clock_seconds", "team_id", "player_id",
        "season", "player_id_x_season", "pre_score_home", "pre_score_away",
        "shot_distance_feet", "loc_x", "loc_y", "is_home_offense", "shot_made",
        "previous_personal_action_number", "previous_personal_shot_distance_feet",
        "previous_personal_miss", "previous_personal_critical", "stable_critical_status",
        "personal_interval_seconds", "same_stint", "no_timeout_between_personal_shots",
        "offensive_rebound_continuation", "putback_within_one_second", "heave_proxy",
        "home_pre_shot_margin", "offense_signed_pre_shot_margin", "absolute_pre_shot_margin",
        "remaining_period_seconds", "remaining_game_seconds", "critical",
        "post_miss_x_critical", "continuous_criticality",
        "post_miss_x_continuous_criticality", "is_three_point_attempt",
        "remaining_period_seconds_spline_60", "remaining_period_seconds_spline_120",
        "remaining_period_seconds_spline_300", "remaining_period_seconds_spline_480",
        "absolute_pre_shot_margin_spline_3", "absolute_pre_shot_margin_spline_5",
        "absolute_pre_shot_margin_spline_10", "absolute_pre_shot_margin_spline_20",
        "personal_interval_seconds_spline_30", "personal_interval_seconds_spline_60",
        "personal_interval_seconds_spline_120", "personal_interval_seconds_spline_300",
        "previous_team_shot_made", "previous_team_shot_distance_feet",
        "previous_team_clock_seconds", "team_interval_seconds", "previous_team_miss",
        "post_team_miss_x_critical", "previous_global_shot_made",
        "previous_global_shot_distance_feet", "previous_global_clock_seconds",
        "previous_global_period", "previous_global_relation", "previous_global_miss",
        "global_rel_teammate", "global_rel_opponent", "global_miss_x_teammate",
        "global_miss_x_opponent", "global_miss_x_critical", "teammate_x_critical",
        "opponent_x_critical", "global_miss_x_teammate_x_critical",
        "global_miss_x_opponent_x_critical",
    )


def validate_registry(registry: Sequence[AnalysisSpec]) -> None:
    if not registry:
        raise ValueError("analysis registry cannot be empty")
    identifiers = [entry.analysis_id for entry in registry]
    if len(identifiers) != len(set(identifiers)):
        raise ValueError("analysis identifiers must be unique")
    for entry in registry:
        if entry.status not in {"confirmatory", "secondary", "exploratory"}:
            raise ValueError(f"invalid status for {entry.analysis_id}")
        if not all((entry.sample, entry.outcome, entry.target_terms, entry.fixed_effects, entry.clusters)):
            raise ValueError(f"incomplete registry entry: {entry.analysis_id}")


def adjust_p_values(p_values: Sequence[float], method: str) -> np.ndarray:
    values = np.asarray(p_values, dtype=float)
    if values.ndim != 1 or not np.isfinite(values).all() or ((values < 0) | (values > 1)).any():
        raise ValueError("p-values must be a finite one-dimensional vector in [0, 1]")
    count = len(values)
    if count == 0:
        return values.copy()
    order = np.argsort(values, kind="stable")
    ranked = values[order]
    if method == "holm":
        adjusted_ranked = np.maximum.accumulate((count - np.arange(count)) * ranked)
    elif method == "fdr_bh":
        adjusted_ranked = np.minimum.accumulate((count / np.arange(count, 0, -1)) * ranked[::-1])[::-1]
    else:
        raise ValueError(f"unknown multiplicity method: {method}")
    adjusted = np.empty(count, dtype=float)
    adjusted[order] = np.minimum(adjusted_ranked, 1.0)
    return adjusted


def fixed_effect_meta(effects: Sequence[float], variances: Sequence[float]) -> dict[str, float | tuple[float, float]]:
    estimates = np.asarray(effects, dtype=float)
    sampling_variances = np.asarray(variances, dtype=float)
    if len(estimates) < 2 or len(estimates) != len(sampling_variances) or (sampling_variances <= 0).any():
        raise ValueError("fixed-effect meta-analysis needs matching positive variances")
    weights = 1.0 / sampling_variances
    pooled = float(np.sum(weights * estimates) / np.sum(weights))
    standard_error = math.sqrt(1.0 / float(np.sum(weights)))
    return {
        "pooled_effect": pooled,
        "standard_error": standard_error,
        "confidence_interval": (pooled - 1.96 * standard_error, pooled + 1.96 * standard_error),
        "p_value_normal": math.erfc(abs(pooled / standard_error) / math.sqrt(2)),
    }


def _json_dump(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")


def _cache_fingerprint(paths: Iterable[Path]) -> str:
    digest = hashlib.sha256()
    for path in paths:
        digest.update(path.name.encode())
        digest.update(calculate_sha256(path).encode())
    return digest.hexdigest()


def _build_enriched_season(
    season: int,
    config: StudyConfig,
    raw_dir: Path,
    cache_dir: Path,
) -> pd.DataFrame:
    pbp_path = raw_dir / f"nbastatsv3_{season}.csv"
    detail_path = raw_dir / f"shotdetail_{season}.csv"
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_path = cache_dir / f"enriched_{season}.pkl"
    metadata_path = cache_dir / f"enriched_{season}.json"
    source_fingerprint = _cache_fingerprint((pbp_path, detail_path))
    if cache_path.is_file() and metadata_path.is_file():
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        cached = pd.read_pickle(cache_path)
        if (
            metadata.get("source_fingerprint") == source_fingerprint
            and metadata.get("cache_schema") == "compact-v1"
        ) or tuple(cached.columns) == analysis_required_columns():
            if metadata.get("cache_schema") != "compact-v1":
                _json_dump(
                    metadata_path,
                    {
                        "source_fingerprint": source_fingerprint,
                        "cache_schema": "compact-v1",
                        "rows": len(cached),
                        "season": season,
                    },
                )
            return cached

    pbp = pd.read_csv(pbp_path, low_memory=False)
    details = pd.read_csv(detail_path, low_memory=False)
    shots, _ = build_shot_events(pbp, details)
    events = canonicalize_pbp_events(pbp)
    shots = add_global_interval_flags(shots, events)
    shots = add_personal_lag(shots)
    shots = add_personal_interval_flags(shots, events)
    shots = add_team_lag(shots)
    shots = add_global_lag(shots)
    shots["season"] = int(season)
    shots["player_id_x_season"] = (
        pd.to_numeric(shots["player_id"], errors="coerce").astype("Int64") * 10_000 + int(season)
    )

    ordered_game = shots.groupby("game_id", sort=False, dropna=False)
    shots["previous_global_shot_distance_feet"] = ordered_game["shot_distance_feet"].shift()
    shots["previous_global_clock_seconds"] = ordered_game["clock_seconds"].shift()
    shots["previous_global_period"] = ordered_game["period"].shift()
    team_groups = shots.groupby(["game_id", "period", "team_id"], sort=False, dropna=False)
    shots["previous_team_shot_distance_feet"] = team_groups["shot_distance_feet"].shift()
    shots["previous_team_clock_seconds"] = team_groups["clock_seconds"].shift()
    shots["team_interval_seconds"] = shots["previous_team_clock_seconds"] - shots["clock_seconds"]

    featured = add_game_state_features(shots, config)
    featured["is_three_point_attempt"] = featured["shot_type"].astype("string").str.contains("3PT", case=False, na=False).astype("Int8")
    featured["previous_team_miss"] = (1.0 - pd.to_numeric(featured["previous_team_shot_made"], errors="coerce")).where(featured["previous_team_shot_made"].notna())
    featured["post_team_miss_x_critical"] = featured["previous_team_miss"] * featured["critical"]
    featured["previous_global_miss"] = (1.0 - pd.to_numeric(featured["previous_global_shot_made"], errors="coerce")).where(featured["previous_global_shot_made"].notna())
    featured["global_rel_teammate"] = featured["previous_global_relation"].eq("teammate").astype("Int8")
    featured["global_rel_opponent"] = featured["previous_global_relation"].eq("opponent").astype("Int8")
    featured["global_miss_x_teammate"] = featured["previous_global_miss"] * featured["global_rel_teammate"]
    featured["global_miss_x_opponent"] = featured["previous_global_miss"] * featured["global_rel_opponent"]
    featured["global_miss_x_critical"] = featured["previous_global_miss"] * featured["critical"]
    featured["teammate_x_critical"] = featured["global_rel_teammate"] * featured["critical"]
    featured["opponent_x_critical"] = featured["global_rel_opponent"] * featured["critical"]
    featured["global_miss_x_teammate_x_critical"] = featured["previous_global_miss"] * featured["global_rel_teammate"] * featured["critical"]
    featured["global_miss_x_opponent_x_critical"] = featured["previous_global_miss"] * featured["global_rel_opponent"] * featured["critical"]
    keep = list(analysis_required_columns())
    missing = sorted(set(keep) - set(featured.columns))
    if missing:
        raise RuntimeError(f"analysis cache contract missing columns: {missing}")
    compact = featured.loc[:, keep].copy()
    compact.to_pickle(cache_path)
    _json_dump(
        metadata_path,
        {
            "source_fingerprint": source_fingerprint,
            "cache_schema": "compact-v1",
            "rows": len(compact),
            "season": season,
        },
    )
    return compact


def _main_predictors(config: StudyConfig) -> list[str]:
    return primary_predictors(config)


def _base_controls(config: StudyConfig, interval_column: str = "personal_interval_seconds") -> list[str]:
    controls = [
        "previous_personal_shot_distance_feet",
        "offense_signed_pre_shot_margin",
        "absolute_pre_shot_margin",
        "remaining_period_seconds",
        interval_column,
        "is_home_offense",
    ]
    controls.extend(f"remaining_period_seconds_spline_{k}" for k in config.remaining_period_seconds_knots)
    controls.extend(f"absolute_pre_shot_margin_spline_{k}" for k in config.absolute_margin_knots)
    if interval_column == "personal_interval_seconds":
        controls.extend(f"personal_interval_seconds_spline_{k}" for k in config.personal_interval_seconds_knots)
    return controls


def _fit(
    data: pd.DataFrame,
    outcome: str,
    predictors: Sequence[str],
    config: StudyConfig,
    config_hash: str,
) -> ModelResult:
    if data.empty:
        raise ValueError("registered model has an empty sample")
    return fit_hdfe_ols(
        data,
        outcome=outcome,
        predictors=list(predictors),
        fe_groups=list(config.fixed_effects),
        cluster_groups=list(config.cluster_groups),
        tol=1e-9,
        max_iter=10_000,
        config_hash=config_hash,
    )


def _result_record(
    model_id: str,
    template_id: str,
    spec: AnalysisSpec,
    model: ModelResult,
    target_terms: Sequence[str] | None = None,
) -> dict[str, object]:
    targets = tuple(target_terms or spec.target_terms)
    omitted = {term: "absorbed or absent" for term in targets if term not in model.estimates}
    return {
        "model_id": model_id,
        "template_id": template_id,
        "status": spec.status,
        "sample": spec.sample,
        "outcome": spec.outcome,
        "target_terms": list(targets),
        "multiplicity_family": spec.multiplicity_family,
        "description": spec.description,
        "model": model.to_dict(),
        "omitted_target_terms": omitted,
    }


def _registry_map() -> dict[str, AnalysisSpec]:
    validate_registry(ANALYSIS_REGISTRY)
    return {entry.analysis_id: entry for entry in ANALYSIS_REGISTRY}


def _fit_primary_record(
    model_id: str,
    template_id: str,
    data: pd.DataFrame,
    config: StudyConfig,
    config_hash: str,
    registry: dict[str, AnalysisSpec],
) -> dict[str, object]:
    model = _fit(data, "shot_distance_feet", _main_predictors(config), config, config_hash)
    return _result_record(model_id, template_id, registry[template_id], model)


def _fit_alternative_criticality(
    model_id: str,
    frame: pd.DataFrame,
    critical: pd.Series,
    config: StudyConfig,
    config_hash: str,
    spec: AnalysisSpec,
) -> dict[str, object]:
    data = frame.copy(deep=False)
    data["critical_alt"] = critical.astype("Int8")
    data["post_miss_x_critical_alt"] = data["previous_personal_miss"] * data["critical_alt"]
    predictors = ["previous_personal_miss", "critical_alt", "post_miss_x_critical_alt", *_base_controls(config)]
    model = _fit(data, "shot_distance_feet", predictors, config, config_hash)
    return _result_record(model_id, spec.analysis_id, spec, model)


def _sealed_confirmation_records(study_root: Path, registry: dict[str, AnalysisSpec]) -> list[dict[str, object]]:
    path = study_root / "results" / "confirmation_primary.json"
    expected = "1a2513226a30479f623f7a56b964a54ea21cbd8262a280bc5cdc31f49924a472"
    actual = calculate_sha256(path)
    if actual != expected:
        raise RuntimeError(f"sealed confirmation artifact hash mismatch: {actual}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    records = []
    for analysis_id, hypothesis in (("confirmation_h1", "h1"), ("confirmation_h2", "h2")):
        records.append(
            {
                "model_id": analysis_id,
                "template_id": analysis_id,
                "status": "confirmatory",
                "sample": registry[analysis_id].sample,
                "outcome": "shot_distance_feet",
                "target_terms": list(registry[analysis_id].target_terms),
                "multiplicity_family": "none",
                "description": "Read without refitting from the sealed held-out confirmation artifact.",
                "sealed_artifact_sha256": actual,
                "sealed_result": payload["hypotheses"][hypothesis],
                "omitted_target_terms": {},
            }
        )
    return records


def _critical(frame: pd.DataFrame, period: int, seconds: float, margin: float) -> pd.Series:
    return frame["period"].eq(period) & frame["clock_seconds"].le(seconds) & frame["absolute_pre_shot_margin"].le(margin)


def _global_social_model(
    data: pd.DataFrame,
    config: StudyConfig,
    config_hash: str,
    spec: AnalysisSpec,
) -> dict[str, object]:
    same_period = pd.to_numeric(data["previous_global_period"], errors="coerce").eq(pd.to_numeric(data["period"], errors="coerce"))
    predictors = [
        "previous_global_miss",
        "global_rel_teammate",
        "global_rel_opponent",
        "global_miss_x_teammate",
        "global_miss_x_opponent",
        "critical",
        "global_miss_x_critical",
        "teammate_x_critical",
        "opponent_x_critical",
        "global_miss_x_teammate_x_critical",
        "global_miss_x_opponent_x_critical",
        "previous_global_shot_distance_feet",
        "offense_signed_pre_shot_margin",
        "absolute_pre_shot_margin",
        "remaining_period_seconds",
        "is_home_offense",
        *[f"remaining_period_seconds_spline_{k}" for k in config.remaining_period_seconds_knots],
        *[f"absolute_pre_shot_margin_spline_{k}" for k in config.absolute_margin_knots],
    ]
    required = list(dict.fromkeys([
        "shot_distance_feet", *predictors, *config.fixed_effects, *config.cluster_groups,
        "previous_global_relation", "previous_global_period", "period", "pre_score_home",
        "pre_score_away", "heave_proxy", "offensive_rebound_continuation",
    ]))
    relation_mask = data["previous_global_relation"].isin(["self", "teammate", "opponent"])
    valid = (
        data[["shot_distance_feet", "previous_global_shot_distance_feet", "pre_score_home", "pre_score_away"]].notna().all(axis=1)
        & ~data["heave_proxy"].fillna(False)
        & ~data["offensive_rebound_continuation"].fillna(False)
    )
    social = data.loc[same_period & relation_mask & valid, required].copy()
    model = _fit(social, "shot_distance_feet", predictors, config, config_hash)
    record = _result_record(spec.analysis_id, spec.analysis_id, spec, model)
    record["coefficient_difference_tests"] = {
        "teammate_minus_self_post_miss": {
            "term": "global_miss_x_teammate",
            "estimate": model.estimates.get("global_miss_x_teammate"),
            "standard_error": model.two_way_standard_errors.get("global_miss_x_teammate"),
            "p_normal": model.p_values_normal.get("global_miss_x_teammate"),
        },
        "teammate_minus_self_critical_moderation": {
            "term": "global_miss_x_teammate_x_critical",
            "estimate": model.estimates.get("global_miss_x_teammate_x_critical"),
            "standard_error": model.two_way_standard_errors.get("global_miss_x_teammate_x_critical"),
            "p_normal": model.p_values_normal.get("global_miss_x_teammate_x_critical"),
        },
    }
    return record


def _extract_target_rows(records: Sequence[dict[str, object]]) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for record in records:
        if "model" in record:
            model = record["model"]
            for term in record["target_terms"]:
                if term in model["estimates"]:
                    rows.append(
                        {
                            "model_id": record["model_id"],
                            "template_id": record["template_id"],
                            "status": record["status"],
                            "multiplicity_family": record["multiplicity_family"],
                            "term": term,
                            "estimate": model["estimates"][term],
                            "standard_error": model["two_way_standard_errors"][term],
                            "p_raw": model["p_values_normal"][term],
                            "n_obs": model["n_obs"],
                        }
                    )
        elif "sealed_result" in record:
            sealed = record["sealed_result"]
            rows.append(
                {
                    "model_id": record["model_id"],
                    "template_id": record["template_id"],
                    "status": record["status"],
                    "multiplicity_family": "none",
                    "term": record["target_terms"][0],
                    "estimate": sealed["estimate"],
                    "standard_error": sealed["standard_error_two_way"],
                    "p_raw": sealed["p_normal"],
                    "n_obs": np.nan,
                }
            )
    return pd.DataFrame.from_records(rows)


def _multiplicity_table(targets: pd.DataFrame) -> pd.DataFrame:
    adjusted = targets.copy()
    adjusted["adjustment_method"] = "none"
    adjusted["p_adjusted"] = adjusted["p_raw"]
    for status, method in (("secondary", "holm"), ("exploratory", "fdr_bh")):
        mask_status = adjusted["status"].eq(status) & adjusted["multiplicity_family"].ne("none")
        for _, index in adjusted.loc[mask_status].groupby("multiplicity_family", sort=True).groups.items():
            indices = list(index)
            adjusted.loc[indices, "adjustment_method"] = method
            adjusted.loc[indices, "p_adjusted"] = adjust_p_values(adjusted.loc[indices, "p_raw"].to_numpy(), method)
    return adjusted


def _meta_table(records: Sequence[dict[str, object]]) -> pd.DataFrame:
    seasonal = []
    for record in records:
        if record["template_id"] == "season_specific":
            model = record["model"]
            seasonal.append(
                (
                    int(record["model_id"].split("_")[-1]),
                    model["estimates"]["post_miss_x_critical"],
                    model["two_way_standard_errors"]["post_miss_x_critical"] ** 2,
                )
            )
    seasonal.sort()
    effects = np.array([row[1] for row in seasonal])
    variances = np.array([row[2] for row in seasonal])
    random = reml_meta(effects, variances).to_dict()
    fixed = fixed_effect_meta(effects, variances)
    rows = [
        {"analysis": "eight_season_h2_random_reml", **random},
        {
            "analysis": "eight_season_h2_fixed_effect_sensitivity",
            **fixed,
            "tau_squared": 0.0,
            "i_squared_percent": np.nan,
            "prediction_interval": (np.nan, np.nan),
            "studies": len(effects),
            "optimizer_tolerance": np.nan,
            "optimizer_iterations": np.nan,
            "converged": True,
        },
    ]
    for excluded in range(len(seasonal)):
        keep = np.arange(len(seasonal)) != excluded
        result = reml_meta(effects[keep], variances[keep]).to_dict()
        rows.append({"analysis": f"leave_season_{seasonal[excluded][0]}_out_reml", **result})
    return pd.DataFrame.from_records(rows)


def _registry_rows(records: Sequence[dict[str, object]]) -> pd.DataFrame:
    rows = []
    for record in records:
        rows.append(
            {
                "model_id": record["model_id"],
                "template_id": record["template_id"],
                "status": record["status"],
                "sample": record["sample"],
                "outcome": record["outcome"],
                "target_terms": "|".join(record["target_terms"]),
                "fixed_effects": "player_id_x_season|game_id",
                "clusters": "game_id|player_id",
                "multiplicity_family": record["multiplicity_family"],
                "result_status": "ok" if not record.get("omitted_target_terms") else "target_omitted",
                "omission_reason": json.dumps(record.get("omitted_target_terms", {}), sort_keys=True),
            }
        )
    frame = pd.DataFrame.from_records(rows)
    if frame["model_id"].duplicated().any():
        raise RuntimeError("expanded model registry contains duplicate model IDs")
    return frame


def run_registered_analyses(study_root: Path, raw_dir: Path, out_dir: Path, cache_dir: Path) -> None:
    study_root = study_root.resolve()
    raw_dir = raw_dir.resolve()
    assert_confirmation_allowed(study_root)
    validate_raw_manifest(study_root, raw_dir)
    registry = _registry_map()
    config = load_config(study_root / "study_config.json")
    config_hash = calculate_sha256(study_root / "study_config.json")

    print("phase 1/4: loading compact season caches and constructing main sample", flush=True)
    main_frames: list[pd.DataFrame] = []
    for season in config.all_seasons:
        enriched = _build_enriched_season(season, config, raw_dir, cache_dir)
        season_main, _ = build_main_sample(enriched, config)
        main_frames.append(season_main)
        del enriched, season_main
        gc.collect()
    main = pd.concat(main_frames, ignore_index=True)
    del main_frames
    gc.collect()

    records: list[dict[str, object]] = _sealed_confirmation_records(study_root, registry)
    print(f"main sample rows: {len(main):,}; fitting registered main-sample models", flush=True)
    records.append(_fit_primary_record("pooled_eight_season", "pooled_eight_season", main, config, config_hash, registry))
    for season in config.all_seasons:
        records.append(
            _fit_primary_record(
                f"season_specific_{season}",
                "season_specific",
                main.loc[main["season"].eq(season)],
                config,
                config_hash,
                registry,
            )
        )

    for analysis_id, seconds, margin in (
        ("critical_2min_margin3", 120.0, 3.0),
        ("critical_5min_margin3", 300.0, 3.0),
        ("critical_5min_margin8", 300.0, 8.0),
    ):
        records.append(
            _fit_alternative_criticality(
                analysis_id,
                main,
                _critical(main, 4, seconds, margin),
                config,
                config_hash,
                registry[analysis_id],
            )
        )

    continuous_spec = registry["continuous_criticality"]
    continuous_predictors = [
        "previous_personal_miss",
        "continuous_criticality",
        "post_miss_x_continuous_criticality",
        *_base_controls(config),
    ]
    records.append(
        _result_record(
            "continuous_criticality",
            "continuous_criticality",
            continuous_spec,
            _fit(main, "shot_distance_feet", continuous_predictors, config, config_hash),
        )
    )

    previous_data = main.copy(deep=False)
    previous_data["post_miss_x_previous_critical"] = previous_data["previous_personal_miss"] * previous_data["previous_personal_critical"]
    previous_predictors = ["previous_personal_miss", "previous_personal_critical", "post_miss_x_previous_critical", *_base_controls(config)]
    records.append(_result_record("previous_shot_criticality", "previous_shot_criticality", registry["previous_shot_criticality"], _fit(previous_data, "shot_distance_feet", previous_predictors, config, config_hash)))

    primary_masks: list[tuple[str, pd.Series]] = [
        ("stable_critical_status", main["stable_critical_status"].fillna(False)),
        ("interval_le_120", main["personal_interval_seconds"].le(120)),
        ("same_stint", main["same_stint"].fillna(False)),
        ("no_timeout", main["no_timeout_between_personal_shots"].fillna(False)),
        ("no_pandemic", ~main["season"].isin([2019, 2020])),
        ("period_end_2s", main["clock_seconds"].gt(2)),
        ("period_end_5s", main["clock_seconds"].gt(5)),
        ("margin_leading", main["offense_signed_pre_shot_margin"].gt(0)),
        ("margin_tied", main["offense_signed_pre_shot_margin"].eq(0)),
        ("margin_trailing", main["offense_signed_pre_shot_margin"].lt(0)),
    ]
    for analysis_id, mask in primary_masks:
        subset = main.loc[mask]
        records.append(_fit_primary_record(analysis_id, analysis_id, subset, config, config_hash, registry))
        del subset
    del primary_masks, mask

    q3_data = main.copy(deep=False)
    q3_data["q3_placebo"] = _critical(main, 3, 300.0, 5.0).astype("Int8")
    q3_data["post_miss_x_q3_placebo"] = q3_data["previous_personal_miss"] * q3_data["q3_placebo"]
    q3_predictors = ["previous_personal_miss", "q3_placebo", "post_miss_x_q3_placebo", *_base_controls(config)]
    records.append(_result_record("q3_placebo", "q3_placebo", registry["q3_placebo"], _fit(q3_data, "shot_distance_feet", q3_predictors, config, config_hash)))
    del q3_data

    team_spec = registry["team_lag"]
    team_data = main.loc[main["previous_team_miss"].notna()]
    team_predictors = [
        "previous_team_miss",
        "critical",
        "post_team_miss_x_critical",
        "previous_team_shot_distance_feet",
        "offense_signed_pre_shot_margin",
        "absolute_pre_shot_margin",
        "remaining_period_seconds",
        "team_interval_seconds",
        "is_home_offense",
        *[f"remaining_period_seconds_spline_{k}" for k in config.remaining_period_seconds_knots],
        *[f"absolute_pre_shot_margin_spline_{k}" for k in config.absolute_margin_knots],
    ]
    records.append(_result_record("team_lag", "team_lag", team_spec, _fit(team_data, "shot_distance_feet", team_predictors, config, config_hash)))
    del team_data

    three_spec = registry["three_point_secondary"]
    records.append(_result_record("three_point_secondary", "three_point_secondary", three_spec, _fit(main, "is_three_point_attempt", _main_predictors(config), config, config_hash)))

    print("fitting leave-one-season, leave-one-team, and high-volume-player diagnostics", flush=True)
    for excluded in config.all_seasons:
        records.append(
            _fit_primary_record(
                f"leave_one_season_out_{excluded}",
                "leave_one_season_out",
                main.loc[main["season"].ne(excluded)],
                config,
                config_hash,
                registry,
            )
        )
    for team in sorted(pd.to_numeric(main["team_id"], errors="coerce").dropna().astype(int).unique()):
        records.append(
            _fit_primary_record(
                f"leave_one_team_out_{team}",
                "leave_one_team_out",
                main.loc[pd.to_numeric(main["team_id"], errors="coerce").ne(team)],
                config,
                config_hash,
                registry,
            )
        )
    top_players = main["player_id"].value_counts().head(10).index.tolist()
    for player in top_players:
        records.append(
            _fit_primary_record(
                f"high_volume_player_influence_{int(player)}",
                "high_volume_player_influence",
                main.loc[main["player_id"].ne(player)],
                config,
                config_hash,
                registry,
            )
        )

    print("phase 2/4: fitting offensive-rebound inclusion variant", flush=True)
    del previous_data
    include_rebounds_config = replace(
        config,
        main_exclusions=tuple(
            reason for reason in config.main_exclusions if reason != "offensive_rebound_continuation"
        ),
    )
    include_frames: list[pd.DataFrame] = []
    primary_columns = list(dict.fromkeys([
        "shot_distance_feet", *_main_predictors(config), *config.fixed_effects, *config.cluster_groups
    ]))
    for season in config.all_seasons:
        enriched = _build_enriched_season(season, config, raw_dir, cache_dir)
        variant, _ = build_main_sample(enriched, include_rebounds_config)
        include_frames.append(variant.loc[:, primary_columns])
        del enriched, variant
        gc.collect()
    include_rebounds = pd.concat(include_frames, ignore_index=True)
    del include_frames
    records.append(_fit_primary_record("include_offensive_rebounds", "include_offensive_rebounds", include_rebounds, config, config_hash, registry))
    del include_rebounds
    gc.collect()

    print("phase 3/4: fitting one-second-putback exclusion variant", flush=True)
    putback_config = replace(
        config,
        main_exclusions=tuple(
            "putback_within_one_second" if reason == "offensive_rebound_continuation" else reason
            for reason in config.main_exclusions
        ),
    )
    putback_frames: list[pd.DataFrame] = []
    for season in config.all_seasons:
        enriched = _build_enriched_season(season, config, raw_dir, cache_dir)
        variant, _ = build_main_sample(enriched, putback_config)
        putback_frames.append(variant.loc[:, primary_columns])
        del enriched, variant
        gc.collect()
    exclude_putbacks = pd.concat(putback_frames, ignore_index=True)
    del putback_frames
    records.append(_fit_primary_record("exclude_putbacks_only", "exclude_putbacks_only", exclude_putbacks, config, config_hash, registry))
    del exclude_putbacks
    gc.collect()

    print("phase 4/4: fitting global self/teammate/opponent joint model", flush=True)
    global_frames: list[pd.DataFrame] = []
    global_predictors = [
        "previous_global_miss", "global_rel_teammate", "global_rel_opponent",
        "global_miss_x_teammate", "global_miss_x_opponent", "critical",
        "global_miss_x_critical", "teammate_x_critical", "opponent_x_critical",
        "global_miss_x_teammate_x_critical", "global_miss_x_opponent_x_critical",
        "previous_global_shot_distance_feet", "offense_signed_pre_shot_margin",
        "absolute_pre_shot_margin", "remaining_period_seconds", "is_home_offense",
        *[f"remaining_period_seconds_spline_{k}" for k in config.remaining_period_seconds_knots],
        *[f"absolute_pre_shot_margin_spline_{k}" for k in config.absolute_margin_knots],
    ]
    global_columns = list(dict.fromkeys([
        "shot_distance_feet", *global_predictors, *config.fixed_effects, *config.cluster_groups,
        "previous_global_relation", "previous_global_period", "period", "pre_score_home",
        "pre_score_away", "heave_proxy", "offensive_rebound_continuation",
    ]))
    for season in config.all_seasons:
        enriched = _build_enriched_season(season, config, raw_dir, cache_dir)
        same_period = pd.to_numeric(enriched["previous_global_period"], errors="coerce").eq(
            pd.to_numeric(enriched["period"], errors="coerce")
        )
        relation = enriched["previous_global_relation"].isin(["self", "teammate", "opponent"])
        valid = (
            enriched[["shot_distance_feet", "previous_global_shot_distance_feet", "pre_score_home", "pre_score_away"]].notna().all(axis=1)
            & ~enriched["heave_proxy"].fillna(False)
            & ~enriched["offensive_rebound_continuation"].fillna(False)
        )
        global_frames.append(enriched.loc[same_period & relation & valid, global_columns].copy())
        del enriched
        gc.collect()
    global_data = pd.concat(global_frames, ignore_index=True)
    del global_frames
    records.append(_global_social_model(global_data, config, config_hash, registry["global_social_replication"]))
    del global_data, main
    gc.collect()

    expanded_registry = _registry_rows(records)
    expected_templates = {entry.analysis_id for entry in ANALYSIS_REGISTRY}
    observed_templates = set(expanded_registry["template_id"])
    if observed_templates != expected_templates:
        raise RuntimeError(f"registry/output mismatch: missing={expected_templates-observed_templates}, extra={observed_templates-expected_templates}")
    if expanded_registry["result_status"].ne("ok").any():
        failures = expanded_registry.loc[expanded_registry["result_status"].ne("ok"), ["model_id", "omission_reason"]]
        raise RuntimeError(f"registered target coefficients omitted:\n{failures.to_string(index=False)}")

    targets = _extract_target_rows(records)
    multiplicity = _multiplicity_table(targets)
    meta = _meta_table(records)
    out_dir.mkdir(parents=True, exist_ok=True)
    expanded_registry.to_csv(out_dir / "model_registry.csv", index=False, lineterminator="\n")
    _json_dump(out_dir / "all_models.json", {"models": records})
    meta.to_csv(out_dir / "meta_analysis.csv", index=False, float_format="%.17g", lineterminator="\n")
    multiplicity.to_csv(out_dir / "multiplicity_adjusted.csv", index=False, float_format="%.17g", lineterminator="\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--raw-dir", type=Path, default=Path("work/data/raw"))
    parser.add_argument("--out-dir", type=Path)
    parser.add_argument("--cache-dir", type=Path, default=Path("work/data/analysis_cache"))
    args = parser.parse_args()
    study_root = args.study_root.resolve()
    run_registered_analyses(
        study_root,
        args.raw_dir,
        args.out_dir or study_root / "results",
        args.cache_dir,
    )


if __name__ == "__main__":
    main()
