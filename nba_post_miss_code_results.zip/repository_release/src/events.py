"""Canonical event ordering, pre-shot state reconstruction, and shot joins."""

from __future__ import annotations

import re

import numpy as np
import pandas as pd


_CLOCK_PATTERN = re.compile(r"^PT(?:(?P<minutes>\d+(?:\.\d+)?)M)?(?P<seconds>\d+(?:\.\d+)?)S$")
_ANOMALY_COLUMNS = ["category", "game_id", "action_number", "detail"]


def parse_clock(series: pd.Series) -> pd.Series:
    """Convert NBA ISO-like period clocks to remaining seconds."""

    def convert(value: object) -> float:
        if pd.isna(value):
            return float("nan")
        match = _CLOCK_PATTERN.match(str(value))
        if match is None:
            return float("nan")
        minutes = float(match.group("minutes") or 0.0)
        seconds = float(match.group("seconds"))
        return 60.0 * minutes + seconds

    return series.map(convert).astype(float)


def canonicalize_pbp_events(pbp: pd.DataFrame) -> pd.DataFrame:
    """Return one chronologically ordered event table with pre-event scores."""

    events = pbp.copy()
    events["_source_row"] = np.arange(len(events), dtype=np.int64)
    events["clock_seconds"] = parse_clock(events["clock"])
    if "actionId" in events:
        events["_event_sequence"] = pd.to_numeric(events["actionId"], errors="coerce")
    else:
        events["_event_sequence"] = pd.to_numeric(events["actionNumber"], errors="coerce")
    events["_event_sequence"] = events["_event_sequence"].fillna(events["_source_row"])
    events = events.sort_values(
        ["gameId", "period", "clock_seconds", "_event_sequence", "actionNumber", "_source_row"],
        ascending=[True, True, False, True, True, True],
        kind="stable",
    ).reset_index(drop=True)
    events["event_order"] = events.groupby("gameId", sort=False).cumcount().astype(np.int64)

    score_home = pd.to_numeric(events["scoreHome"], errors="coerce")
    score_away = pd.to_numeric(events["scoreAway"], errors="coerce")
    points = pd.to_numeric(events.get("pointsTotal", 0), errors="coerce").fillna(0)
    action = events.get("actionType", pd.Series("", index=events.index)).fillna("").astype(str)
    is_correction = action.str.casefold().str.contains("score correction", regex=False)
    first_in_game = events.groupby("gameId", sort=False).cumcount().eq(0)
    valid_update = score_home.notna() & score_away.notna() & (
        points.gt(0) | is_correction | first_in_game
    )
    update_home = score_home.where(valid_update)
    update_away = score_away.where(valid_update)
    after_home = update_home.groupby(events["gameId"], sort=False).ffill().fillna(0)
    after_away = update_away.groupby(events["gameId"], sort=False).ffill().fillna(0)
    events["pre_score_home"] = after_home.groupby(events["gameId"], sort=False).shift().fillna(0)
    events["pre_score_away"] = after_away.groupby(events["gameId"], sort=False).shift().fillna(0)

    rename = {
        "gameId": "game_id",
        "actionNumber": "action_number",
        "teamId": "team_id",
        "personId": "player_id",
        "playerName": "player_name",
        "description": "description",
        "actionType": "action_type",
        "subType": "sub_type",
        "isFieldGoal": "is_field_goal",
        "shotResult": "shot_result",
        "location": "offense_location",
    }
    events = events.rename(columns=rename)
    for column in (
        "team_id",
        "player_id",
        "player_name",
        "description",
        "action_type",
        "sub_type",
        "is_field_goal",
        "shot_result",
        "offense_location",
    ):
        if column not in events:
            events[column] = np.nan
    return events


def _anomalies(frame: pd.DataFrame, category: str, game: str, action: str, detail: str) -> list[dict[str, object]]:
    return [
        {
            "category": category,
            "game_id": row[game],
            "action_number": row[action],
            "detail": detail,
        }
        for _, row in frame.iterrows()
    ]


def build_shot_events(pbp: pd.DataFrame, shots: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build canonical PBP FGA rows and attach only unambiguous shot detail."""

    events = canonicalize_pbp_events(pbp)
    fga = events.loc[pd.to_numeric(events["is_field_goal"], errors="coerce").eq(1)].copy()
    details = shots.copy()
    if "SHOT_ATTEMPTED_FLAG" in details:
        details = details.loc[pd.to_numeric(details["SHOT_ATTEMPTED_FLAG"], errors="coerce").eq(1)].copy()

    pbp_key = ["game_id", "action_number"]
    shot_key = ["GAME_ID", "GAME_EVENT_ID"]
    duplicate_pbp = fga.duplicated(pbp_key, keep=False)
    duplicate_shot = details.duplicated(shot_key, keep=False)
    anomaly_rows: list[dict[str, object]] = []
    anomaly_rows.extend(
        _anomalies(
            fga.loc[duplicate_pbp],
            "duplicate_pbp_fga_key",
            "game_id",
            "action_number",
            "ambiguous play-by-play field-goal key excluded",
        )
    )
    anomaly_rows.extend(
        _anomalies(
            details.loc[duplicate_shot],
            "duplicate_shot_key",
            "GAME_ID",
            "GAME_EVENT_ID",
            "ambiguous shot-detail key excluded",
        )
    )

    base = fga.loc[~duplicate_pbp].copy()
    valid_details = details.loc[~duplicate_shot].copy()
    pbp_keys = base.loc[:, pbp_key].drop_duplicates()
    shot_keys = valid_details.loc[:, shot_key].drop_duplicates()
    coverage = pbp_keys.merge(
        shot_keys,
        how="outer",
        left_on=pbp_key,
        right_on=shot_key,
        indicator=True,
    )
    anomaly_rows.extend(
        _anomalies(
            coverage.loc[coverage["_merge"].eq("left_only")],
            "pbp_only_key",
            "game_id",
            "action_number",
            "no unambiguous shot-detail row",
        )
    )
    anomaly_rows.extend(
        _anomalies(
            coverage.loc[coverage["_merge"].eq("right_only")],
            "shot_only_key",
            "GAME_ID",
            "GAME_EVENT_ID",
            "no play-by-play field-goal row",
        )
    )

    selected_details = valid_details.loc[
        :,
        [
            "GAME_ID",
            "GAME_EVENT_ID",
            "PLAYER_ID",
            "TEAM_ID",
            "PLAYER_NAME",
            "SHOT_DISTANCE",
            "LOC_X",
            "LOC_Y",
            "SHOT_MADE_FLAG",
            "SHOT_TYPE",
            "ACTION_TYPE",
            "SHOT_ZONE_BASIC",
            "SHOT_ZONE_AREA",
            "SHOT_ZONE_RANGE",
            "GAME_DATE",
            "HTM",
            "VTM",
        ],
    ].copy()
    merged = base.merge(
        selected_details,
        how="left",
        left_on=pbp_key,
        right_on=shot_key,
        validate="one_to_one",
        suffixes=("", "_detail"),
    )
    player_mismatch = merged["PLAYER_ID"].notna() & merged["player_id"].astype("Int64").ne(
        merged["PLAYER_ID"].astype("Int64")
    )
    team_mismatch = merged["TEAM_ID"].notna() & merged["team_id"].astype("Int64").ne(
        merged["TEAM_ID"].astype("Int64")
    )
    anomaly_rows.extend(
        _anomalies(
            merged.loc[player_mismatch],
            "player_id_disagreement",
            "game_id",
            "action_number",
            "PBP and shot-detail player IDs disagree",
        )
    )
    anomaly_rows.extend(
        _anomalies(
            merged.loc[team_mismatch],
            "team_id_disagreement",
            "game_id",
            "action_number",
            "PBP and shot-detail team IDs disagree",
        )
    )

    merged["shot_made"] = merged["shot_result"].astype(str).str.casefold().eq("made").astype("Int8")
    merged["shot_distance_feet"] = pd.to_numeric(merged["SHOT_DISTANCE"], errors="coerce")
    merged["loc_x"] = pd.to_numeric(merged["LOC_X"], errors="coerce")
    merged["loc_y"] = pd.to_numeric(merged["LOC_Y"], errors="coerce")
    merged["shot_type"] = merged["SHOT_TYPE"]
    merged["shot_action_type"] = merged["ACTION_TYPE"]
    merged["shot_zone_basic"] = merged["SHOT_ZONE_BASIC"]
    merged["shot_zone_area"] = merged["SHOT_ZONE_AREA"]
    merged["shot_zone_range"] = merged["SHOT_ZONE_RANGE"]
    merged["game_date"] = merged["GAME_DATE"]
    merged["home_team_tricode"] = merged["HTM"]
    merged["away_team_tricode"] = merged["VTM"]
    merged["is_home_offense"] = (
        merged["offense_location"].astype("string").str.casefold().map({"h": 1, "v": 0}).astype("Int8")
    )
    merged["shot_detail_matched"] = merged["GAME_ID"].notna()

    output_columns = [
        "game_id",
        "action_number",
        "period",
        "clock_seconds",
        "event_order",
        "team_id",
        "player_id",
        "player_name",
        "is_home_offense",
        "shot_made",
        "shot_distance_feet",
        "loc_x",
        "loc_y",
        "shot_type",
        "shot_action_type",
        "shot_zone_basic",
        "shot_zone_area",
        "shot_zone_range",
        "pre_score_home",
        "pre_score_away",
        "game_date",
        "home_team_tricode",
        "away_team_tricode",
        "shot_detail_matched",
    ]
    result = merged.loc[:, output_columns].sort_values(
        ["game_id", "period", "clock_seconds", "event_order", "action_number"],
        ascending=[True, True, False, True, True],
        kind="stable",
    ).reset_index(drop=True)
    anomaly_frame = pd.DataFrame.from_records(anomaly_rows, columns=_ANOMALY_COLUMNS)
    return result, anomaly_frame

