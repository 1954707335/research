"""Deterministic restricted maximum-likelihood meta-analysis."""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass

import numpy as np


@dataclass(frozen=True, slots=True)
class MetaResult:
    pooled_effect: float
    standard_error: float
    confidence_interval: tuple[float, float]
    p_value_normal: float
    tau_squared: float
    i_squared_percent: float
    prediction_interval: tuple[float, float]
    studies: int
    optimizer_tolerance: float
    optimizer_iterations: int
    converged: bool

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _reml_objective(tau_squared: float, effects: np.ndarray, variances: np.ndarray) -> float:
    total_variance = variances + tau_squared
    weights = 1.0 / total_variance
    pooled = float(np.sum(weights * effects) / np.sum(weights))
    residual_term = float(np.sum(weights * (effects - pooled) ** 2))
    return 0.5 * (
        float(np.sum(np.log(total_variance))) + math.log(float(np.sum(weights))) + residual_term
    )


def _reml_score(tau_squared: float, effects: np.ndarray, variances: np.ndarray) -> float:
    weights = 1.0 / (variances + tau_squared)
    pooled = float(np.sum(weights * effects) / np.sum(weights))
    residuals = effects - pooled
    return 0.5 * (
        float(np.sum(weights))
        - float(np.sum(weights**2) / np.sum(weights))
        - float(np.sum((weights**2) * (residuals**2)))
    )


def _score_root(
    effects: np.ndarray,
    variances: np.ndarray,
    lower: float,
    upper: float,
    tol: float,
    max_iter: int,
) -> tuple[float, int, bool]:
    if _reml_score(lower, effects, variances) >= 0:
        return lower, 0, True
    while _reml_score(upper, effects, variances) < 0:
        upper *= 2.0
    for iteration in range(1, max_iter + 1):
        if upper - lower <= tol * max(1.0, upper):
            return (lower + upper) / 2.0, iteration, True
        midpoint = (lower + upper) / 2.0
        if _reml_score(midpoint, effects, variances) < 0:
            lower = midpoint
        else:
            upper = midpoint
    return (lower + upper) / 2.0, max_iter, False


def reml_meta(
    effects: np.ndarray,
    variances: np.ndarray,
    tol: float = 1e-10,
    max_iter: int = 10_000,
) -> MetaResult:
    estimates = np.asarray(effects, dtype=float).reshape(-1)
    sampling_variances = np.asarray(variances, dtype=float).reshape(-1)
    if len(estimates) != len(sampling_variances) or len(estimates) < 2:
        raise ValueError("REML requires at least two effects with matching variances")
    if not np.isfinite(estimates).all() or not np.isfinite(sampling_variances).all():
        raise ValueError("effects and variances must be finite")
    if (sampling_variances <= 0).any():
        raise ValueError("sampling variances must be strictly positive")

    upper = max(float(np.var(estimates, ddof=1)), float(np.max(sampling_variances)), 1.0) * 100.0
    candidate, iterations, converged = _score_root(
        estimates, sampling_variances, 0.0, upper, tol, max_iter
    )
    tau_squared = max(0.0, candidate)

    weights = 1.0 / (sampling_variances + tau_squared)
    pooled = float(np.sum(weights * estimates) / np.sum(weights))
    standard_error = math.sqrt(1.0 / float(np.sum(weights)))
    confidence_interval = (pooled - 1.96 * standard_error, pooled + 1.96 * standard_error)
    p_value = math.erfc(abs(pooled / standard_error) / math.sqrt(2))

    fixed_weights = 1.0 / sampling_variances
    fixed_mean = float(np.sum(fixed_weights * estimates) / np.sum(fixed_weights))
    q_statistic = float(np.sum(fixed_weights * (estimates - fixed_mean) ** 2))
    degrees_freedom = len(estimates) - 1
    i_squared = (
        max(0.0, (q_statistic - degrees_freedom) / q_statistic) * 100.0
        if q_statistic > 0
        else 0.0
    )
    prediction_scale = math.sqrt(tau_squared + standard_error**2)
    prediction_interval = (pooled - 1.96 * prediction_scale, pooled + 1.96 * prediction_scale)
    return MetaResult(
        pooled_effect=pooled,
        standard_error=standard_error,
        confidence_interval=confidence_interval,
        p_value_normal=p_value,
        tau_squared=tau_squared,
        i_squared_percent=i_squared,
        prediction_interval=prediction_interval,
        studies=len(estimates),
        optimizer_tolerance=tol,
        optimizer_iterations=iterations,
        converged=converged,
    )
