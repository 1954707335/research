from __future__ import annotations

import sys
import unittest
from pathlib import Path

import pandas as pd


STUDY_ROOT = Path(__file__).resolve().parents[1]
FIXTURES = Path(__file__).resolve().parent / "fixtures"
sys.path.insert(0, str(STUDY_ROOT))

from src.events import build_shot_events, parse_clock  # noqa: E402


class EventReconstructionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.pbp = pd.read_csv(FIXTURES / "synthetic_pbp.csv")
        cls.shots = pd.read_csv(FIXTURES / "synthetic_shots.csv")

    def test_parse_clock(self) -> None:
        parsed = parse_clock(pd.Series(["PT12M00.00S", "PT00M03.50S", None]))
        self.assertEqual(parsed.iloc[0], 720.0)
        self.assertEqual(parsed.iloc[1], 3.5)
        self.assertTrue(pd.isna(parsed.iloc[2]))

    def test_pre_shot_score_uses_only_earlier_state(self) -> None:
        events, anomalies = build_shot_events(self.pbp, self.shots)
        indexed = events.set_index("action_number")
        self.assertEqual((indexed.loc[10, "pre_score_home"], indexed.loc[10, "pre_score_away"]), (0, 0))
        self.assertEqual((indexed.loc[20, "pre_score_home"], indexed.loc[20, "pre_score_away"]), (2, 0))
        self.assertEqual((indexed.loc[22, "pre_score_home"], indexed.loc[22, "pre_score_away"]), (2, 0))
        self.assertEqual((indexed.loc[30, "pre_score_home"], indexed.loc[30, "pre_score_away"]), (4, 0))
        self.assertEqual((indexed.loc[44, "pre_score_home"], indexed.loc[44, "pre_score_away"]), (4, 2))
        self.assertEqual((indexed.loc[50, "pre_score_home"], indexed.loc[50, "pre_score_away"]), (5, 2))
        self.assertNotIn("post_score_home", events.columns)
        self.assertTrue(anomalies.empty)

    def test_order_is_stable_with_duplicate_action_number_block_row(self) -> None:
        shuffled = self.pbp.sample(frac=1, random_state=7).reset_index(drop=True)
        events, _ = build_shot_events(shuffled, self.shots)
        period_clock = list(zip(events["period"], events["clock_seconds"]))
        self.assertEqual(period_clock, sorted(period_clock, key=lambda row: (row[0], -row[1])))
        self.assertEqual(events["action_number"].tolist().count(50), 1)

    def test_duplicate_shot_key_is_emitted_and_not_joined_ambiguously(self) -> None:
        duplicated = pd.concat([self.shots, self.shots.loc[self.shots.GAME_EVENT_ID.eq(20)]])
        events, anomalies = build_shot_events(self.pbp, duplicated)
        row = events.loc[events.action_number.eq(20)].iloc[0]
        self.assertTrue(pd.isna(row["shot_distance_feet"]))
        self.assertIn("duplicate_shot_key", set(anomalies["category"]))

    def test_missing_offense_location_stays_missing(self) -> None:
        pbp = self.pbp.copy()
        pbp.loc[pbp.actionNumber.eq(20), "location"] = pd.NA
        events, _ = build_shot_events(pbp, self.shots)
        self.assertTrue(pd.isna(events.loc[events.action_number.eq(20), "is_home_offense"].iloc[0]))


if __name__ == "__main__":
    unittest.main()
