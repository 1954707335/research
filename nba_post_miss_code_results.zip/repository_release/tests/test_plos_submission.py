from __future__ import annotations

import gzip
import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from src.config import load_config  # noqa: E402
from src.features import add_game_state_features  # noqa: E402
from src.plos_submission import (  # noqa: E402
    coefficient_rows,
    export_cached_derived_data,
    find_forbidden_release_files,
)
from src.post_confirmation import fit_hdfe_covariance  # noqa: E402


class PlosSubmissionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config = load_config(STUDY_ROOT / "study_config.json")

    def test_coefficient_rows_include_complete_inference_and_model_metadata(self) -> None:
        model = {
            "outcome": "shot_distance_feet",
            "predictors": ["miss", "critical"],
            "estimates": {"miss": -1.25, "critical": 0.4},
            "two_way_standard_errors": {"miss": 0.1, "critical": 0.2},
            "p_values_normal": {"miss": 1e-6, "critical": 0.0455},
            "confidence_intervals": {
                "miss": [-1.446, -1.054],
                "critical": [0.008, 0.792],
            },
            "n_obs": 1000,
            "within_r_squared": 0.125,
            "cluster_counts": {"game_id": 20, "player_id": 30},
            "fixed_effect_counts": {"game_id": 20, "player_id_x_season": 40},
            "converged": True,
        }

        rows = coefficient_rows("main", model, "confirmatory", "six seasons")

        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["model_id"], "main")
        self.assertEqual(rows[0]["standard_error"], 0.1)
        self.assertEqual(rows[0]["ci_low"], -1.446)
        self.assertEqual(rows[0]["n_obs"], 1000)
        self.assertEqual(rows[0]["within_r_squared"], 0.125)
        self.assertEqual(rows[0]["fixed_effects"], "game_id|player_id_x_season")
        self.assertEqual(rows[0]["clusters"], "game_id|player_id")
        self.assertTrue(rows[0]["converged"])

    def test_post_confirmation_model_retains_within_r_squared(self) -> None:
        rows = []
        for game in range(1, 7):
            for player in range(1, 6):
                for index in range(4):
                    x = float(index + player / 10)
                    rows.append(
                        {
                            "game_id": game,
                            "player_id": player,
                            "player_id_x_season": f"{player}:2020",
                            "x": x,
                            "y": 2.0 * x + (game % 2) * 0.1,
                        }
                    )
        fitted = fit_hdfe_covariance(
            pd.DataFrame(rows),
            outcome="y",
            predictors=["x"],
            fe_groups=["player_id_x_season", "game_id"],
        ).to_dict()
        self.assertIn("within_r_squared", fitted)
        self.assertGreaterEqual(fitted["within_r_squared"], 0.0)
        self.assertLessEqual(fitted["within_r_squared"], 1.0)

    def _featured_row(self, action_number: int) -> dict[str, object]:
        return {
            "game_id": 1,
            "action_number": action_number,
            "period": 4,
            "clock_seconds": 300.0 - action_number,
            "team_id": 100,
            "player_id": 7,
            "season": 2016,
            "player_id_x_season": "7:2016",
            "is_home_offense": 1,
            "pre_score_home": 100,
            "pre_score_away": 95,
            "shot_distance_feet": 20.0,
            "loc_x": 10.0,
            "loc_y": 10.0,
            "shot_made": 0,
            "previous_personal_action_number": float(action_number - 1),
            "previous_personal_shot_made": 0.0,
            "previous_personal_shot_distance_feet": 18.0,
            "previous_personal_clock_seconds": 310.0 - action_number,
            "previous_personal_pre_score_home": 99.0,
            "previous_personal_pre_score_away": 95.0,
            "previous_personal_is_home_offense": 1.0,
            "personal_interval_seconds": 10.0,
            "offensive_rebound_continuation": False,
            "putback_within_one_second": False,
            "same_stint": True,
            "no_timeout_between_personal_shots": True,
        }

    def test_export_cached_derived_data_reapplies_frozen_sample_and_is_deterministic(self) -> None:
        featured = add_game_state_features(
            pd.DataFrame([self._featured_row(10), self._featured_row(20)]), self.config
        )
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cache = root / "cache"
            out = root / "derived"
            cache.mkdir()
            featured.to_pickle(cache / "enriched_2016.pkl")

            manifest = export_cached_derived_data(
                cache, out, self.config, seasons=[2016]
            )

            self.assertEqual(manifest[0]["rows"], 2)
            self.assertEqual(manifest[0]["season"], 2016)
            path = out / manifest[0]["file"]
            self.assertTrue(path.is_file())
            with gzip.open(path, "rt", encoding="utf-8") as handle:
                exported = pd.read_csv(handle)
            self.assertIn("previous_personal_miss", exported.columns)
            self.assertIn("post_miss_x_critical", exported.columns)
            self.assertNotIn("player_name", exported.columns)
            first_hash = manifest[0]["sha256"]
            second = export_cached_derived_data(cache, out, self.config, seasons=[2016])
            self.assertEqual(first_hash, second[0]["sha256"])

    def test_release_scan_flags_raw_provider_files(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "code").mkdir()
            (root / "code" / "analysis.py").write_text("print('ok')\n", encoding="utf-8")
            (root / "data").mkdir()
            (root / "data" / "nbastatsv3_2016.csv").write_text("raw\n", encoding="utf-8")
            problems = find_forbidden_release_files(root)
            self.assertEqual(problems, ["data/nbastatsv3_2016.csv"])


if __name__ == "__main__":
    unittest.main()
