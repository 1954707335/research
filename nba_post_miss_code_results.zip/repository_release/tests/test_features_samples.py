from __future__ import annotations

import math
import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from src.config import load_config  # noqa: E402
from src.features import add_game_state_features  # noqa: E402
from src.samples import build_main_sample, build_sensitivity_samples  # noqa: E402


class FeatureAndSampleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config = load_config(STUDY_ROOT / "study_config.json")

    def _base_row(self, **updates: object) -> dict[str, object]:
        row: dict[str, object] = {
            "game_id": 1,
            "action_number": 10,
            "period": 4,
            "clock_seconds": 300.0,
            "team_id": 100,
            "player_id": 7,
            "is_home_offense": 1,
            "pre_score_home": 100,
            "pre_score_away": 95,
            "shot_distance_feet": 20.0,
            "loc_x": 10.0,
            "loc_y": 10.0,
            "previous_personal_action_number": 5.0,
            "previous_personal_shot_made": 0.0,
            "previous_personal_shot_distance_feet": 18.0,
            "previous_personal_clock_seconds": 310.0,
            "previous_personal_pre_score_home": 99.0,
            "previous_personal_pre_score_away": 95.0,
            "previous_personal_is_home_offense": 1.0,
            "personal_interval_seconds": 10.0,
            "offensive_rebound_continuation": False,
            "putback_within_one_second": False,
            "same_stint": True,
            "no_timeout_between_personal_shots": True,
        }
        row.update(updates)
        return row

    def test_exact_criticality_boundaries_and_overtime(self) -> None:
        rows = [
            self._base_row(action_number=1, clock_seconds=300.0, pre_score_home=100, pre_score_away=95),
            self._base_row(action_number=2, clock_seconds=300.0001),
            self._base_row(action_number=3, pre_score_home=100, pre_score_away=94),
            self._base_row(action_number=4, pre_score_home=95, pre_score_away=100, is_home_offense=0),
            self._base_row(action_number=5, period=5, clock_seconds=200.0, pre_score_home=100, pre_score_away=100),
        ]
        featured = add_game_state_features(pd.DataFrame(rows), self.config).set_index("action_number")
        self.assertEqual(featured.loc[1, "critical"], 1)
        self.assertEqual(featured.loc[2, "critical"], 0)
        self.assertEqual(featured.loc[3, "critical"], 0)
        self.assertEqual(featured.loc[4, "critical"], 1)
        self.assertEqual(featured.loc[5, "critical"], 0)
        self.assertEqual(featured.loc[4, "offense_signed_pre_shot_margin"], 5)

    def test_heave_boundaries(self) -> None:
        rows = [
            self._base_row(action_number=1, period=3, clock_seconds=3.0, shot_distance_feet=36.0),
            self._base_row(action_number=2, period=3, clock_seconds=3.0001, shot_distance_feet=36.0),
            self._base_row(action_number=3, period=3, clock_seconds=3.0, shot_distance_feet=35.999),
            self._base_row(action_number=4, period=4, clock_seconds=3.0, shot_distance_feet=60.0),
        ]
        featured = add_game_state_features(pd.DataFrame(rows), self.config).set_index("action_number")
        self.assertTrue(featured.loc[1, "heave_proxy"])
        self.assertFalse(featured.loc[2, "heave_proxy"])
        self.assertFalse(featured.loc[3, "heave_proxy"])
        self.assertFalse(featured.loc[4, "heave_proxy"])

    def test_current_previous_and_stable_criticality_are_distinct(self) -> None:
        rows = [
            self._base_row(
                action_number=1,
                previous_personal_clock_seconds=301.0,
                previous_personal_pre_score_home=99.0,
                previous_personal_pre_score_away=95.0,
            ),
            self._base_row(
                action_number=2,
                previous_personal_clock_seconds=299.0,
                previous_personal_pre_score_home=99.0,
                previous_personal_pre_score_away=95.0,
            ),
        ]
        featured = add_game_state_features(pd.DataFrame(rows), self.config).set_index("action_number")
        self.assertEqual(featured.loc[1, "critical"], 1)
        self.assertEqual(featured.loc[1, "previous_personal_critical"], 0)
        self.assertFalse(featured.loc[1, "stable_critical_status"])
        self.assertEqual(featured.loc[2, "previous_personal_critical"], 1)
        self.assertTrue(featured.loc[2, "stable_critical_status"])

    def test_continuous_criticality_formula_and_spline_columns(self) -> None:
        rows = [
            self._base_row(action_number=1, clock_seconds=0.0, pre_score_home=100, pre_score_away=100),
            self._base_row(action_number=2, clock_seconds=300.0, pre_score_home=100, pre_score_away=95),
        ]
        featured = add_game_state_features(pd.DataFrame(rows), self.config).set_index("action_number")
        self.assertAlmostEqual(featured.loc[1, "continuous_criticality"], 1.0, places=12)
        self.assertAlmostEqual(featured.loc[2, "continuous_criticality"], math.exp(-2), places=12)
        self.assertIn("remaining_period_seconds_spline_60", featured.columns)
        self.assertIn("absolute_pre_shot_margin_spline_5", featured.columns)
        self.assertIn("personal_interval_seconds_spline_120", featured.columns)

    def test_exclusion_flow_assigns_every_dropped_row_one_reason(self) -> None:
        rows = [self._base_row(action_number=i) for i in range(1, 9)]
        rows[0]["game_id"] = np.nan
        rows[1]["pre_score_home"] = np.nan
        rows[2]["loc_x"] = np.nan
        rows[3]["previous_personal_action_number"] = np.nan
        rows[4]["previous_personal_shot_distance_feet"] = np.nan
        rows[5]["offensive_rebound_continuation"] = True
        rows[6].update({"period": 3, "clock_seconds": 3.0, "shot_distance_feet": 36.0})
        featured = add_game_state_features(pd.DataFrame(rows), self.config)

        sample, flow = build_main_sample(featured, self.config)

        self.assertEqual(len(sample), 1)
        flow_frame = flow.to_frame().set_index("reason")
        for reason in self.config.main_exclusions:
            self.assertEqual(flow_frame.loc[reason, "excluded_n"], 1)
        self.assertEqual(flow.initial_n, 8)
        self.assertEqual(flow.retained_n, 1)
        self.assertEqual(flow_frame["excluded_n"].sum() + flow.retained_n, flow.initial_n)

    def test_sensitivity_samples_change_only_named_exclusion(self) -> None:
        regular = self._base_row(action_number=1)
        continuation = self._base_row(action_number=2, offensive_rebound_continuation=True)
        putback = self._base_row(
            action_number=3,
            offensive_rebound_continuation=True,
            putback_within_one_second=True,
        )
        featured = add_game_state_features(pd.DataFrame([regular, continuation, putback]), self.config)
        samples = build_sensitivity_samples(featured, self.config)
        self.assertEqual(len(samples["main"]), 1)
        self.assertEqual(len(samples["include_offensive_rebounds"]), 3)
        self.assertEqual(len(samples["exclude_putbacks_only"]), 2)


if __name__ == "__main__":
    unittest.main()
