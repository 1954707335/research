from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from src.analyses import (  # noqa: E402
    ANALYSIS_REGISTRY,
    analysis_required_columns,
    adjust_p_values,
    fixed_effect_meta,
    validate_registry,
)


class AnalysisRegistryTests(unittest.TestCase):
    def test_registry_contains_every_planned_analysis_family(self) -> None:
        identifiers = {entry.analysis_id for entry in ANALYSIS_REGISTRY}
        required = {
            "confirmation_h1",
            "confirmation_h2",
            "pooled_eight_season",
            "season_specific",
            "critical_2min_margin3",
            "critical_5min_margin3",
            "critical_5min_margin8",
            "continuous_criticality",
            "previous_shot_criticality",
            "stable_critical_status",
            "interval_le_120",
            "same_stint",
            "no_timeout",
            "no_pandemic",
            "include_offensive_rebounds",
            "exclude_putbacks_only",
            "period_end_2s",
            "period_end_5s",
            "margin_leading",
            "margin_tied",
            "margin_trailing",
            "q3_placebo",
            "team_lag",
            "global_social_replication",
            "three_point_secondary",
            "leave_one_season_out",
            "leave_one_team_out",
            "high_volume_player_influence",
        }
        self.assertTrue(required.issubset(identifiers), required - identifiers)

    def test_registry_is_unique_and_complete(self) -> None:
        validate_registry(ANALYSIS_REGISTRY)
        identifiers = [entry.analysis_id for entry in ANALYSIS_REGISTRY]
        self.assertEqual(len(identifiers), len(set(identifiers)))
        for entry in ANALYSIS_REGISTRY:
            self.assertIn(entry.status, {"confirmatory", "secondary", "exploratory"})
            self.assertTrue(entry.sample)
            self.assertTrue(entry.outcome)
            self.assertTrue(entry.target_terms)
            self.assertTrue(entry.fixed_effects)
            self.assertTrue(entry.clusters)

    def test_holm_and_bh_adjustments_match_hand_values(self) -> None:
        p = np.array([0.01, 0.04, 0.03])
        np.testing.assert_allclose(adjust_p_values(p, "holm"), [0.03, 0.06, 0.06])
        np.testing.assert_allclose(adjust_p_values(p, "fdr_bh"), [0.03, 0.04, 0.04])

    def test_fixed_effect_meta_matches_inverse_variance_formula(self) -> None:
        result = fixed_effect_meta(np.array([1.0, 2.0]), np.array([1.0, 4.0]))
        self.assertAlmostEqual(result["pooled_effect"], 1.2)
        self.assertAlmostEqual(result["standard_error"], np.sqrt(0.8))

    def test_analysis_cache_prunes_bulky_nonanalytic_columns(self) -> None:
        columns = set(analysis_required_columns())
        self.assertTrue({"shot_distance_feet", "post_miss_x_critical", "same_stint"}.issubset(columns))
        self.assertTrue({"description", "player_name", "shot_action_type", "game_date"}.isdisjoint(columns))
        self.assertLess(len(columns), 70)


if __name__ == "__main__":
    unittest.main()
