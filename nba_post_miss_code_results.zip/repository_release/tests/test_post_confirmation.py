from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from src.post_confirmation import (  # noqa: E402
    REQUIRED_MODEL_IDS,
    holm_adjust,
    linear_contrast,
    moderator_change_spec,
    moderator_effect_scale,
    moderator_high_low_scale,
    probability_diagnostics,
    shot_zone_indicators,
    timeout_design,
    validate_supplement_payload,
    win_probability_leverage,
)


class PostConfirmationUtilitiesTests(unittest.TestCase):
    def test_probability_diagnostics_are_computed_on_supplied_holdout_rows(self) -> None:
        outcome = np.array([0.0, 0.0, 1.0, 1.0])
        prediction = np.array([0.1, 0.2, 0.8, 0.9])
        result = probability_diagnostics(outcome, prediction)
        self.assertEqual(result["rows"], 4)
        self.assertAlmostEqual(result["brier_score"], 0.025)
        self.assertAlmostEqual(result["log_loss"], -np.mean(np.log([0.9, 0.8, 0.8, 0.9])))
        self.assertIn("calibration_intercept", result)
        self.assertIn("calibration_slope", result)

    def test_holm_adjust_is_monotone_and_caps_at_one(self) -> None:
        adjusted = holm_adjust([0.01, 0.04, 0.03, 0.8])
        self.assertEqual(len(adjusted), 4)
        self.assertAlmostEqual(adjusted[0], 0.04)
        self.assertAlmostEqual(adjusted[2], 0.09)
        self.assertAlmostEqual(adjusted[1], 0.09)
        self.assertAlmostEqual(adjusted[3], 0.8)

    def test_moderator_change_spec_labels_binary_and_continuous_scales(self) -> None:
        binary = moderator_change_spec({"q05": 0.0, "q95": 1.0}, binary=True)
        self.assertEqual(binary["effect_scale"], "binary 0→1")
        self.assertEqual(binary["scale_low"], 0.0)
        self.assertEqual(binary["scale_high"], 1.0)
        continuous = moderator_change_spec({"q05": 0.02, "q95": 0.22}, binary=False)
        self.assertEqual(continuous["effect_scale"], "continuous P5→P95")
        self.assertEqual(continuous["scale_low"], 0.02)
        self.assertEqual(continuous["scale_high"], 0.22)
        self.assertAlmostEqual(continuous["scale_change"], 0.20)

    def test_linear_contrast_uses_cross_covariance(self) -> None:
        names = ("miss", "interaction")
        estimates = np.array([-1.0, 0.4])
        covariance = np.array([[0.04, -0.01], [-0.01, 0.09]])
        result = linear_contrast(names, estimates, covariance, {"miss": 1.0, "interaction": 1.0})
        self.assertAlmostEqual(result["estimate"], -0.6)
        self.assertAlmostEqual(result["standard_error"], np.sqrt(0.11))
        self.assertAlmostEqual(result["ci_low"], -0.6 - 1.96 * np.sqrt(0.11))

    def test_timeout_design_contains_full_three_way_hierarchy(self) -> None:
        frame = pd.DataFrame(
            {
                "previous_personal_miss": [0, 1, 1],
                "critical": [1, 0, 1],
                "no_timeout_between_personal_shots": [True, False, False],
            }
        )
        result = timeout_design(frame)
        expected = {
            "intervening_timeout",
            "miss_x_timeout",
            "critical_x_timeout",
            "miss_x_critical_x_timeout",
        }
        self.assertTrue(expected.issubset(result.columns))
        self.assertEqual(result["miss_x_critical_x_timeout"].tolist(), [0.0, 0.0, 1.0])

    def test_shot_zone_indicators_are_mutually_exclusive_and_exhaustive(self) -> None:
        frame = pd.DataFrame(
            {
                "shot_distance_feet": [3.0, 9.0, 18.0, 26.0],
                "is_three_point_attempt": [0, 0, 0, 1],
            }
        )
        result = shot_zone_indicators(frame)
        columns = ["zone_at_rim", "zone_short_two", "zone_long_two", "zone_three"]
        self.assertTrue((result[columns].sum(axis=1) == 1).all())
        self.assertEqual(result[columns].idxmax(axis=1).tolist(), columns)

    def test_win_probability_leverage_uses_pre_shot_state_and_offense_side(self) -> None:
        frame = pd.DataFrame(
            {
                "home_pre_shot_margin": [0.0, 0.0],
                "remaining_game_seconds": [60.0, 60.0],
                "is_home_offense": [1.0, 0.0],
            }
        )
        beta = np.array([0.0, 0.2, -0.1, 0.0, 0.0, 0.0, 0.0])
        result = win_probability_leverage(frame, beta)
        self.assertEqual(len(result), 2)
        self.assertTrue(np.isfinite(result).all())
        self.assertAlmostEqual(result.iloc[0], result.iloc[1])
        self.assertGreater(result.iloc[0], 0)

    def test_required_models_cover_author_requested_checks(self) -> None:
        required = {
            "sealed_refit_covariance",
            "critical_2min_margin3",
            "critical_5min_margin3",
            "critical_5min_margin8",
            "continuous_criticality",
            "win_probability_leverage",
            "interval_le_120",
            "same_stint",
            "no_timeout",
            "timeout_heterogeneity",
            "three_point_secondary",
            "period_fixed_effects",
            "fourth_quarter_only",
            "nonlinear_previous_distance",
        }
        self.assertTrue(required.issubset(REQUIRED_MODEL_IDS))

    def test_binary_moderator_uses_full_zero_to_one_contrast_when_iqr_is_zero(self) -> None:
        self.assertEqual(moderator_effect_scale({"q25": 0.0, "q75": 0.0}, binary=True), 1.0)
        self.assertAlmostEqual(
            moderator_effect_scale({"q25": 0.1, "q75": 0.4}, binary=False), 0.3
        )
        self.assertEqual(
            moderator_high_low_scale({"q05": 0.0, "q95": 0.0}, binary=True), 1.0
        )
        self.assertAlmostEqual(
            moderator_high_low_scale({"q05": 0.02, "q95": 0.22}, binary=False), 0.2
        )

    def test_supplement_payload_requires_status_models_and_sealed_parity(self) -> None:
        payload = {
            "analysis_status": "post_confirmation_supplementary",
            "models": {model_id: {"n_obs": 10} for model_id in REQUIRED_MODEL_IDS},
            "sealed_parity": {
                "h1_difference": 0.0,
                "h2_difference": 0.0,
                "tolerance": 1e-10,
            },
            "analysis_flow": {"rows_excluded_from_regulation_only_moderators": 3508},
            "win_probability_definition": {"validation_scope": "held-out only"},
            "software_versions": {"python": "test"},
            "no_timeout_pooled_parity": {
                "estimate_difference": 0.0,
                "reference_n_obs": 10,
                "refit_n_obs": 10,
                "tolerance": 1e-10,
            },
        }
        validate_supplement_payload(payload)
        incomplete = dict(payload)
        incomplete.pop("win_probability_definition")
        with self.assertRaises(ValueError):
            validate_supplement_payload(incomplete)
        payload["analysis_status"] = "confirmatory"
        with self.assertRaises(ValueError):
            validate_supplement_payload(payload)


if __name__ == "__main__":
    unittest.main()
