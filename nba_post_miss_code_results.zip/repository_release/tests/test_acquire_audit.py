from __future__ import annotations

import hashlib
import io
import sys
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from src.acquire import _download, calculate_sha256, select_dataset_urls, validate_tar_members  # noqa: E402
from src.audit import _score_consistency, audit_season  # noqa: E402
from src.config import load_config  # noqa: E402


class AcquisitionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config = load_config(STUDY_ROOT / "study_config.json")

    def test_exact_filename_selection(self) -> None:
        lines = []
        for season in range(2016, 2024):
            for family in ("nbastatsv3", "shotdetail"):
                name = f"{family}_{season}"
                lines.append(f"{name}=https://example.test/{name}.tar.xz")
            lines.append(f"nbastatsv3_po_{season}=https://example.test/nbastatsv3_po_{season}.tar.xz")
        lines.append("nbastatsv3_2024=https://example.test/nbastatsv3_2024.tar.xz")

        selected = select_dataset_urls("\n".join(lines), self.config)

        expected = {
            f"{family}_{season}"
            for season in range(2016, 2024)
            for family in ("nbastatsv3", "shotdetail")
        }
        self.assertEqual(set(selected), expected)
        self.assertEqual(len(selected), 16)

    def test_checksum_calculation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample.bin"
            path.write_bytes(b"post-miss-study\n")
            expected = hashlib.sha256(b"post-miss-study\n").hexdigest()
            self.assertEqual(calculate_sha256(path), expected)

    def test_safe_tar_member_validation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            safe = Path(tmp) / "safe.tar.xz"
            with tarfile.open(safe, "w:xz") as archive:
                payload = b"a,b\n1,2\n"
                info = tarfile.TarInfo("sample.csv")
                info.size = len(payload)
                archive.addfile(info, io.BytesIO(payload))
            self.assertEqual([m.name for m in validate_tar_members(safe)], ["sample.csv"])

            unsafe = Path(tmp) / "unsafe.tar.xz"
            with tarfile.open(unsafe, "w:xz") as archive:
                payload = b"no"
                info = tarfile.TarInfo("../escape.csv")
                info.size = len(payload)
                archive.addfile(info, io.BytesIO(payload))
            with self.assertRaises(ValueError):
                validate_tar_members(unsafe)

    def test_download_retries_after_transient_timeout(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            destination = Path(tmp) / "sample.tar.xz"
            with patch(
                "src.acquire.urllib.request.urlopen",
                side_effect=[TimeoutError("transient"), io.BytesIO(b"complete")],
            ) as mocked_open:
                _download("https://example.test/sample.tar.xz", destination, attempts=2)
            self.assertEqual(destination.read_bytes(), b"complete")
            self.assertEqual(mocked_open.call_count, 2)


class OutcomeBlindAuditTests(unittest.TestCase):
    def test_score_consistency_ignores_legacy_zero_placeholders(self) -> None:
        pbp = pd.DataFrame(
            [
                {"gameId": 1, "pointsTotal": 2, "scoreHome": 2, "scoreAway": 0},
                {"gameId": 1, "pointsTotal": 0, "scoreHome": 0, "scoreAway": 0},
                {"gameId": 1, "pointsTotal": 2, "scoreHome": 2, "scoreAway": 2},
            ]
        )
        self.assertEqual(_score_consistency(pbp), (0, 0))

    def _write_fixture(self, root: Path) -> tuple[Path, Path]:
        pbp = pd.DataFrame(
            [
                {
                    "gameId": 1,
                    "actionNumber": 10,
                    "period": 1,
                    "clock": "PT11M00.00S",
                    "teamId": 100,
                    "personId": 7,
                    "isFieldGoal": 1,
                    "shotResult": "Made",
                    "scoreHome": 2,
                    "scoreAway": 0,
                    "xLegacy": 1,
                    "yLegacy": 2,
                },
                {
                    "gameId": 1,
                    "actionNumber": 10,
                    "period": 1,
                    "clock": "PT11M00.00S",
                    "teamId": 100,
                    "personId": 7,
                    "isFieldGoal": 1,
                    "shotResult": "Made",
                    "scoreHome": 2,
                    "scoreAway": 0,
                    "xLegacy": 1,
                    "yLegacy": 2,
                },
                {
                    "gameId": 1,
                    "actionNumber": 20,
                    "period": 1,
                    "clock": "PT10M00.00S",
                    "teamId": 200,
                    "personId": 8,
                    "isFieldGoal": 1,
                    "shotResult": "Missed",
                    "scoreHome": 2,
                    "scoreAway": 0,
                    "xLegacy": 3,
                    "yLegacy": 4,
                },
            ]
        )
        shots = pd.DataFrame(
            [
                {
                    "GAME_ID": 1,
                    "GAME_EVENT_ID": 10,
                    "PLAYER_ID": 7,
                    "TEAM_ID": 100,
                    "PERIOD": 1,
                    "MINUTES_REMAINING": 11,
                    "SECONDS_REMAINING": 0,
                    "SHOT_DISTANCE": 18,
                    "LOC_X": 1,
                    "LOC_Y": 2,
                    "SHOT_ATTEMPTED_FLAG": 1,
                    "SHOT_MADE_FLAG": 1,
                    "GAME_DATE": 20221001,
                },
                {
                    "GAME_ID": 1,
                    "GAME_EVENT_ID": 30,
                    "PLAYER_ID": 9,
                    "TEAM_ID": 100,
                    "PERIOD": 1,
                    "MINUTES_REMAINING": 9,
                    "SECONDS_REMAINING": 0,
                    "SHOT_DISTANCE": 22,
                    "LOC_X": 3,
                    "LOC_Y": 4,
                    "SHOT_ATTEMPTED_FLAG": 1,
                    "SHOT_MADE_FLAG": 0,
                    "GAME_DATE": 20221001,
                },
            ]
        )
        pbp_path = root / "pbp.csv"
        shot_path = root / "shots.csv"
        pbp.to_csv(pbp_path, index=False)
        shots.to_csv(shot_path, index=False)
        return pbp_path, shot_path

    def test_duplicate_keys_and_outer_join_anomalies_are_reported(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            pbp_path, shot_path = self._write_fixture(Path(tmp))
            result = audit_season(pbp_path, shot_path, season=2022)
            summary = result.to_record()

            self.assertEqual(summary["duplicate_pbp_fga_key_rows"], 2)
            self.assertEqual(summary["duplicate_shot_key_rows"], 0)
            self.assertEqual(summary["pbp_only_unique_keys"], 1)
            self.assertEqual(summary["shot_only_unique_keys"], 1)
            categories = set(result.anomalies["category"])
            self.assertIn("duplicate_pbp_fga_key", categories)
            self.assertIn("pbp_only_key", categories)
            self.assertIn("shot_only_key", categories)

    def test_audit_cannot_emit_model_coefficients(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            pbp_path, shot_path = self._write_fixture(Path(tmp))
            result = audit_season(pbp_path, shot_path, season=2022)
            forbidden = ("coefficient", "estimate", "p_value", "previous_personal_miss", "critical")
            keys = {key.lower() for key in result.to_record()}
            self.assertFalse(any(token in key for key in keys for token in forbidden))
            self.assertFalse(any(token in col.lower() for col in result.anomalies for token in forbidden))


if __name__ == "__main__":
    unittest.main()
