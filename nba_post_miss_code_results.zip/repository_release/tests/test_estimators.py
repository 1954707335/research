from __future__ import annotations

import math
import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from src.estimators import (  # noqa: E402
    AbsorptionConvergenceError,
    absorb_fixed_effects,
    cluster_covariance,
    fit_hdfe_ols,
    two_way_cluster_covariance,
)


def direct_cluster_covariance(
    X: np.ndarray, residuals: np.ndarray, clusters: np.ndarray
) -> np.ndarray:
    bread = np.linalg.pinv(X.T @ X)
    meat = np.zeros((X.shape[1], X.shape[1]))
    for value in pd.unique(clusters):
        score = X[clusters == value].T @ residuals[clusters == value]
        meat += np.outer(score, score)
    n, k = X.shape
    g = len(pd.unique(clusters))
    correction = (g / (g - 1)) * ((n - 1) / (n - k))
    return correction * bread @ meat @ bread


class FixedEffectEstimatorTests(unittest.TestCase):
    def setUp(self) -> None:
        rng = np.random.default_rng(817)
        rows = []
        for player in range(5):
            for game in range(7):
                if (player + game) % 4 == 0:
                    continue
                for repeat in range(2):
                    x = rng.normal() + 0.2 * player - 0.1 * game
                    y = 1.75 * x + 0.7 * player - 0.4 * game + rng.normal(scale=0.05)
                    rows.append({"player_season": player, "game": game, "x": x, "y": y})
        self.data = pd.DataFrame(rows)

    def test_absorption_matches_explicit_dummy_ols(self) -> None:
        absorbed = absorb_fixed_effects(
            self.data["y"],
            self.data[["x"]],
            [self.data["player_season"], self.data["game"]],
            tol=1e-12,
            max_iter=10_000,
        )
        beta_absorbed = np.linalg.lstsq(absorbed.X, absorbed.y, rcond=None)[0][0]
        player_dummies = pd.get_dummies(self.data["player_season"], drop_first=True, dtype=float)
        game_dummies = pd.get_dummies(self.data["game"], drop_first=True, dtype=float)
        design = np.column_stack(
            [np.ones(len(self.data)), self.data["x"].to_numpy(), player_dummies, game_dummies]
        )
        beta_explicit = np.linalg.lstsq(design, self.data["y"].to_numpy(), rcond=None)[0][1]
        self.assertAlmostEqual(beta_absorbed, beta_explicit, places=9)
        self.assertTrue(absorbed.converged)
        self.assertGreater(absorbed.iterations, 0)

    def test_absorption_raises_on_nonconvergence(self) -> None:
        with self.assertRaises(AbsorptionConvergenceError):
            absorb_fixed_effects(
                self.data["y"],
                self.data[["x"]],
                [self.data["player_season"], self.data["game"]],
                tol=1e-30,
                max_iter=1,
            )

    def test_one_way_and_two_way_cluster_covariance(self) -> None:
        rng = np.random.default_rng(91)
        X = np.column_stack([np.ones(24), rng.normal(size=24), rng.normal(size=24)])
        residuals = rng.normal(size=24)
        game = np.repeat(np.arange(6), 4)
        player = np.tile(np.arange(4), 6)
        intersection = np.array([f"{g}:{p}" for g, p in zip(game, player)], dtype=object)

        expected_game = direct_cluster_covariance(X, residuals, game)
        expected_player = direct_cluster_covariance(X, residuals, player)
        expected_intersection = direct_cluster_covariance(X, residuals, intersection)
        actual_game = cluster_covariance(X, residuals, game)
        actual_two_way = two_way_cluster_covariance(X, residuals, game, player)

        np.testing.assert_allclose(actual_game, expected_game, rtol=0, atol=1e-12)
        np.testing.assert_allclose(
            actual_two_way,
            expected_game + expected_player - expected_intersection,
            rtol=0,
            atol=1e-12,
        )

    def test_model_result_contains_required_diagnostics(self) -> None:
        data = self.data.copy()
        data["absorbed_constant"] = data.groupby("game")["game"].transform("first")
        result = fit_hdfe_ols(
            data,
            outcome="y",
            predictors=["x", "absorbed_constant"],
            fe_groups=["player_season", "game"],
            cluster_groups=["game", "player_season"],
            tol=1e-12,
            max_iter=10_000,
        )
        self.assertIn("x", result.estimates)
        self.assertIn("absorbed_constant", result.dropped_predictors)
        self.assertEqual(result.n_obs, len(data))
        self.assertEqual(result.cluster_counts["game"], data.game.nunique())
        self.assertEqual(result.cluster_counts["player_season"], data.player_season.nunique())
        self.assertTrue(math.isfinite(result.two_way_standard_errors["x"]))
        self.assertEqual(len(result.formula_hash), 64)
        self.assertEqual(len(result.sample_hash), 64)
        self.assertTrue(result.converged)


if __name__ == "__main__":
    unittest.main()
