from __future__ import annotations

import sys
import unittest
from pathlib import Path


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from src.config import StudyConfig, load_config  # noqa: E402


class StudyConfigContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config_path = STUDY_ROOT / "study_config.json"
        cls.config = load_config(cls.config_path)

    def test_confirmation_and_pilot_seasons_do_not_overlap(self) -> None:
        self.assertIsInstance(self.config, StudyConfig)
        self.assertEqual(self.config.confirmation_seasons, (2016, 2017, 2018, 2019, 2020, 2021))
        self.assertEqual(self.config.pilot_seasons, (2022, 2023))
        self.assertTrue(set(self.config.confirmation_seasons).isdisjoint(self.config.pilot_seasons))

    def test_primary_thresholds_are_frozen(self) -> None:
        self.assertEqual(self.config.critical_period, 4)
        self.assertEqual(self.config.critical_clock_seconds_max, 300.0)
        self.assertEqual(self.config.critical_abs_margin_max, 5)
        self.assertEqual(self.config.heave_periods, (1, 2, 3))
        self.assertEqual(self.config.heave_clock_seconds_max, 3.0)
        self.assertEqual(self.config.heave_distance_feet_min, 36.0)
        self.assertEqual(
            self.config.main_exclusions,
            (
                "missing_event_key",
                "missing_pre_shot_state",
                "missing_shot_location",
                "no_same_period_personal_lag",
                "missing_previous_personal_shot_distance",
                "offensive_rebound_continuation",
                "heave_proxy",
            ),
        )

    def test_distance_is_only_primary_outcome(self) -> None:
        self.assertEqual(self.config.primary_outcomes, ("shot_distance_feet",))
        self.assertNotIn("shot_distance_feet", self.config.secondary_outcomes)
        self.assertIn("is_three_point_attempt", self.config.secondary_outcomes)

    def test_no_cross_period_lag(self) -> None:
        self.assertEqual(self.config.main_lag_definition, "same_player_same_game_same_period_prior_fga")
        self.assertFalse(self.config.allow_cross_period_personal_lag)


if __name__ == "__main__":
    unittest.main()
