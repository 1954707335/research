from __future__ import annotations

import math
import sys
import unittest
from pathlib import Path

import numpy as np


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from src.meta import reml_meta  # noqa: E402


class RemlMetaAnalysisTests(unittest.TestCase):
    def test_identical_effects_hit_zero_tau_boundary(self) -> None:
        result = reml_meta(np.array([1.0, 1.0, 1.0]), np.array([0.04, 0.04, 0.04]))
        self.assertAlmostEqual(result.pooled_effect, 1.0, places=12)
        self.assertAlmostEqual(result.tau_squared, 0.0, places=12)
        self.assertAlmostEqual(result.i_squared_percent, 0.0, places=12)
        self.assertAlmostEqual(result.standard_error, math.sqrt(0.04 / 3), places=10)
        self.assertTrue(result.converged)

    def test_two_study_equal_variance_fixture_has_hand_calculable_reml(self) -> None:
        result = reml_meta(np.array([0.0, 2.0]), np.array([1.0, 1.0]), tol=1e-12)
        self.assertAlmostEqual(result.pooled_effect, 1.0, places=10)
        self.assertAlmostEqual(result.tau_squared, 1.0, places=7)
        self.assertAlmostEqual(result.standard_error, 1.0, places=7)
        self.assertAlmostEqual(result.i_squared_percent, 50.0, places=7)
        self.assertAlmostEqual(result.confidence_interval[0], 1.0 - 1.96, places=7)
        self.assertAlmostEqual(result.confidence_interval[1], 1.0 + 1.96, places=7)
        self.assertGreater(result.prediction_interval[1], result.confidence_interval[1])

    def test_invalid_variance_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            reml_meta(np.array([0.0, 1.0]), np.array([1.0, 0.0]))


if __name__ == "__main__":
    unittest.main()
