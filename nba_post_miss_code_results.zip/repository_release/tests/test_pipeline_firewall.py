from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from src.pipeline import (  # noqa: E402
    ConfirmationFirewallError,
    assert_confirmation_allowed,
    create_freeze_manifest,
    stage_output_names,
)


class ConfirmationFirewallTests(unittest.TestCase):
    def _temporary_study(self, root: Path) -> tuple[Path, list[Path]]:
        study = root / "study"
        (study / "src").mkdir(parents=True)
        (study / "tests").mkdir()
        config = study / "study_config.json"
        source = study / "src" / "model.py"
        test = study / "tests" / "test_model.py"
        spec = root / "approved_spec.md"
        manifest = study / "data_manifest.csv"
        config.write_text('{"frozen": true}\n', encoding="utf-8")
        source.write_text("PRIMARY = 'distance'\n", encoding="utf-8")
        test.write_text("assert True\n", encoding="utf-8")
        spec.write_text("approved\n", encoding="utf-8")
        manifest.write_text("status\ncomplete\n", encoding="utf-8")
        return study, [config, source, test, spec, manifest]

    def test_confirm_fails_before_freeze(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            study, _ = self._temporary_study(Path(tmp))
            with self.assertRaises(ConfirmationFirewallError):
                assert_confirmation_allowed(study)

    def test_confirm_fails_after_hashed_file_changes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            study, tracked = self._temporary_study(Path(tmp))
            create_freeze_manifest(study, tracked_paths=tracked)
            tracked[1].write_text("PRIMARY = 'changed'\n", encoding="utf-8")
            with self.assertRaises(ConfirmationFirewallError):
                assert_confirmation_allowed(study)

    def test_confirm_succeeds_only_when_manifest_hashes_match(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            study, tracked = self._temporary_study(Path(tmp))
            freeze_path = create_freeze_manifest(study, tracked_paths=tracked)
            result = assert_confirmation_allowed(study)
            self.assertEqual(result["status"], "frozen_pre_confirmation")
            self.assertEqual(len(result["tracked_files"]), len(tracked))
            self.assertEqual(json.loads(freeze_path.read_text())["status"], "frozen_pre_confirmation")

    def test_audit_and_pilot_outputs_cannot_use_confirmation_names(self) -> None:
        forbidden = {"confirmation_primary.json", "confirmation_by_season.csv"}
        self.assertTrue(forbidden.isdisjoint(stage_output_names("audit")))
        self.assertTrue(forbidden.isdisjoint(stage_output_names("pilot")))
        self.assertTrue(forbidden.issubset(stage_output_names("confirm")))


if __name__ == "__main__":
    unittest.main()
