from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from src.reporting import build_primary_table, format_p_value, write_figure_data  # noqa: E402


class ReportingTests(unittest.TestCase):
    def test_primary_table_traces_exactly_to_sealed_result(self) -> None:
        payload = {
            "analysis_label": "held_out_confirmation",
            "pooled_model": {"n_obs": 1234},
            "hypotheses": {
                "h1": {"estimate": -1.2, "standard_error_two_way": 0.2, "confidence_interval": [-1.592, -0.808], "p_normal": 1e-8, "direction_supported": True},
                "h2": {"estimate": 0.5, "standard_error_two_way": 0.1, "confidence_interval": [0.304, 0.696], "p_normal": 2e-6, "direction_supported": True},
            },
        }
        table = build_primary_table(payload)
        self.assertEqual(table["analysis_status"].unique().tolist(), ["confirmatory"])
        self.assertEqual(table.loc[table.term.eq("H1"), "estimate_feet"].iloc[0], -1.2)
        self.assertEqual(table.loc[table.term.eq("H2"), "ci_high_feet"].iloc[0], 0.696)
        self.assertEqual(table["n_obs"].unique().tolist(), [1234])

    def test_p_values_are_never_rendered_as_zero(self) -> None:
        self.assertEqual(format_p_value(1e-12), "<.001")
        self.assertEqual(format_p_value(0.03456), ".035")
        self.assertEqual(format_p_value(0.8), ".800")

    def test_figure_data_written_equals_supplied_plot_input(self) -> None:
        frame = pd.DataFrame({"label": ["a", "b"], "estimate": [1.25, -0.5]})
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "figure_data.csv"
            write_figure_data(frame, path)
            observed = pd.read_csv(path)
        pd.testing.assert_frame_equal(observed, frame)


if __name__ == "__main__":
    unittest.main()
