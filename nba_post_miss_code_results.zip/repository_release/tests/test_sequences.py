from __future__ import annotations

import sys
import unittest
from pathlib import Path

import pandas as pd


STUDY_ROOT = Path(__file__).resolve().parents[1]
FIXTURES = Path(__file__).resolve().parent / "fixtures"
sys.path.insert(0, str(STUDY_ROOT))

from src.events import build_shot_events, canonicalize_pbp_events  # noqa: E402
from src.sequences import (  # noqa: E402
    add_global_lag,
    add_global_interval_flags,
    add_personal_interval_flags,
    add_personal_lag,
    add_team_lag,
    classify_interval,
)


class SequenceConstructionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.pbp = pd.read_csv(FIXTURES / "synthetic_pbp.csv")
        cls.details = pd.read_csv(FIXTURES / "synthetic_shots.csv")
        cls.shots, _ = build_shot_events(cls.pbp, cls.details)
        cls.events = canonicalize_pbp_events(cls.pbp)

    def test_personal_lag_resets_at_period_boundary(self) -> None:
        lagged = add_personal_lag(self.shots).set_index("action_number")
        self.assertEqual(lagged.loc[22, "previous_personal_action_number"], 20)
        self.assertEqual(lagged.loc[44, "previous_personal_action_number"], 40)
        self.assertTrue(pd.isna(lagged.loc[110, "previous_personal_action_number"]))
        self.assertEqual(lagged.loc[120, "previous_personal_action_number"], 110)
        self.assertTrue((lagged["personal_interval_seconds"].dropna() >= 0).all())

    def test_team_and_global_lag_definitions_differ(self) -> None:
        personal = add_personal_lag(self.shots).set_index("action_number")
        team = add_team_lag(self.shots).set_index("action_number")
        global_lag = add_global_lag(self.shots).set_index("action_number")
        self.assertEqual(personal.loc[40, "previous_personal_action_number"], 22)
        self.assertEqual(team.loc[40, "previous_team_action_number"], 22)
        self.assertEqual(global_lag.loc[40, "previous_global_action_number"], 30)
        self.assertEqual(global_lag.loc[40, "previous_global_relation"], "opponent")
        self.assertEqual(global_lag.loc[22, "previous_global_relation"], "self")

    def test_offensive_rebound_and_one_second_putback_flags(self) -> None:
        indexed = self.shots.set_index("action_number", drop=False)
        flags = classify_interval(self.events, indexed.loc[20], indexed.loc[22])
        self.assertTrue(flags.offensive_rebound_continuation)
        self.assertTrue(flags.putback_within_one_second)
        self.assertFalse(flags.possession_reset)
        self.assertEqual(flags.elapsed_game_seconds, 1.0)

    def test_timeout_substitution_and_bench_return_are_retained(self) -> None:
        indexed = self.shots.set_index("action_number", drop=False)
        flags = classify_interval(self.events, indexed.loc[40], indexed.loc[44])
        self.assertTrue(flags.timeout_between)
        self.assertTrue(flags.substitution_out_between)
        self.assertTrue(flags.substitution_in_between)
        self.assertTrue(flags.bench_return)
        self.assertEqual(flags.elapsed_game_seconds, 40.0)

    def test_defensive_rebound_and_turnover_mark_resets(self) -> None:
        indexed = self.shots.set_index("action_number", drop=False)
        rebound_reset = classify_interval(self.events, indexed.loc[22], indexed.loc[40])
        turnover_reset = classify_interval(self.events, indexed.loc[44], indexed.loc[50])
        self.assertTrue(rebound_reset.possession_reset)
        self.assertTrue(turnover_reset.possession_reset)

    def test_vectorized_global_interval_flags_match_event_classifier(self) -> None:
        flagged = add_global_interval_flags(self.shots, self.events).set_index("action_number")
        self.assertTrue(flagged.loc[22, "offensive_rebound_continuation"])
        self.assertTrue(flagged.loc[22, "putback_within_one_second"])
        self.assertTrue(flagged.loc[40, "possession_reset"])
        self.assertTrue(flagged.loc[44, "timeout_between_global_shots"])
        self.assertTrue(flagged.loc[50, "turnover_between_global_shots"])

    def test_same_clock_uses_event_id_not_nonmonotonic_action_number(self) -> None:
        pbp = self.pbp.copy()
        details = self.details.copy()
        pbp.loc[pbp.actionNumber.eq(22), "actionNumber"] = 19
        details.loc[details.GAME_EVENT_ID.eq(22), "GAME_EVENT_ID"] = 19
        shots, _ = build_shot_events(pbp, details)
        events = canonicalize_pbp_events(pbp)
        flagged = add_global_interval_flags(shots, events).set_index("action_number")
        self.assertTrue(flagged.loc[19, "offensive_rebound_continuation"])

    def test_personal_interval_flags_detect_timeout_and_bench_return(self) -> None:
        flagged = add_personal_interval_flags(self.shots, self.events).set_index("action_number")
        self.assertTrue(flagged.loc[44, "timeout_between_personal_shots"])
        self.assertTrue(flagged.loc[44, "substitution_out_between_personal_shots"])
        self.assertTrue(flagged.loc[44, "bench_return"])
        self.assertFalse(flagged.loc[44, "same_stint"])
        self.assertFalse(flagged.loc[44, "no_timeout_between_personal_shots"])
        self.assertTrue(flagged.loc[22, "same_stint"])


if __name__ == "__main__":
    unittest.main()
