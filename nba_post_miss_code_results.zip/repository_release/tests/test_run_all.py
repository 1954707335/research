from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from run_all import (  # noqa: E402
    _generated_relative_paths,
    _manuscript_counts,
    ReproductionError,
    build_final_manifest,
    compare_artifacts,
    find_raw_redistribution,
    validate_version_dir,
)


class RunAllTests(unittest.TestCase):
    def test_clean_reproduction_compares_only_frozen_pipeline_outputs(self) -> None:
        paths = {path.as_posix() for path in _generated_relative_paths(STUDY_ROOT)}
        self.assertIn("tables/table_4_secondary_robustness.csv", paths)
        self.assertIn("supplement/supplementary_results.md", paths)
        self.assertNotIn("tables/table_9_no_timeout_decomposition.csv", paths)
        self.assertNotIn("supplement/post_confirmation_supplement.md", paths)

    def test_manifest_excludes_circular_self_and_final_checkpoint(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            study = Path(tmp)
            (study / "checkpoints").mkdir()
            (study / "README.md").write_text("release\n", encoding="utf-8")
            (study / "final_file_manifest.csv").write_text("old\n", encoding="utf-8")
            (study / "checkpoints" / "task10_final.sha256").write_text(
                "old\n", encoding="utf-8"
            )
            (study / "src" / "__pycache__").mkdir(parents=True)
            (study / "src" / "__pycache__" / "module.pyc").write_bytes(b"cache")
            (study / "manuscript").mkdir()
            (study / "manuscript" / "~$draft.docx").write_bytes(b"lock")
            manifest = pd.read_csv(build_final_manifest(study))
            self.assertEqual(manifest["path"].tolist(), ["README.md"])

    def test_manuscript_counts_abstract_before_keywords(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            manuscript = Path(tmp) / "manuscript.md"
            manuscript.write_text(
                "# Title\n\n## Abstract\n\none two three\n\n"
                "**Keywords:** x; y\n\n## 1. Introduction\n\nfour five\n",
                encoding="utf-8",
            )
            total, abstract = _manuscript_counts(manuscript)
            self.assertGreater(total, abstract)
            self.assertEqual(abstract, 3)

    def test_version_directory_cannot_target_study_or_results(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            study = Path(tmp) / "study"
            (study / "results").mkdir(parents=True)
            for candidate in (study, study / "results", study / "results" / "nested"):
                with self.subTest(candidate=candidate):
                    with self.assertRaises(ReproductionError):
                        validate_version_dir(study, candidate)

    def test_version_directory_must_be_new_and_outside_study(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            study = root / "study"
            study.mkdir()
            candidate = root / "clean_version"
            validate_version_dir(study, candidate)
            candidate.mkdir()
            with self.assertRaises(ReproductionError):
                validate_version_dir(study, candidate)

    def test_artifact_comparison_requires_byte_identity(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            reference = root / "reference"
            candidate = root / "candidate"
            (reference / "results").mkdir(parents=True)
            (candidate / "results").mkdir(parents=True)
            relative = Path("results/example.csv")
            (reference / relative).write_text("x\n1\n", encoding="utf-8")
            (candidate / relative).write_text("x\n1\n", encoding="utf-8")
            exact = compare_artifacts(reference, candidate, [relative])
            self.assertTrue(bool(exact.loc[0, "byte_identical"]))
            (candidate / relative).write_text("x\n2\n", encoding="utf-8")
            changed = compare_artifacts(reference, candidate, [relative])
            self.assertFalse(bool(changed.loc[0, "byte_identical"]))

    def test_raw_provider_csvs_are_detected_below_release_root(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "nested").mkdir()
            clean = root / "nested" / "derived.csv"
            clean.write_text("x\n1\n", encoding="utf-8")
            self.assertEqual(find_raw_redistribution(root), [])
            raw = root / "nested" / "nbastatsv3_2023.csv"
            raw.write_text("raw\n", encoding="utf-8")
            self.assertEqual(find_raw_redistribution(root), [raw.resolve()])


if __name__ == "__main__":
    unittest.main()
