#!/usr/bin/env python3
"""Run and validate all post-confirmation six/eight-season revision analyses."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from src.pipeline import assert_confirmation_allowed, validate_raw_manifest
from src.post_confirmation import run_post_confirmation, validate_supplement_payload


SEALED_HASHES = {
    "results/confirmation_primary.json": "1a2513226a30479f623f7a56b964a54ea21cbd8262a280bc5cdc31f49924a472",
    "results/confirmation_by_season.csv": "44ebb8418223af15040794a7ca7ec0f9bc2b04051418993853eebdc35aa58d4d",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study-root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--cache-dir", type=Path, required=True)
    args = parser.parse_args()
    study_root = args.study_root.resolve()
    assert_confirmation_allowed(study_root)
    validate_raw_manifest(study_root, args.raw_dir)
    before = {
        relative: sha256(study_root / relative) for relative in SEALED_HASHES
    }
    if before != SEALED_HASHES:
        raise RuntimeError("sealed confirmation hashes do not match the verified reference")
    payload = run_post_confirmation(study_root, args.raw_dir, args.cache_dir)
    validate_supplement_payload(payload)
    after = {
        relative: sha256(study_root / relative) for relative in SEALED_HASHES
    }
    if after != before:
        raise RuntimeError("sealed confirmation artifacts changed during revision run")
    persisted = json.loads(
        (study_root / "results" / "post_confirmation_six_season.json").read_text(
            encoding="utf-8"
        )
    )
    validate_supplement_payload(persisted)
    print("PASS: six/eight-season revision analyses reproduced; sealed outputs unchanged")


if __name__ == "__main__":
    main()

