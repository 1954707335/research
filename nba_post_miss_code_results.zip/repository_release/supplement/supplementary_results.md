# Supplementary results

## Analysis integrity

- Sealed held-out confirmation artifact: `results/confirmation_primary.json`.
- Expanded registry: 80 unique model outputs; result status counts: {'ok': 80}.
- Fitted models: 78; all reported model diagnostics and coefficients are in `all_coefficients.csv`.
- Multiplicity-adjusted target tests: `results/multiplicity_adjusted.csv`.

## Data audit and anomaly handling

The blind field audit is reproduced in `tables/table_1_data_quality.csv`. Duplicate or unmatched keys were emitted as explicit anomalies before modeling. Category counts and the exclusion decision are in `anomaly_decisions.csv`; raw third-party event files are not redistributed.

## Confirmation sample flow

Every fixed-order exclusion for the six held-out seasons is in `confirmation_exclusion_flow.csv`. No model row was silently dropped after the explicit missing-previous-distance exclusion was added before the analysis freeze.

## Cross-season synthesis

The REML H2 estimate was 0.497 ft (SE=0.108), tau-squared=0.0080, I-squared=3.3%. Full random- and fixed-effect results plus leave-one-season meta-analyses are in `results/meta_analysis.csv`.

## Internally prespecified robustness and falsification tests

All internally prespecified target coefficients, raw p-values, Holm/FDR families, and adjusted p-values appear in `tables/table_4_secondary_robustness.csv` and `results/multiplicity_adjusted.csv`. The third-quarter matched-window placebo was specified before output generation. The social-context joint model directly tests teammate-minus-self coefficient differences; it does not infer a difference from separate significance tests.

## Post-confirmation additions

Reviewer-motivated analyses are documented separately in `post_confirmation_supplement.md`. They retain their post-confirmation label and do not alter the sealed confirmation artifact.

## Reproduction pointers

The exact expanded registry is `results/model_registry.csv`; model/sample/formula hashes are in `all_coefficients.csv` and `results/all_models.json`. Figure source CSV files sit beside each PNG/SVG and are the exact frames passed to plotting functions.
