# Post-confirmation supplementary analyses

## Status and provenance

These analyses were added after the held-out confirmation coefficients had been exposed. They address construct validity, covariance reporting, timeout heterogeneity, and specification robustness. Every output is labeled `post_confirmation_supplementary`; none is presented as preregistered or confirmatory. The original freeze and sealed outputs were not modified.

The machine-readable result is `results/post_confirmation_six_season.json`. It retains every fitted covariance matrix, model sample hash, filter record, software version, win-probability coefficient vector, and held-out validation statistic. Long-form estimates are in `tables/table_5_six_season_supplementary.csv`; construct summaries, timeout contrasts, shot-zone estimates, no-timeout decomposition, and win-probability validation appear in Tables 6–10.

## Covariance-preserving refit

The primary six-season model was refit under the same sample and specification while retaining the complete covariance matrix. The sealed coefficients were reproduced exactly to displayed precision: previous personal miss = −1.375946 ft and miss × criticality = 0.513884 ft. Their linear combination yielded a critical-state post-miss contrast of −0.862063 ft (SE = 0.152639, 95% CI [−1.161236, −0.562889], p < .001).

## Criticality constructs

All models below use the six held-out seasons. Alternative binary interactions were 0.534830 ft for the last two minutes within three points, 0.441526 ft for the last five minutes within three points, and 0.442837 ft for the last five minutes within eight points. Their raw two-sided p-values were .028, .008, and <.001; Holm-adjusted p-values within the five-test criticality-construct family were .028, .016, and <.001.

The continuous time-margin interaction was 0.988103 ft per unit (95% CI [0.394530, 1.581676], raw p = .001, Holm p = .004). The moderator's 5th and 95th percentiles were 0.000043 and 0.196584, implying a 0.194203-ft interaction over that observed range. This regulation-only model used 712,948 observations. The 3,508 observations not shared with the primary model were all overtime attempts: 3,098 in period 5, 340 in period 6, 57 in period 7, and 13 in period 8.

For each held-out season, pre-shot home-win probability was predicted by a model trained on the other five seasons. The logistic basis contained an intercept, home margin, margin cubed divided by 100, log remaining regulation seconds, its square, margin × log time, and margin divided by the square root of remaining seconds plus one. The two-point counterfactual added two home-margin points for a home-offense shot and subtracted two for an away-offense shot. Leverage was the absolute counterfactual-minus-baseline probability change; the current shot's outcome was not used. The pooled held-out predictions had Brier score 0.168461, log loss 0.495265, calibration intercept 0.001145, and calibration slope 0.997815. Season-level intercepts ranged from −0.099608 to 0.135317 and slopes from 0.975721 to 1.039075.

The leverage interaction was 2.276788 ft per unit (95% CI [0.743528, 3.810049], raw p = .004, Holm p = .011). The 5th and 95th percentiles were 0.001581 and 0.099686, implying a 0.223365-ft interaction over that range. Binary estimates are reported for a 0→1 change; continuous estimates are reported from P5→P95 with both endpoints. Raw per-unit coefficients should not be compared across differently scaled moderators.

## Multiplicity families

Three post-confirmation families were specified for transparent reporting. Holm adjustment was applied to five alternative criticality-construct interactions; seven sequence/specification interactions (short interval, same stint, no timeout, three-point outcome, period fixed effects, fourth-quarter restriction, and nonlinear previous-distance control); and four shot-zone interactions. The sealed primary result, the covariance-based critical-state contrast, and the single formal timeout-group difference are focused contrasts and are shown without a post hoc family adjustment. Machine-readable tables contain both raw and Holm-adjusted p-values.

## Sequence and specification checks

The interaction was 0.523687 ft with personal intervals ≤120 seconds, 0.445685 ft when the player remained in the same stint, 0.513788 ft after adding period fixed effects, 0.594587 ft in fourth-quarter attempts only, and 0.514407 ft with nonlinear control for previous-shot distance. All five 95% confidence intervals excluded zero and all five Holm-adjusted p-values were ≤ .0053.

## Timeout heterogeneity

The standalone six-season no-timeout estimate was 0.468034 ft (95% CI [0.023584, 0.912483], raw and Holm p = .039). In contrast, the two pilot seasons yielded −0.456795 ft (95% CI [−1.061126, 0.147536]), and the pooled eight-season estimate was 0.227256 ft (95% CI [−0.153154, 0.607665], p = .242). A pooled interaction model estimated the pilot-minus-confirmation difference as −0.926616 ft (95% CI [−1.632384, −0.220849], p = .010). The eight-season refit matched the original coefficient to 2.78 × 10⁻¹⁷ and reproduced N = 601,089. The 0.227-versus-0.468 change is therefore a sample-period composition result, not a coding discrepancy.

The fully interacted six-season model estimated a miss × criticality effect of 0.478824 ft without an intervening timeout and 0.152415 ft with an intervening timeout. The direct with-timeout minus no-timeout difference was −0.326409 ft (SE = 0.268454, 95% CI [−0.852578, 0.199760], p = .224). The wide interval crosses zero. It neither establishes that timeouts weaken the moderation effect nor establishes equivalence between the two sequence types.

Critical-state cell counts were 5,696 previous makes and 5,560 previous misses without a timeout, and 8,556 previous makes and 10,248 previous misses with a timeout. The non-critical cells contained 217,503 previous makes and 212,114 previous misses without a timeout, and 125,086 previous makes and 131,693 previous misses with a timeout.

## Shot-type outcomes

After a miss, the probability of an at-rim attempt increased by 5.042 percentage points and a short two by 1.001 points; the probability of a long two decreased by 1.068 points and a three-pointer by 4.976 points. Criticality changed these post-miss shifts by −1.734, −0.316, −0.043, and +2.094 percentage points, respectively. Holm-adjusted p-values for these four interactions were .008, 1.000, 1.000, and .002. Table 8 reports probability estimates and intervals only in percentage points; no foot-based unit applies.

These models describe selection among shot locations. They do not establish that misses are decision errors, that shorter shots are psychologically cautious, or that any observed selection is causally produced by pressure.
