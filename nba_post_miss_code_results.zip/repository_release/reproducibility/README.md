# Reproducibility attachment

This directory documents the post-confirmation revision workflow. Raw NBA-derived CSV files are not redistributed. Obtain the exact inputs listed in `../data_manifest.csv`, verify their sizes and SHA-256 hashes, and place them in a local raw-data directory.

Run the unified revision analysis from the study root:

```bash
python3 run_revision.py \
  --raw-dir /absolute/path/to/raw \
  --cache-dir /absolute/path/to/cache
```

The runner validates the frozen analysis contract and raw-data manifest, verifies the two sealed confirmation hashes, reproduces the six-season supplementary analyses and pooled eight-season no-timeout check, writes full covariance matrices and sample hashes, and confirms that sealed outputs remain unchanged.

Key machine-readable files:

- `../results/post_confirmation_six_season.json`: complete models, covariance matrices, sample hashes, filters, software versions, cross-fitting definitions, coefficients, and calibration diagnostics.
- `../tables/table_5_six_season_supplementary.csv`: long-form estimates with raw and Holm-adjusted p-values.
- `../tables/table_6_criticality_constructs.csv`: binary 0→1 and continuous P5→P95 construct comparisons.
- `../tables/table_9_no_timeout_decomposition.csv`: eight single-season estimates, six/two/eight-season summaries, and the formal pilot-minus-confirmation difference.
- `../tables/table_10_win_probability_validation.csv`: held-out calibration by target season and pooled.
- `software_versions.json`: recorded analysis runtime.

The PLOS ONE submission builder additionally writes:

- `submission_plos_one/derived_data/`: six compressed confirmation-season analysis datasets, a variable dictionary, and a SHA-256 manifest.
- `submission_plos_one/supporting_information/S1`–`S5`: complete coefficient-level results, calibration diagnostics, exclusions, and anomalies.
- `submission_plos_one/supporting_information/S6_STROBE_checklist.docx`: completed reporting checklist.
- `submission_plos_one/repository_release/`: the public-release candidate containing code, tests, documentation, derived data, and machine-readable results but no provider raw CSV files.

A permanent public repository or DOI must be supplied only after the authors choose a hosting service. Until then, this local attachment is complete but does not claim a public access URL.

