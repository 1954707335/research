#!/usr/bin/env python3
"""Run a clean, versioned reproduction without touching sealed study results."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Sequence

import pandas as pd

from src.analyses import run_registered_analyses
from src.config import load_config
from src.pipeline import (
    assert_confirmation_allowed,
    run_audit_stage,
    run_confirm_stage,
    run_pilot_stage,
    validate_raw_manifest,
)
from src.reporting import run_reporting


class ReproductionError(RuntimeError):
    """Raised when a clean reproduction violates a safety or equality check."""


RAW_PROVIDER_PREFIXES = ("nbastatsv3_", "shotdetail_")
SEALED_CONFIRMATION = (
    Path("results/confirmation_primary.json"),
    Path("results/confirmation_by_season.csv"),
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
    except ValueError:
        return False
    return True


def validate_version_dir(study_root: Path, version_dir: Path) -> None:
    study_root = Path(study_root).resolve()
    version_dir = Path(version_dir).resolve()
    protected_results = study_root / "results"
    if version_dir == study_root or _is_relative_to(version_dir, protected_results):
        raise ReproductionError("version directory cannot be the study root or its results tree")
    if version_dir.exists():
        raise ReproductionError(f"version directory must not already exist: {version_dir}")


def compare_artifacts(
    reference_root: Path, candidate_root: Path, relative_paths: Sequence[Path]
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for relative in relative_paths:
        relative = Path(relative)
        reference = Path(reference_root) / relative
        candidate = Path(candidate_root) / relative
        reference_hash = sha256(reference) if reference.is_file() else ""
        candidate_hash = sha256(candidate) if candidate.is_file() else ""
        rows.append(
            {
                "path": relative.as_posix(),
                "reference_exists": reference.is_file(),
                "candidate_exists": candidate.is_file(),
                "reference_sha256": reference_hash,
                "candidate_sha256": candidate_hash,
                "byte_identical": bool(reference_hash and reference_hash == candidate_hash),
            }
        )
    return pd.DataFrame.from_records(rows)


def find_raw_redistribution(release_root: Path) -> list[Path]:
    release_root = Path(release_root).resolve()
    matches = []
    for path in release_root.rglob("*.csv"):
        if path.name.lower().startswith(RAW_PROVIDER_PREFIXES):
            matches.append(path.resolve())
    return sorted(matches)


def _generated_relative_paths(study_root: Path) -> list[Path]:
    result_names = {
        "data_audit.csv",
        "data_anomalies.csv",
        "pilot_pipeline_dry_run.json",
        "pilot_by_season.csv",
        "confirmation_primary.json",
        "confirmation_by_season.csv",
        "model_registry.csv",
        "all_models.json",
        "meta_analysis.csv",
        "multiplicity_adjusted.csv",
    }
    paths = [Path("results") / name for name in sorted(result_names)]
    paths.extend(
        Path("tables") / name
        for name in (
            "table_1_data_quality.csv",
            "table_2_descriptives.csv",
            "table_3_primary_models.csv",
            "table_4_secondary_robustness.csv",
        )
    )
    for figure in range(1, 5):
        stem = {
            1: "sample_flow",
            2: "marginal_distance",
            3: "season_forest",
            4: "continuous_criticality",
        }[figure]
        for suffix in ("data.csv", "png", "svg"):
            paths.append(Path("figures") / f"figure_{figure}_{stem}.{suffix}")
    paths.extend(
        Path("supplement") / name
        for name in (
            "all_coefficients.csv",
            "anomaly_decisions.csv",
            "confirmation_exclusion_flow.csv",
            "supplementary_results.md",
        )
    )
    return sorted(paths)


def _copy_release_documents(study_root: Path, version_dir: Path) -> None:
    for name in ("README.md", "study_config.json", "data_manifest.csv", "analysis_freeze.json"):
        shutil.copy2(study_root / name, version_dir / name)
    shutil.copytree(study_root / "manuscript", version_dir / "manuscript")
    shutil.copy2(
        study_root / "results" / "variable_dictionary.csv",
        version_dir / "results" / "variable_dictionary.csv",
    )


def _manuscript_counts(manuscript: Path) -> tuple[int, int]:
    text = manuscript.read_text(encoding="utf-8")
    word_count = len(text.split())
    abstract = ""
    if "## Abstract" in text:
        abstract = text.split("## Abstract", 1)[1].split("\n## ", 1)[0]
        abstract = abstract.split("**Keywords:**", 1)[0]
    return word_count, len(abstract.split())


def _write_log(
    path: Path,
    *,
    started: datetime,
    elapsed_seconds: float,
    study_root: Path,
    raw_dir: Path,
    version_dir: Path,
    comparison: pd.DataFrame,
    sealed_before: dict[str, str],
    sealed_after: dict[str, str],
) -> None:
    confirmation = json.loads(
        (version_dir / "results" / "confirmation_primary.json").read_text(encoding="utf-8")
    )
    h1 = confirmation["hypotheses"]["h1"]
    h2 = confirmation["hypotheses"]["h2"]
    words, abstract_words = _manuscript_counts(version_dir / "manuscript" / "manuscript.md")
    lines = [
        "NBA post-miss study: clean reproduction log",
        f"started_utc: {started.isoformat()}",
        f"completed_utc: {datetime.now(timezone.utc).isoformat()}",
        f"elapsed_seconds: {elapsed_seconds:.3f}",
        f"study_root: {study_root}",
        f"raw_input_directory: {raw_dir}",
        f"clean_version_directory: {version_dir}",
        "raw_provider_files_redistributed: no",
        f"artifacts_compared: {len(comparison)}",
        f"artifacts_byte_identical: {int(comparison['byte_identical'].sum())}",
        f"sealed_confirmation_unchanged: {sealed_before == sealed_after}",
        f"confirmation_n: {confirmation['pooled_model']['n_obs']}",
        f"h1_estimate_feet: {h1['estimate']:.15g}",
        f"h1_se_two_way: {h1['standard_error_two_way']:.15g}",
        f"h1_p_normal: {h1['p_normal']:.15g}",
        f"h2_estimate_feet: {h2['estimate']:.15g}",
        f"h2_se_two_way: {h2['standard_error_two_way']:.15g}",
        f"h2_p_normal: {h2['p_normal']:.15g}",
        f"manuscript_whitespace_word_count: {words}",
        f"abstract_whitespace_word_count: {abstract_words}",
        "status: PASS",
        "note: Statistical artifacts were regenerated from validated raw inputs in a new directory.",
        "note: Manuscript and documentation files were copied only after numerical equality checks.",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_final_manifest(study_root: Path) -> Path:
    study_root = Path(study_root).resolve()
    manifest_path = study_root / "final_file_manifest.csv"
    # Self-hashes and the checkpoint that hashes this manifest would be circular.
    excluded = {
        manifest_path.resolve(),
        (study_root / "checkpoints" / "task10_final.sha256").resolve(),
    }
    rows = []
    for path in sorted(study_root.rglob("*")):
        if not path.is_file() or path.resolve() in excluded:
            continue
        relative = path.relative_to(study_root)
        if "__pycache__" in relative.parts or path.suffix == ".pyc" or path.name.startswith("~$"):
            continue
        top = relative.parts[0]
        if top == "manuscript":
            category = "manuscript"
        elif top in {"results", "tables", "figures", "supplement"}:
            category = "analysis_output"
        elif top == "src":
            category = "source_code"
        elif top == "tests":
            category = "test"
        elif top == "checkpoints":
            category = "integrity_checkpoint"
        else:
            category = "project_documentation"
        rows.append(
            {
                "path": relative.as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
                "category": category,
                "public_release": "yes",
                "notes": "Raw third-party event data excluded from release.",
            }
        )
    with manifest_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return manifest_path


def run_clean_reproduction(study_root: Path, raw_dir: Path, version_dir: Path) -> Path:
    study_root = Path(study_root).resolve()
    raw_dir = Path(raw_dir).resolve()
    version_dir = Path(version_dir).resolve()
    validate_version_dir(study_root, version_dir)
    assert_confirmation_allowed(study_root)
    validate_raw_manifest(study_root, raw_dir)
    redistributed = find_raw_redistribution(study_root)
    if redistributed:
        raise ReproductionError(f"raw provider CSVs found in release tree: {redistributed}")

    sealed_before = {relative.as_posix(): sha256(study_root / relative) for relative in SEALED_CONFIRMATION}
    started = datetime.now(timezone.utc)
    started_clock = time.monotonic()
    results = version_dir / "results"
    cache = version_dir / "cache"
    results.mkdir(parents=True)

    config = load_config(study_root / "study_config.json")
    print("stage 1/5: audit", flush=True)
    run_audit_stage(config, raw_dir, results)
    print("stage 2/5: pilot", flush=True)
    run_pilot_stage(config, study_root, raw_dir, results)
    print("stage 3/5: held-out confirmation", flush=True)
    run_confirm_stage(config, study_root, raw_dir, results)

    confirmation_check = compare_artifacts(study_root, version_dir, list(SEALED_CONFIRMATION))
    if not confirmation_check["byte_identical"].all():
        raise ReproductionError("regenerated held-out confirmation is not byte-identical")

    print("stage 4/5: registered pooled and robustness analyses", flush=True)
    run_registered_analyses(study_root, raw_dir, results, cache)
    print("stage 5/5: tables, figures, and supplement", flush=True)
    run_reporting(version_dir)

    relative_paths = _generated_relative_paths(study_root)
    comparison = compare_artifacts(study_root, version_dir, relative_paths)
    comparison.to_csv(
        version_dir / "reproduction_comparison.csv", index=False, lineterminator="\n"
    )
    if not comparison["byte_identical"].all():
        failures = comparison.loc[~comparison["byte_identical"], "path"].tolist()
        raise ReproductionError(f"regenerated artifacts differ: {failures}")

    sealed_after = {relative.as_posix(): sha256(study_root / relative) for relative in SEALED_CONFIRMATION}
    if sealed_before != sealed_after:
        raise ReproductionError("original sealed confirmation changed during reproduction")

    _copy_release_documents(study_root, version_dir)
    elapsed = time.monotonic() - started_clock
    version_log = version_dir / "reproduction_log.txt"
    _write_log(
        version_log,
        started=started,
        elapsed_seconds=elapsed,
        study_root=study_root,
        raw_dir=raw_dir,
        version_dir=version_dir,
        comparison=comparison,
        sealed_before=sealed_before,
        sealed_after=sealed_after,
    )
    shutil.copy2(version_log, study_root / "reproduction_log.txt")
    return version_log


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study-root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--raw-dir", type=Path, default=Path("work/data/raw"))
    parser.add_argument("--version-dir", type=Path)
    parser.add_argument("--finalize-only", action="store_true")
    args = parser.parse_args()
    study_root = args.study_root.resolve()
    if args.finalize_only:
        if find_raw_redistribution(study_root):
            raise ReproductionError("raw provider CSVs found in release tree")
        print(build_final_manifest(study_root))
        return
    if args.version_dir is None:
        parser.error("--version-dir is required unless --finalize-only is used")
    print(run_clean_reproduction(study_root, args.raw_dir, args.version_dir))


if __name__ == "__main__":
    main()
