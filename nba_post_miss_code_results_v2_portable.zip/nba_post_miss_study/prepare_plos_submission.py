#!/usr/bin/env python3
"""Build PLOS ONE supporting tables, derived data, and repository release files."""

from __future__ import annotations

import argparse
import csv
import json
import shutil
from pathlib import Path

import pandas as pd

from src.config import load_config
from src.plos_submission import (
    assemble_portable_release,
    coefficient_rows,
    derived_variable_metadata,
    export_cached_derived_data,
    find_forbidden_release_files,
    sha256,
)
from src.post_confirmation import _final_home_win
from src.reporting import write_continuous_post_miss_figure


CONFIRMATION_SEASONS = (2016, 2017, 2018, 2019, 2020, 2021)
SEASON_PREFIX = "season_specific_"
S5_POST_MODELS = {
    "shot_zone_at_rim",
    "shot_zone_short_two",
    "shot_zone_long_two",
    "shot_zone_three",
    "timeout_heterogeneity",
    "no_timeout",
}
S3_POST_MODELS = {"win_probability_leverage"}


def _write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError(f"refusing to write empty table: {path.name}")
    fields = list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _all_models(study_root: Path) -> list[dict[str, object]]:
    payload = json.loads((study_root / "results" / "all_models.json").read_text(encoding="utf-8"))
    return [record for record in payload["models"] if isinstance(record.get("model"), dict)]


def _post_models(study_root: Path) -> tuple[dict[str, object], dict[str, object]]:
    payload = json.loads(
        (study_root / "results" / "post_confirmation_six_season.json").read_text(
            encoding="utf-8"
        )
    )
    return payload, payload["models"]


def write_supporting_tables(study_root: Path, output_dir: Path) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    confirmation = json.loads(
        (study_root / "results" / "confirmation_primary.json").read_text(encoding="utf-8")
    )
    all_models = _all_models(study_root)
    post_payload, post_models = _post_models(study_root)

    s1 = coefficient_rows(
        "confirmation_primary",
        confirmation["pooled_model"],
        "confirmatory",
        "six held-out seasons, 2016-17 through 2021-22",
    )
    s1_path = output_dir / "S1_Table_primary_model_full_results.csv"
    _write_csv(s1_path, s1)

    s2: list[dict[str, object]] = []
    for record in all_models:
        model_id = str(record["model_id"])
        if model_id.startswith(SEASON_PREFIX) or model_id in {
            "pooled_eight_season",
            "three_point_secondary",
        }:
            continue
        if model_id in {"confirmation_h1", "confirmation_h2"}:
            continue
        s2.extend(
            coefficient_rows(
                model_id,
                record["model"],
                str(record.get("status", "secondary")),
                str(record.get("sample", "")),
            )
        )
    for model_id, record in post_models.items():
        if model_id in S5_POST_MODELS or model_id in S3_POST_MODELS:
            continue
        s2.extend(
            coefficient_rows(
                model_id,
                record["model"],
                str(record.get("analysis_status", "post_confirmation_supplementary")),
                str(record.get("sample", "six confirmation seasons")),
            )
        )
    s2_path = output_dir / "S2_Table_robustness_models_full_results.csv"
    _write_csv(s2_path, s2)

    s3: list[dict[str, object]] = []
    basis_terms = post_payload["win_probability_definition"]["basis_terms"]
    for record in post_payload["win_probability_crossfit"]:
        base = {
            "target_season": record["target_season"],
            "training_seasons": "|".join(map(str, record["training_seasons"])),
            "training_rows": record["training_rows"],
            "test_rows": record["test_rows"],
            "observed_rate": record["observed_rate"],
            "mean_prediction": record["mean_prediction"],
            "brier_score": record["brier_score"],
            "log_loss": record["log_loss"],
            "calibration_intercept": record["calibration_intercept"],
            "calibration_slope": record["calibration_slope"],
        }
        for term, coefficient in zip(basis_terms, record["coefficients"]):
            s3.append({**base, "basis_term": term, "coefficient": coefficient})
    pooled = post_payload["win_probability_definition"]["pooled_holdout_diagnostics"]
    s3.append(
        {
            "target_season": "pooled held-out predictions",
            "training_seasons": "leave-one-season-out",
            "training_rows": "",
            "test_rows": pooled["rows"],
            "observed_rate": pooled["observed_rate"],
            "mean_prediction": pooled["mean_prediction"],
            "brier_score": pooled["brier_score"],
            "log_loss": pooled["log_loss"],
            "calibration_intercept": pooled["calibration_intercept"],
            "calibration_slope": pooled["calibration_slope"],
            "basis_term": "",
            "coefficient": "",
        }
    )
    s3_path = output_dir / "S3_Table_win_probability_model_and_calibration.csv"
    _write_csv(s3_path, s3)
    (output_dir / "S3_win_probability_definition.json").write_text(
        json.dumps(post_payload["win_probability_definition"], indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    s4: list[dict[str, object]] = []
    exclusion = pd.read_csv(study_root / "supplement" / "confirmation_exclusion_flow.csv")
    for row in exclusion.to_dict(orient="records"):
        s4.append(
            {
                "record_type": "sequential_exclusion",
                "season": row["season"],
                "category": row["reason"],
                "game_id": "",
                "action_number": "",
                "count": row["excluded_n"],
                "remaining_n": row["remaining_n"],
                "detail": "frozen-order exclusion",
            }
        )
    anomalies = pd.read_csv(study_root / "results" / "data_anomalies.csv")
    for row in anomalies.to_dict(orient="records"):
        s4.append(
            {
                "record_type": "recorded_anomaly",
                "season": row["season_start"],
                "category": row["category"],
                "game_id": row["game_id"],
                "action_number": row["action_number"],
                "count": 1,
                "remaining_n": "",
                "detail": row["detail"],
            }
        )
    s4_path = output_dir / "S4_Table_exclusions_and_anomalies.csv"
    _write_csv(s4_path, s4)

    s5: list[dict[str, object]] = []
    for record in all_models:
        model_id = str(record["model_id"])
        if model_id.startswith(SEASON_PREFIX) or model_id == "three_point_secondary":
            s5.extend(
                coefficient_rows(
                    model_id,
                    record["model"],
                    str(record.get("status", "secondary")),
                    str(record.get("sample", "")),
                )
            )
    for model_id in sorted(S5_POST_MODELS):
        record = post_models[model_id]
        s5.extend(
            coefficient_rows(
                model_id,
                record["model"],
                str(record.get("analysis_status", "post_confirmation_supplementary")),
                str(record.get("sample", "six confirmation seasons")),
            )
        )
    s5_path = output_dir / "S5_Table_season_zone_timeout_full_results.csv"
    _write_csv(s5_path, s5)
    return [s1_path, s2_path, s3_path, s4_path, s5_path]


def write_derived_dictionary(derived_dir: Path, manifest: list[dict[str, object]]) -> Path:
    first = derived_dir / str(manifest[0]["file"])
    frame = pd.read_csv(first, compression="gzip", nrows=5)
    known_path = Path(__file__).resolve().parent / "results" / "variable_dictionary.csv"
    known = pd.read_csv(known_path).set_index("variable").to_dict(orient="index")
    rows = []
    for column in frame.columns:
        metadata = {**known.get(column, {}), **derived_variable_metadata(column)}
        rows.append(
            {
                "variable": column,
                "storage_type": str(frame[column].dtype),
                "definition": metadata["definition"],
                "source_or_derivation": metadata["source_field"],
                "role": metadata["role"],
                "missing_rule": metadata["missing_rule"],
            }
        )
    path = derived_dir / "derived_data_dictionary.csv"
    _write_csv(path, rows)
    return path


def copy_repository_release(study_root: Path, submission_root: Path) -> Path:
    release = submission_root / "repository_release"
    assemble_portable_release(study_root, release)
    packaged_study = release / "nba_post_miss_study"
    derived_source = submission_root / "derived_data"
    shutil.copytree(derived_source, packaged_study / "derived_data")
    supporting_source = submission_root / "supporting_information"
    shutil.copytree(supporting_source, packaged_study / "supporting_information")
    problems = find_forbidden_release_files(release)
    if problems:
        raise RuntimeError(f"release contains raw provider files: {problems}")
    inventory = []
    for path in sorted(item for item in release.rglob("*") if item.is_file()):
        inventory.append(
            {
                "path": path.relative_to(release).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    _write_csv(release / "repository_file_manifest.csv", inventory)
    return release


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study-root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--cache-dir", type=Path, required=True)
    args = parser.parse_args()
    study_root = args.study_root.resolve()
    submission_root = study_root / "submission_plos_one"
    supporting = submission_root / "supporting_information"
    derived = submission_root / "derived_data"
    submission_root.mkdir(parents=True, exist_ok=True)

    tables = write_supporting_tables(study_root, supporting)
    config = load_config(study_root / "study_config.json")
    final = _final_home_win(args.raw_dir, CONFIRMATION_SEASONS)
    manifest = export_cached_derived_data(
        args.cache_dir,
        derived,
        config,
        CONFIRMATION_SEASONS,
        home_win_by_season_game=final,
    )
    _write_csv(derived / "derived_data_manifest.csv", manifest)
    dictionary = write_derived_dictionary(derived, manifest)
    post_payload, post_models = _post_models(study_root)
    write_continuous_post_miss_figure(
        post_models["continuous_criticality"]["model"], study_root / "figures"
    )
    release = copy_repository_release(study_root, submission_root)
    print(
        json.dumps(
            {
                "supporting_tables": [path.name for path in tables],
                "derived_rows": sum(int(row["rows"]) for row in manifest),
                "derived_files": len(manifest),
                "dictionary": dictionary.name,
                "repository_release": str(release),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
