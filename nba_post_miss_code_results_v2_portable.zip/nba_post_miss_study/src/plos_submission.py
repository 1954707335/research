"""Deterministic helpers for PLOS ONE submission and repository artifacts."""

from __future__ import annotations

import hashlib
import re
import shutil
from pathlib import Path
from typing import Mapping, Sequence

import pandas as pd

from .config import StudyConfig
from .pipeline import primary_predictors
from .samples import build_main_sample


DERIVED_BASE_COLUMNS = (
    "season",
    "game_id",
    "action_number",
    "period",
    "clock_seconds",
    "team_id",
    "player_id",
    "player_id_x_season",
    "pre_score_home",
    "pre_score_away",
    "shot_distance_feet",
    "loc_x",
    "loc_y",
    "is_home_offense",
    "shot_made",
    "previous_personal_action_number",
    "previous_personal_shot_distance_feet",
    "previous_personal_miss",
    "previous_personal_critical",
    "stable_critical_status",
    "personal_interval_seconds",
    "same_stint",
    "no_timeout_between_personal_shots",
    "offensive_rebound_continuation",
    "putback_within_one_second",
    "heave_proxy",
    "home_pre_shot_margin",
    "offense_signed_pre_shot_margin",
    "absolute_pre_shot_margin",
    "remaining_period_seconds",
    "remaining_game_seconds",
    "critical",
    "post_miss_x_critical",
    "continuous_criticality",
    "post_miss_x_continuous_criticality",
    "is_three_point_attempt",
    "previous_team_miss",
    "post_team_miss_x_critical",
    "previous_global_miss",
    "previous_global_relation",
    "global_rel_teammate",
    "global_rel_opponent",
    "global_miss_x_teammate",
    "global_miss_x_opponent",
    "global_miss_x_critical",
    "teammate_x_critical",
    "opponent_x_critical",
    "global_miss_x_teammate_x_critical",
    "global_miss_x_opponent_x_critical",
)


VARIABLE_METADATA: dict[str, dict[str, str]] = {
    "season": {"definition": "NBA season start year (for example, 2016 denotes 2016-17).", "source_field": "file season", "role": "season identifier", "missing_rule": "required"},
    "game_id": {"definition": "Numeric NBA game identifier.", "source_field": "play-by-play gameId", "role": "game identifier and cluster", "missing_rule": "required"},
    "action_number": {"definition": "Play-by-play actionNumber identifying the event within a game.", "source_field": "play-by-play actionNumber", "role": "event identifier and ordering", "missing_rule": "required after event join"},
    "period": {"definition": "Period number: 1-4 for regulation and 5 or greater for overtime.", "source_field": "play-by-play period", "role": "game-state control", "missing_rule": "required"},
    "clock_seconds": {"definition": "Seconds remaining in the current period, parsed from the play-by-play clock.", "source_field": "play-by-play clock", "role": "event ordering and game state", "missing_rule": "required after clock parsing"},
    "team_id": {"definition": "Numeric identifier of the shooting team.", "source_field": "play-by-play teamId", "role": "team and sequence identifier", "missing_rule": "required"},
    "player_id": {"definition": "Public numeric identifier of the shooter.", "source_field": "play-by-play personId", "role": "player identifier and cluster", "missing_rule": "required"},
    "player_id_x_season": {"definition": "Concatenated player identifier and season used for player-by-season fixed effects.", "source_field": "derived from player_id and season", "role": "fixed-effect identifier", "missing_rule": "required"},
    "pre_score_home": {"definition": "Home-team score immediately before the current field-goal attempt.", "source_field": "derived from prior scoring events", "role": "pre-shot game state", "missing_rule": "required after score reconstruction"},
    "pre_score_away": {"definition": "Away-team score immediately before the current field-goal attempt.", "source_field": "derived from prior scoring events", "role": "pre-shot game state", "missing_rule": "required after score reconstruction"},
    "shot_distance_feet": {"definition": "Recorded distance of the current field-goal attempt from the basket, in feet.", "source_field": "shot-detail SHOT_DISTANCE", "role": "primary outcome", "missing_rule": "required"},
    "loc_x": {"definition": "Horizontal shot coordinate in tenths of feet, with the basket centered at zero.", "source_field": "shot-detail LOC_X", "role": "shot location", "missing_rule": "required after event join"},
    "loc_y": {"definition": "Longitudinal shot coordinate from the basket in tenths of feet.", "source_field": "shot-detail LOC_Y", "role": "shot location", "missing_rule": "required after event join"},
    "is_home_offense": {"definition": "Indicator equal to 1 when the shooting team is the home team and 0 otherwise.", "source_field": "derived from team and game identifiers", "role": "control", "missing_rule": "required"},
    "shot_made": {"definition": "Field-goal outcome: 1 if made and 0 if missed.", "source_field": "play-by-play shot result", "role": "current-shot outcome", "missing_rule": "required"},
    "previous_personal_action_number": {"definition": "actionNumber of the same player's immediately previous field-goal attempt in the same period.", "source_field": "derived personal lag", "role": "sequence trace", "missing_rule": "missing when no prior same-period personal attempt exists"},
    "previous_personal_shot_distance_feet": {"definition": "Distance in feet of the same player's immediately previous same-period field-goal attempt.", "source_field": "derived personal lag", "role": "lagged-distance control", "missing_rule": "missing when no prior same-period personal attempt exists"},
    "previous_personal_miss": {"definition": "Indicator equal to 1 if the same player's immediately previous same-period attempt missed and 0 if it was made.", "source_field": "1 - previous_personal_shot_made", "role": "focal exposure", "missing_rule": "missing when no prior same-period personal attempt exists"},
    "previous_personal_critical": {"definition": "Critical-state indicator evaluated at the immediately previous personal attempt.", "source_field": "derived from previous personal shot clock and score", "role": "sequence-state diagnostic", "missing_rule": "missing when prior personal state is unavailable"},
    "stable_critical_status": {"definition": "Indicator that the previous and current personal attempts have the same binary critical-state classification.", "source_field": "derived from current and previous critical indicators", "role": "sensitivity restriction", "missing_rule": "missing when prior personal state is unavailable"},
    "personal_interval_seconds": {"definition": "Elapsed game-clock seconds between the same player's current and immediately previous attempt in the same period.", "source_field": "previous_personal_clock_seconds - clock_seconds", "role": "interval control and restriction", "missing_rule": "missing when no prior same-period personal attempt exists"},
    "same_stint": {"definition": "Indicator equal to 1 when no substitution-out event for the player occurred between the paired attempts.", "source_field": "derived from substitution events", "role": "sensitivity restriction", "missing_rule": "missing when no prior personal attempt exists"},
    "no_timeout_between_personal_shots": {"definition": "Indicator equal to 1 when no timeout occurred between the paired personal attempts.", "source_field": "derived from timeout events", "role": "sensitivity restriction", "missing_rule": "missing when no prior personal attempt exists"},
    "offensive_rebound_continuation": {"definition": "Indicator that the current attempt follows a missed same-team attempt and an offensive rebound in the same period.", "source_field": "derived from global shot and rebound sequence", "role": "predefined exclusion", "missing_rule": "0 when conditions are not met"},
    "putback_within_one_second": {"definition": "Indicator that an offensive-rebound continuation was attempted within one game-clock second of the rebound.", "source_field": "derived from rebound and shot clocks", "role": "sensitivity exclusion", "missing_rule": "0 when conditions are not met"},
    "heave_proxy": {"definition": "Rule-based indicator for an end-of-period long-distance heave.", "source_field": "derived from shot distance and remaining period time", "role": "predefined exclusion", "missing_rule": "0 when rule is not met"},
    "home_pre_shot_margin": {"definition": "Home-team pre-shot margin: pre_score_home minus pre_score_away, in points.", "source_field": "derived from pre-shot scores", "role": "game state", "missing_rule": "required after score reconstruction"},
    "offense_signed_pre_shot_margin": {"definition": "Shooting team's pre-shot lead in points; positive means the offense leads and negative means it trails.", "source_field": "home_pre_shot_margin signed by is_home_offense", "role": "control", "missing_rule": "required after score reconstruction"},
    "absolute_pre_shot_margin": {"definition": "Absolute pre-shot score margin in points.", "source_field": "absolute value of home_pre_shot_margin", "role": "control and criticality component", "missing_rule": "required after score reconstruction"},
    "remaining_period_seconds": {"definition": "Seconds remaining in the current period.", "source_field": "clock_seconds", "role": "nonlinear clock control", "missing_rule": "required"},
    "remaining_game_seconds": {"definition": "Regulation seconds remaining: (4 - period) x 720 + remaining_period_seconds.", "source_field": "derived from period and clock", "role": "criticality component", "missing_rule": "missing in overtime"},
    "critical": {"definition": "Indicator equal to 1 in the fourth quarter with at most 300 seconds remaining and absolute pre-shot margin at most 5 points.", "source_field": "derived from period, clock, and score", "role": "primary moderator", "missing_rule": "required"},
    "post_miss_x_critical": {"definition": "Product of previous_personal_miss and critical.", "source_field": "derived interaction", "role": "primary interaction", "missing_rule": "missing if a component is missing"},
    "continuous_criticality": {"definition": "Continuous index exp(-remaining_game_seconds/300) x exp(-absolute_pre_shot_margin/5).", "source_field": "derived from pre-shot time and margin", "role": "supplementary moderator", "missing_rule": "missing in overtime"},
    "post_miss_x_continuous_criticality": {"definition": "Product of previous_personal_miss and continuous_criticality.", "source_field": "derived interaction", "role": "supplementary interaction", "missing_rule": "missing if a component is missing"},
    "is_three_point_attempt": {"definition": "Indicator equal to 1 for a recorded three-point attempt and 0 otherwise.", "source_field": "shot-detail shot type", "role": "secondary outcome", "missing_rule": "required after event join"},
    "previous_team_miss": {"definition": "Indicator equal to 1 if the shooting team's immediately previous same-period attempt missed and 0 if made.", "source_field": "derived team lag", "role": "social-sequence exposure", "missing_rule": "missing when no prior same-team same-period attempt exists"},
    "post_team_miss_x_critical": {"definition": "Product of previous_team_miss and critical.", "source_field": "derived interaction", "role": "team-sequence interaction", "missing_rule": "missing if a component is missing"},
    "previous_global_miss": {"definition": "Indicator equal to 1 if the immediately previous field-goal attempt by any player in the game missed and 0 if made.", "source_field": "derived global lag", "role": "social-sequence exposure", "missing_rule": "missing for the first game attempt"},
    "previous_global_relation": {"definition": "Relationship of the previous game-level attempt's shooter to the current shooter: self, teammate, or opponent.", "source_field": "derived from current and previous player/team identifiers", "role": "social-context category", "missing_rule": "missing for the first game attempt"},
    "global_rel_teammate": {"definition": "Indicator equal to 1 when previous_global_relation is teammate.", "source_field": "derived category indicator", "role": "social-context indicator", "missing_rule": "0 for other observed relations"},
    "global_rel_opponent": {"definition": "Indicator equal to 1 when previous_global_relation is opponent.", "source_field": "derived category indicator", "role": "social-context indicator", "missing_rule": "0 for other observed relations"},
    "global_miss_x_teammate": {"definition": "Product of previous_global_miss and global_rel_teammate.", "source_field": "derived interaction", "role": "social interaction", "missing_rule": "missing if a component is missing"},
    "global_miss_x_opponent": {"definition": "Product of previous_global_miss and global_rel_opponent.", "source_field": "derived interaction", "role": "social interaction", "missing_rule": "missing if a component is missing"},
    "global_miss_x_critical": {"definition": "Product of previous_global_miss and critical.", "source_field": "derived interaction", "role": "social interaction", "missing_rule": "missing if a component is missing"},
    "teammate_x_critical": {"definition": "Product of global_rel_teammate and critical.", "source_field": "derived interaction", "role": "social interaction", "missing_rule": "missing if a component is missing"},
    "opponent_x_critical": {"definition": "Product of global_rel_opponent and critical.", "source_field": "derived interaction", "role": "social interaction", "missing_rule": "missing if a component is missing"},
    "global_miss_x_teammate_x_critical": {"definition": "Three-way product of previous_global_miss, global_rel_teammate, and critical.", "source_field": "derived interaction", "role": "social criticality interaction", "missing_rule": "missing if a component is missing"},
    "global_miss_x_opponent_x_critical": {"definition": "Three-way product of previous_global_miss, global_rel_opponent, and critical.", "source_field": "derived interaction", "role": "social criticality interaction", "missing_rule": "missing if a component is missing"},
    "home_win": {"definition": "Indicator equal to 1 if the final home score exceeded the final away score and 0 otherwise.", "source_field": "derived from final game scores", "role": "win-probability target", "missing_rule": "required in exported confirmation data"},
}


def derived_variable_metadata(variable: str) -> dict[str, str]:
    """Return an explicit definition for every released derived-data field."""
    if variable in VARIABLE_METADATA:
        return dict(VARIABLE_METADATA[variable])
    match = re.fullmatch(r"(remaining_period_seconds|absolute_pre_shot_margin|personal_interval_seconds)_spline_(\d+)", variable)
    if match:
        base, knot = match.groups()
        unit = "seconds" if "seconds" in base else "points"
        return {
            "definition": f"Truncated linear spline basis max({base} - {knot}, 0), in {unit}.",
            "source_field": f"derived from {base}",
            "role": "nonlinear control",
            "missing_rule": f"missing if {base} is missing",
        }
    raise KeyError(f"no released-data definition for {variable}")


def assemble_portable_release(study_root: Path, destination: Path) -> Path:
    """Assemble the freeze-compatible top-level layout used by the public archive."""
    study_root = Path(study_root)
    destination = Path(destination)
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True)
    packaged_study = destination / "nba_post_miss_study"
    packaged_study.mkdir()
    for name in ("src", "tests", "results", "tables", "figures", "supplement", "reproducibility"):
        source = study_root / name
        if source.is_dir():
            shutil.copytree(source, packaged_study / name, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pkl"))
    for name in (
        "README.md", "requirements.txt", "study_config.json", "data_manifest.csv",
        "analysis_freeze.json", "run_all.py", "run_revision.py",
        "prepare_plos_submission.py", "reproduction_log.txt",
    ):
        source = study_root / name
        if source.is_file():
            shutil.copy2(source, packaged_study / name)
    design = study_root.parent / "SCI_research_design_post_miss_criticality_zh.md"
    if design.is_file():
        shutil.copy2(design, destination / design.name)
    (destination / "README.md").write_text(
        """# NBA post-miss study: portable reproduction package

This archive preserves the original freeze manifest and its required relative layout. Do not replace or regenerate `nba_post_miss_study/analysis_freeze.json`.

## Reproduce

1. Extract this archive and keep `SCI_research_design_post_miss_criticality_zh.md` beside the `nba_post_miss_study` folder.
2. Obtain the third-party raw files listed in `nba_post_miss_study/data_manifest.csv` and verify their recorded sizes and SHA-256 hashes.
3. From the extracted top-level directory, run:

   `python3 nba_post_miss_study/run_all.py --raw-dir /absolute/path/to/raw --version-dir /absolute/path/to/new-output`

The original raw NBA-derived files are not included. The preserved `nba_post_miss_study/reproduction_log.txt` records the completed local verification used for the manuscript.
""",
        encoding="utf-8",
    )
    return destination


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def coefficient_rows(
    model_id: str,
    model: Mapping[str, object],
    status: str,
    sample: str,
) -> list[dict[str, object]]:
    """Flatten a stored HDFE model into complete coefficient rows."""
    estimates = model.get("estimates")
    if not isinstance(estimates, Mapping):
        raise ValueError(f"model {model_id} has no coefficient mapping")
    standard_errors = model.get("two_way_standard_errors", model.get("standard_errors"))
    p_values = model.get("p_values_normal")
    confidence = model.get("confidence_intervals")
    if not isinstance(standard_errors, Mapping) or not isinstance(p_values, Mapping):
        raise ValueError(f"model {model_id} lacks complete inference")
    fixed_effect_counts = model.get("fixed_effect_counts", {})
    cluster_counts = model.get("cluster_counts", {})
    fixed_effects = "|".join(sorted(str(key) for key in fixed_effect_counts))
    clusters = "|".join(sorted(str(key) for key in cluster_counts))
    result = []
    for term in model.get("predictors", estimates.keys()):
        if term not in estimates:
            continue
        estimate = float(estimates[term])
        standard_error = float(standard_errors[term])
        if isinstance(confidence, Mapping) and term in confidence:
            ci_low, ci_high = map(float, confidence[term])
        else:
            ci_low = estimate - 1.96 * standard_error
            ci_high = estimate + 1.96 * standard_error
        result.append(
            {
                "model_id": model_id,
                "analysis_status": status,
                "sample": sample,
                "outcome": model.get("outcome", ""),
                "term": str(term),
                "estimate": estimate,
                "standard_error": standard_error,
                "p_value_two_sided": float(p_values[term]),
                "ci_low": ci_low,
                "ci_high": ci_high,
                "n_obs": int(model.get("n_obs", 0)),
                "within_r_squared": model.get("within_r_squared", ""),
                "fixed_effects": fixed_effects,
                "fixed_effect_counts": "|".join(
                    f"{key}:{value}" for key, value in sorted(fixed_effect_counts.items())
                ),
                "clusters": clusters,
                "cluster_counts": "|".join(
                    f"{key}:{value}" for key, value in sorted(cluster_counts.items())
                ),
                "converged": bool(model.get("converged", True)),
                "sample_hash": model.get("sample_hash", ""),
                "formula_hash": model.get("formula_hash", ""),
            }
        )
    return result


def derived_analysis_columns(config: StudyConfig) -> list[str]:
    columns = list(DERIVED_BASE_COLUMNS)
    for name in primary_predictors(config):
        if name not in columns:
            columns.append(name)
    return columns


def required_derived_columns(config: StudyConfig) -> list[str]:
    return list(
        dict.fromkeys(
            [
                "season",
                "game_id",
                "action_number",
                "period",
                "clock_seconds",
                "team_id",
                "player_id",
                "player_id_x_season",
                "pre_score_home",
                "pre_score_away",
                "shot_distance_feet",
                "loc_x",
                "loc_y",
                "is_home_offense",
                "shot_made",
                "previous_personal_action_number",
                "previous_personal_shot_distance_feet",
                "offensive_rebound_continuation",
                "putback_within_one_second",
                "heave_proxy",
                *primary_predictors(config),
            ]
        )
    )


def export_cached_derived_data(
    cache_dir: Path,
    output_dir: Path,
    config: StudyConfig,
    seasons: Sequence[int],
    *,
    home_win_by_season_game: pd.Series | None = None,
) -> list[dict[str, object]]:
    """Export the frozen main sample as deterministic season-level CSV.GZ files."""
    cache_dir = Path(cache_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    requested_columns = derived_analysis_columns(config)
    required_columns = required_derived_columns(config)
    records: list[dict[str, object]] = []
    for season in seasons:
        cached = cache_dir / f"enriched_{season}.pkl"
        if not cached.is_file():
            raise FileNotFoundError(cached)
        enriched = pd.read_pickle(cached)
        sample, _ = build_main_sample(enriched, config)
        missing = [name for name in required_columns if name not in sample.columns]
        if missing:
            raise ValueError(f"cached season {season} lacks derived columns: {missing}")
        columns = [name for name in requested_columns if name in sample.columns]
        export = sample.loc[:, columns].copy()
        if home_win_by_season_game is not None:
            keys = pd.MultiIndex.from_arrays(
                [export["season"].astype(int), export["game_id"].astype(int)]
            )
            export["home_win"] = home_win_by_season_game.reindex(keys).to_numpy()
            if export["home_win"].isna().any():
                raise ValueError(f"missing final-game outcome for season {season}")
        export = export.sort_values(["game_id", "period", "action_number"], kind="stable")
        file_name = f"derived_confirmation_{season}.csv.gz"
        path = output_dir / file_name
        export.to_csv(
            path,
            index=False,
            float_format="%.12g",
            compression={"method": "gzip", "compresslevel": 9, "mtime": 0},
        )
        records.append(
            {
                "season": int(season),
                "file": file_name,
                "rows": int(len(export)),
                "columns": int(len(export.columns)),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    return records


def find_forbidden_release_files(root: Path) -> list[str]:
    """Return provider raw archives/CSVs that must not enter the release bundle."""
    root = Path(root)
    forbidden = []
    prefixes = ("nbastatsv3_", "shotdetail_")
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        name = path.name.lower()
        if name.startswith(prefixes) and name.endswith((".csv", ".tar.xz", ".zip")):
            forbidden.append(path.relative_to(root).as_posix())
    return forbidden
