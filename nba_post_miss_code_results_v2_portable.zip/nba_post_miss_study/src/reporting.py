"""Create publication tables, figures, and supplement from sealed results only."""

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont


BLUE = "#0072B2"
ORANGE = "#D55E00"
GREEN = "#009E73"
GRAY = "#5B6573"


def format_p_value(value: float) -> str:
    if value < 0.001:
        return "<.001"
    return f"{value:.3f}".lstrip("0")


def write_figure_data(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, lineterminator="\n")


def build_primary_table(confirmation: dict[str, object]) -> pd.DataFrame:
    rows = []
    for term, label in (("h1", "H1"), ("h2", "H2")):
        result = confirmation["hypotheses"][term]
        rows.append(
            {
                "analysis": "Held-out confirmation (2016-17 to 2021-22)",
                "analysis_status": "confirmatory",
                "term": label,
                "coefficient": "Previous personal miss" if term == "h1" else "Previous personal miss × critical",
                "estimate_feet": result["estimate"],
                "se_two_way_feet": result["standard_error_two_way"],
                "ci_low_feet": result["confidence_interval"][0],
                "ci_high_feet": result["confidence_interval"][1],
                "p_normal": result["p_normal"],
                "p_display": format_p_value(result["p_normal"]),
                "direction_supported": result["direction_supported"],
                "n_obs": confirmation["pooled_model"]["n_obs"],
            }
        )
    return pd.DataFrame.from_records(rows)


def continuous_post_miss_contrast_curve(
    model: dict[str, object], grid: Sequence[float] | None = None
) -> pd.DataFrame:
    """Return beta_miss + C*beta_interaction and its same-model covariance CI."""
    predictors = list(model["predictors"])
    miss_term = "previous_personal_miss"
    interaction_term = "post_miss_x_continuous_criticality"
    miss_index = predictors.index(miss_term)
    interaction_index = predictors.index(interaction_term)
    estimates = model["estimates"]
    covariance = np.asarray(model["covariance"], dtype=float)
    if covariance.shape != (len(predictors), len(predictors)):
        raise ValueError("continuous-criticality covariance does not match predictor order")
    values = np.asarray(list(grid) if grid is not None else np.linspace(0, 1, 101), dtype=float)
    miss = float(estimates[miss_term])
    interaction = float(estimates[interaction_term])
    variance = (
        covariance[miss_index, miss_index]
        + 2 * values * covariance[miss_index, interaction_index]
        + values**2 * covariance[interaction_index, interaction_index]
    )
    standard_error = np.sqrt(np.clip(variance, 0.0, None))
    contrast = miss + interaction * values
    return pd.DataFrame(
        {
            "continuous_criticality": values,
            "post_miss_distance_contrast_feet": contrast,
            "standard_error": standard_error,
            "ci_low": contrast - 1.96 * standard_error,
            "ci_high": contrast + 1.96 * standard_error,
            "source_model": "continuous_criticality_six_season",
            "post_miss_coefficient": miss,
            "interaction_coefficient": interaction,
        }
    )


def write_continuous_post_miss_figure(model: dict[str, object], figures: Path) -> pd.DataFrame:
    """Write the corrected six-season Fig 4 without altering the frozen legacy figure."""
    data = continuous_post_miss_contrast_curve(model)
    stem = figures / "figure_4_continuous_criticality_six_season"
    write_figure_data(data, stem.with_name(stem.name + "_data.csv"))
    width, height = 1500, 850
    left, right, top, bottom = 200, 1370, 150, 700
    low = min(-1.8, float(data["ci_low"].min()) - 0.1)
    high = max(0.2, float(data["ci_high"].max()) + 0.1)
    sx = lambda value: left + value * (right - left)
    sy = lambda value: bottom - (value - low) / (high - low) * (bottom - top)
    line_points = [(sx(x), sy(y)) for x, y in zip(data["continuous_criticality"], data["post_miss_distance_contrast_feet"])]
    upper = [(sx(x), sy(y)) for x, y in zip(data["continuous_criticality"], data["ci_high"])]
    lower = [(sx(x), sy(y)) for x, y in zip(data["continuous_criticality"].iloc[::-1], data["ci_low"].iloc[::-1])]
    polygon = upper + lower
    polygon_svg = " ".join(f"{x:.1f},{y:.1f}" for x, y in polygon)
    line_svg = " ".join(f"{x:.1f},{y:.1f}" for x, y in line_points)
    svg = [
        f'<text x="{width/2}" y="65" text-anchor="middle" font-family="Arial,sans-serif" font-size="38" font-weight="700">Post-miss distance contrast across continuous criticality</text>',
        f'<polygon points="{polygon_svg}" fill="{GREEN}" fill-opacity="0.20"/>',
    ]
    zero = sy(0)
    svg.append(f'<line x1="{left}" y1="{zero}" x2="{right}" y2="{zero}" stroke="{GRAY}" stroke-width="3" stroke-dasharray="10,8"/>')
    svg.append(f'<polyline points="{line_svg}" fill="none" stroke="{GREEN}" stroke-width="7"/>')
    for tick in np.linspace(0, 1, 6):
        svg.append(f'<text x="{sx(tick)}" y="{bottom+40}" text-anchor="middle" font-family="Arial,sans-serif" font-size="22">{tick:.1f}</text>')
    for tick in np.arange(np.ceil(low * 2) / 2, high + 0.001, 0.5):
        svg.append(f'<text x="{left-25}" y="{sy(tick)+7}" text-anchor="end" font-family="Arial,sans-serif" font-size="22">{tick:.1f}</text>')
    svg.extend(
        [
            f'<text x="{(left+right)/2}" y="{height-30}" text-anchor="middle" font-family="Arial,sans-serif" font-size="25">Continuous criticality index (0 = low, 1 = high)</text>',
            f'<text x="45" y="{(top+bottom)/2}" text-anchor="middle" transform="rotate(-90 45 {(top+bottom)/2})" font-family="Arial,sans-serif" font-size="25">Post-miss distance contrast (feet)</text>',
        ]
    )

    def draw_png(draw: ImageDraw.ImageDraw) -> None:
        draw.text((width / 2, 55), "Post-miss distance contrast across continuous criticality", font=_font(38, True), fill="black", anchor="mm")
        draw.text((left, 110), "Post-miss distance contrast (feet)", font=_font(23), fill="black", anchor="la")
        draw.polygon(polygon, fill="#B8E5D9")
        draw.line((left, zero, right, zero), fill=GRAY, width=3)
        draw.line(line_points, fill=GREEN, width=7, joint="curve")
        for tick in np.linspace(0, 1, 6):
            draw.text((sx(tick), bottom + 25), f"{tick:.1f}", font=_font(22), fill="black", anchor="ma")
        for tick in np.arange(np.ceil(low * 2) / 2, high + 0.001, 0.5):
            draw.text((left - 25, sy(tick)), f"{tick:.1f}", font=_font(22), fill="black", anchor="rm")
        draw.text(((left + right) / 2, height - 30), "Continuous criticality index (0 = low, 1 = high)", font=_font(25), fill="black", anchor="mm")

    _write_plot(stem, width, height, "".join(svg), draw_png)
    return data


def _model_map(models: Sequence[dict[str, object]]) -> dict[str, dict[str, object]]:
    return {record["model_id"]: record for record in models}


def _target(mult: pd.DataFrame, model_id: str, term: str) -> pd.Series:
    rows = mult.loc[mult["model_id"].eq(model_id) & mult["term"].eq(term)]
    if len(rows) != 1:
        raise ValueError(f"expected one registered result for {model_id}/{term}, found {len(rows)}")
    return rows.iloc[0]


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path("/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf"),
        Path("/System/Library/Fonts/Helvetica.ttc"),
    ]
    for path in candidates:
        if path.is_file():
            try:
                return ImageFont.truetype(str(path), size=size)
            except OSError:
                pass
    return ImageFont.load_default()


def _write_plot(stem: Path, width: int, height: int, svg_body: str, draw_png) -> None:
    stem.parent.mkdir(parents=True, exist_ok=True)
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">'
        f'<rect width="100%" height="100%" fill="white"/>{svg_body}</svg>\n'
    )
    stem.with_suffix(".svg").write_text(svg, encoding="utf-8")
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    draw_png(draw)
    image.save(stem.with_suffix(".png"), dpi=(300, 300))


def _esc(value: object) -> str:
    return html.escape(str(value))


def _figure_sample_flow(confirmation: dict[str, object], figures: Path) -> None:
    flows = confirmation["sample_flow"]
    reasons = [step["reason"] for step in flows[0]["steps"]]
    rows = [{"stage": "Initial field-goal attempts", "remaining_n": sum(flow["initial_n"] for flow in flows)}]
    remaining = rows[0]["remaining_n"]
    for reason in reasons:
        excluded = sum(next(step["excluded_n"] for step in flow["steps"] if step["reason"] == reason) for flow in flows)
        remaining -= excluded
        rows.append({"stage": f"After excluding: {reason.replace('_', ' ')}", "remaining_n": remaining})
    data = pd.DataFrame.from_records(rows)
    write_figure_data(data, figures / "figure_1_sample_flow_data.csv")
    width, height = 1800, 1050
    left, right, top, bottom = 690, 1650, 150, 930
    ys = np.linspace(top + 70, bottom - 40, len(data))
    maximum = float(data["remaining_n"].max())
    xs = left + (data["remaining_n"].to_numpy() / maximum) * (right - left)
    points = " ".join(f"{x:.1f},{y:.1f}" for x, y in zip(xs, ys))
    svg = [f'<text x="{width/2}" y="70" text-anchor="middle" font-family="Arial,sans-serif" font-size="38" font-weight="700">Held-out confirmation sample flow</text>']
    for tick in np.linspace(0, maximum, 5):
        x = left + tick / maximum * (right - left)
        svg.append(f'<line x1="{x}" y1="{top}" x2="{x}" y2="{bottom}" stroke="#D9DDE3" stroke-width="2"/>')
        svg.append(f'<text x="{x}" y="{bottom+45}" text-anchor="middle" font-family="Arial,sans-serif" font-size="22">{int(tick):,}</text>')
    svg.append(f'<polyline points="{points}" fill="none" stroke="{BLUE}" stroke-width="6"/>')
    for stage, count, x, y in zip(data["stage"], data["remaining_n"], xs, ys):
        svg.append(f'<text x="{left-25}" y="{y+8}" text-anchor="end" font-family="Arial,sans-serif" font-size="21">{_esc(stage)}</text>')
        svg.append(f'<circle cx="{x}" cy="{y}" r="9" fill="{BLUE}"/>')
        svg.append(f'<text x="{x+18}" y="{y+7}" font-family="Arial,sans-serif" font-size="20">{int(count):,}</text>')
    svg.append(f'<text x="{(left+right)/2}" y="{height-25}" text-anchor="middle" font-family="Arial,sans-serif" font-size="25">Remaining shot observations</text>')

    def draw_png(draw: ImageDraw.ImageDraw) -> None:
        title = _font(38, True); label = _font(21); tick_font = _font(20); axis = _font(25)
        draw.text((width/2, 55), "Held-out confirmation sample flow", font=title, fill="black", anchor="mm")
        for tick in np.linspace(0, maximum, 5):
            x = left + tick / maximum * (right - left)
            draw.line((x, top, x, bottom), fill="#D9DDE3", width=2)
            draw.text((x, bottom+25), f"{int(tick):,}", font=tick_font, fill="black", anchor="ma")
        draw.line(list(zip(xs.tolist(), ys.tolist())), fill=BLUE, width=6, joint="curve")
        for stage, count, x, y in zip(data["stage"], data["remaining_n"], xs, ys):
            draw.text((left-25, y), str(stage), font=label, fill="black", anchor="rm")
            draw.ellipse((x-9, y-9, x+9, y+9), fill=BLUE)
            draw.text((x+18, y), f"{int(count):,}", font=tick_font, fill="black", anchor="lm")
        draw.text(((left+right)/2, height-35), "Remaining shot observations", font=axis, fill="black", anchor="mm")

    _write_plot(figures / "figure_1_sample_flow", width, height, "".join(svg), draw_png)


def _figure_distance_components(confirmation: dict[str, object], figures: Path) -> None:
    h1 = confirmation["hypotheses"]["h1"]
    h2 = confirmation["hypotheses"]["h2"]
    data = pd.DataFrame(
        [
            {
                "component": "Post-miss distance change\n(non-critical; H1)",
                "estimate_feet": h1["estimate"],
                "ci_low": h1["confidence_interval"][0],
                "ci_high": h1["confidence_interval"][1],
                "analysis_status": "confirmatory",
            },
            {
                "component": "Critical-game attenuation\n(interaction; H2)",
                "estimate_feet": h2["estimate"],
                "ci_low": h2["confidence_interval"][0],
                "ci_high": h2["confidence_interval"][1],
                "analysis_status": "confirmatory",
            },
        ]
    )
    write_figure_data(data, figures / "figure_2_marginal_distance_data.csv")
    width, height = 1600, 760
    left, right, top, bottom = 590, 1480, 180, 610
    domain = (-1.8, 1.0)
    scale = lambda value: left + (value-domain[0])/(domain[1]-domain[0])*(right-left)
    ys = [310, 480]
    svg = [f'<text x="{width/2}" y="70" text-anchor="middle" font-family="Arial,sans-serif" font-size="36" font-weight="700">Confirmed post-miss caution and critical-game attenuation</text>']
    zero = scale(0)
    svg.append(f'<line x1="{zero}" y1="{top}" x2="{zero}" y2="{bottom}" stroke="{GRAY}" stroke-width="3" stroke-dasharray="10,8"/>')
    for row, y in zip(data.itertuples(index=False), ys):
        x, lo, hi = scale(row.estimate_feet), scale(row.ci_low), scale(row.ci_high)
        label = str(row.component).replace("\n", " — ")
        svg.extend([
            f'<text x="{left-30}" y="{y+8}" text-anchor="end" font-family="Arial,sans-serif" font-size="25">{_esc(label)}</text>',
            f'<line x1="{lo}" y1="{y}" x2="{hi}" y2="{y}" stroke="{BLUE}" stroke-width="6"/>',
            f'<line x1="{lo}" y1="{y-14}" x2="{lo}" y2="{y+14}" stroke="{BLUE}" stroke-width="4"/>',
            f'<line x1="{hi}" y1="{y-14}" x2="{hi}" y2="{y+14}" stroke="{BLUE}" stroke-width="4"/>',
            f'<circle cx="{x}" cy="{y}" r="11" fill="{BLUE}"/>',
            f'<text x="{x+18}" y="{y-20}" font-family="Arial,sans-serif" font-size="23">{row.estimate_feet:+.2f} ft</text>',
        ])
    for tick in np.arange(-1.5, 1.01, .5):
        x = scale(tick)
        svg.append(f'<text x="{x}" y="{bottom+45}" text-anchor="middle" font-family="Arial,sans-serif" font-size="22">{tick:.1f}</text>')
    svg.append(f'<text x="{(left+right)/2}" y="{height-35}" text-anchor="middle" font-family="Arial,sans-serif" font-size="25">Change in next-shot distance (feet; 95% CI)</text>')

    def draw_png(draw: ImageDraw.ImageDraw) -> None:
        draw.text((width/2, 55), "Confirmed post-miss caution and critical-game attenuation", font=_font(36, True), fill="black", anchor="mm")
        draw.line((zero, top, zero, bottom), fill=GRAY, width=3)
        for row, y in zip(data.itertuples(index=False), ys):
            x, lo, hi = scale(row.estimate_feet), scale(row.ci_low), scale(row.ci_high)
            label = str(row.component).replace("\n", " — ")
            draw.text((left-30, y), label, font=_font(25), fill="black", anchor="rm")
            draw.line((lo, y, hi, y), fill=BLUE, width=6)
            draw.line((lo, y-14, lo, y+14), fill=BLUE, width=4); draw.line((hi, y-14, hi, y+14), fill=BLUE, width=4)
            draw.ellipse((x-11, y-11, x+11, y+11), fill=BLUE)
            draw.text((x+18, y-20), f"{row.estimate_feet:+.2f} ft", font=_font(23), fill="black", anchor="ls")
        for tick in np.arange(-1.5, 1.01, .5):
            draw.text((scale(tick), bottom+25), f"{tick:.1f}", font=_font(22), fill="black", anchor="ma")
        draw.text(((left+right)/2, height-35), "Change in next-shot distance (feet; 95% CI)", font=_font(25), fill="black", anchor="mm")

    _write_plot(figures / "figure_2_marginal_distance", width, height, "".join(svg), draw_png)


def _figure_forest(mult: pd.DataFrame, meta: pd.DataFrame, figures: Path) -> None:
    season = mult.loc[
        mult["template_id"].eq("season_specific") & mult["term"].eq("post_miss_x_critical")
    ].copy()
    season["season_start"] = season["model_id"].str.extract(r"(\d{4})$").astype(int)
    season = season.sort_values("season_start")
    season["label"] = season["season_start"].map(lambda x: f"{x}-{str(x+1)[-2:]}")
    season["ci_low"] = season["estimate"] - 1.96 * season["standard_error"]
    season["ci_high"] = season["estimate"] + 1.96 * season["standard_error"]
    pooled = meta.loc[meta["analysis"].eq("eight_season_h2_random_reml")].iloc[0]
    pooled_ci = str(pooled["confidence_interval"]).strip("() ").split(",")
    pooled_row = pd.DataFrame(
        [{
            "model_id": "reml_random_effects",
            "template_id": "meta",
            "term": "post_miss_x_critical",
            "estimate": pooled["pooled_effect"],
            "standard_error": pooled["standard_error"],
            "label": "REML pooled",
            "ci_low": float(pooled_ci[0]),
            "ci_high": float(pooled_ci[1]),
            "analysis_status": "secondary",
        }]
    )
    data = pd.concat(
        [season[["model_id", "template_id", "term", "estimate", "standard_error", "label", "ci_low", "ci_high", "status"]].rename(columns={"status": "analysis_status"}), pooled_row],
        ignore_index=True,
    )
    write_figure_data(data, figures / "figure_3_season_forest_data.csv")
    width, height = 1780, 1100
    left, right, top, bottom = 330, 1320, 150, 970
    lo_domain = min(-0.2, float(data["ci_low"].min()) - .1); hi_domain = max(1.3, float(data["ci_high"].max()) + .1)
    scale = lambda value: left + (value-lo_domain)/(hi_domain-lo_domain)*(right-left)
    ys = np.linspace(top+70, bottom-60, len(data))
    svg = [f'<text x="{width/2}" y="65" text-anchor="middle" font-family="Arial,sans-serif" font-size="38" font-weight="700">Season-specific and random-effects H2 estimates</text>']
    zero=scale(0); svg.append(f'<line x1="{zero}" y1="{top}" x2="{zero}" y2="{bottom}" stroke="{GRAY}" stroke-width="3" stroke-dasharray="10,8"/>')
    for idx, (row, y) in enumerate(zip(data.itertuples(index=False), ys)):
        color = ORANGE if idx == len(data)-1 else BLUE
        x, lo, hi = scale(row.estimate), scale(row.ci_low), scale(row.ci_high)
        svg.extend([
            f'<text x="{left-25}" y="{y+8}" text-anchor="end" font-family="Arial,sans-serif" font-size="24">{_esc(row.label)}</text>',
            f'<line x1="{lo}" y1="{y}" x2="{hi}" y2="{y}" stroke="{color}" stroke-width="5"/>',
            f'<circle cx="{x}" cy="{y}" r="{12 if idx==len(data)-1 else 9}" fill="{color}"/>',
            f'<text x="{right+20}" y="{y+7}" font-family="Arial,sans-serif" font-size="20">{row.estimate:.2f} [{row.ci_low:.2f}, {row.ci_high:.2f}]</text>',
        ])
    for tick in np.arange(0, 1.21, .2):
        svg.append(f'<text x="{scale(tick)}" y="{bottom+42}" text-anchor="middle" font-family="Arial,sans-serif" font-size="21">{tick:.1f}</text>')
    svg.append(f'<text x="{(left+right)/2}" y="{height-30}" text-anchor="middle" font-family="Arial,sans-serif" font-size="24">Criticality moderation of post-miss distance (feet; 95% CI)</text>')

    def draw_png(draw: ImageDraw.ImageDraw) -> None:
        draw.text((width/2, 55), "Season-specific and random-effects H2 estimates", font=_font(38, True), fill="black", anchor="mm")
        draw.line((zero, top, zero, bottom), fill=GRAY, width=3)
        for idx, (row, y) in enumerate(zip(data.itertuples(index=False), ys)):
            color = ORANGE if idx == len(data)-1 else BLUE
            x, lo, hi = scale(row.estimate), scale(row.ci_low), scale(row.ci_high)
            draw.text((left-25, y), str(row.label), font=_font(24), fill="black", anchor="rm")
            draw.line((lo, y, hi, y), fill=color, width=5)
            radius=12 if idx==len(data)-1 else 9; draw.ellipse((x-radius,y-radius,x+radius,y+radius),fill=color)
            draw.text((right+20,y),f"{row.estimate:.2f} [{row.ci_low:.2f}, {row.ci_high:.2f}]",font=_font(20),fill="black",anchor="lm")
        for tick in np.arange(0,1.21,.2):
            draw.text((scale(tick),bottom+25),f"{tick:.1f}",font=_font(21),fill="black",anchor="ma")
        draw.text(((left+right)/2,height-30),"Criticality moderation of post-miss distance (feet; 95% CI)",font=_font(24),fill="black",anchor="mm")

    _write_plot(figures / "figure_3_season_forest", width, height, "".join(svg), draw_png)


def _figure_continuous(mult: pd.DataFrame, figures: Path) -> None:
    main_h1 = _target(mult, "pooled_eight_season", "previous_personal_miss")
    continuous = _target(mult, "continuous_criticality", "post_miss_x_continuous_criticality")
    grid = np.linspace(0, 1, 101)
    data = pd.DataFrame(
        {
            "continuous_criticality": grid,
            "post_miss_distance_contrast_feet": main_h1["estimate"] + continuous["estimate"] * grid,
            "h1_source_model": "pooled_eight_season",
            "interaction_source_model": "continuous_criticality",
        }
    )
    write_figure_data(data, figures / "figure_4_continuous_criticality_data.csv")
    width, height = 1500, 850
    left, right, top, bottom = 200, 1370, 150, 700
    y_domain=(-1.6,0.15)
    sx=lambda value:left+value*(right-left)
    sy=lambda value:bottom-(value-y_domain[0])/(y_domain[1]-y_domain[0])*(bottom-top)
    points=" ".join(f"{sx(x):.1f},{sy(y):.1f}" for x,y in zip(data.iloc[:,0],data.iloc[:,1]))
    svg=[f'<text x="{width/2}" y="65" text-anchor="middle" font-family="Arial,sans-serif" font-size="38" font-weight="700">Post-miss caution attenuates as game criticality increases</text>']
    zero=sy(0); svg.append(f'<line x1="{left}" y1="{zero}" x2="{right}" y2="{zero}" stroke="{GRAY}" stroke-width="3" stroke-dasharray="10,8"/>')
    svg.append(f'<polyline points="{points}" fill="none" stroke="{GREEN}" stroke-width="7"/>')
    for tick in np.linspace(0,1,6): svg.append(f'<text x="{sx(tick)}" y="{bottom+40}" text-anchor="middle" font-family="Arial,sans-serif" font-size="22">{tick:.1f}</text>')
    for tick in np.arange(-1.5,.01,.3): svg.append(f'<text x="{left-25}" y="{sy(tick)+7}" text-anchor="end" font-family="Arial,sans-serif" font-size="22">{tick:.1f}</text>')
    svg.extend([
        f'<text x="{sx(0)+18}" y="{sy(data.iloc[0,1])-15}" font-family="Arial,sans-serif" font-size="24">{data.iloc[0,1]:+.2f} ft</text>',
        f'<text x="{sx(1)-18}" y="{sy(data.iloc[-1,1])-15}" text-anchor="end" font-family="Arial,sans-serif" font-size="24">{data.iloc[-1,1]:+.2f} ft</text>',
        f'<text x="{(left+right)/2}" y="{height-30}" text-anchor="middle" font-family="Arial,sans-serif" font-size="25">Continuous criticality index (0 = low, 1 = high)</text>',
        f'<text x="45" y="{(top+bottom)/2}" text-anchor="middle" transform="rotate(-90 45 {(top+bottom)/2})" font-family="Arial,sans-serif" font-size="25">Post-miss distance contrast (feet)</text>',
    ])

    def draw_png(draw: ImageDraw.ImageDraw) -> None:
        draw.text((width/2,55),"Post-miss caution attenuates as game criticality increases",font=_font(38,True),fill="black",anchor="mm")
        draw.text((left,110),"Post-miss distance contrast (feet)",font=_font(23),fill="black",anchor="la")
        draw.line((left,zero,right,zero),fill=GRAY,width=3)
        draw.line([(sx(x),sy(y)) for x,y in zip(data.iloc[:,0],data.iloc[:,1])],fill=GREEN,width=7,joint="curve")
        for tick in np.linspace(0,1,6): draw.text((sx(tick),bottom+25),f"{tick:.1f}",font=_font(22),fill="black",anchor="ma")
        for tick in np.arange(-1.5,.01,.3): draw.text((left-25,sy(tick)),f"{tick:.1f}",font=_font(22),fill="black",anchor="rm")
        draw.text((sx(0)+18,sy(data.iloc[0,1])-15),f"{data.iloc[0,1]:+.2f} ft",font=_font(24),fill="black",anchor="ls")
        draw.text((sx(1)-18,sy(data.iloc[-1,1])-15),f"{data.iloc[-1,1]:+.2f} ft",font=_font(24),fill="black",anchor="rs")
        draw.text(((left+right)/2,height-30),"Continuous criticality index (0 = low, 1 = high)",font=_font(25),fill="black",anchor="mm")

    _write_plot(figures / "figure_4_continuous_criticality", width, height, "".join(svg), draw_png)


def _all_coefficients(models: Sequence[dict[str, object]]) -> pd.DataFrame:
    rows = []
    for record in models:
        if "model" not in record:
            continue
        model = record["model"]
        for term, estimate in model["estimates"].items():
            ci = model["confidence_intervals"][term]
            rows.append(
                {
                    "model_id": record["model_id"],
                    "status": record["status"],
                    "outcome": record["outcome"],
                    "term": term,
                    "estimate": estimate,
                    "se_two_way": model["two_way_standard_errors"][term],
                    "ci_low": ci[0],
                    "ci_high": ci[1],
                    "p_normal": model["p_values_normal"][term],
                    "n_obs": model["n_obs"],
                    "sample_hash": model["sample_hash"],
                    "formula_hash": model["formula_hash"],
                }
            )
    return pd.DataFrame.from_records(rows)


def run_reporting(study_root: Path) -> None:
    results = study_root / "results"
    tables = study_root / "tables"
    figures = study_root / "figures"
    supplement = study_root / "supplement"
    for directory in (tables, figures, supplement):
        directory.mkdir(parents=True, exist_ok=True)

    confirmation = json.loads((results / "confirmation_primary.json").read_text(encoding="utf-8"))
    models = json.loads((results / "all_models.json").read_text(encoding="utf-8"))["models"]
    model_map = _model_map(models)
    mult = pd.read_csv(results / "multiplicity_adjusted.csv")
    meta = pd.read_csv(results / "meta_analysis.csv")
    audit = pd.read_csv(results / "data_audit.csv")
    registry = pd.read_csv(results / "model_registry.csv")

    quality_columns = [column for column in audit.columns if column not in {"anomaly_records"}]
    audit.loc[:, quality_columns].to_csv(tables / "table_1_data_quality.csv", index=False, lineterminator="\n")

    descriptive_rows = []
    for season in range(2016, 2024):
        record = model_map[f"season_specific_{season}"]
        model = record["model"]
        descriptive_rows.append(
            {
                "season": f"{season}-{str(season+1)[-2:]}",
                "analysis_role": "held-out confirmation" if season <= 2021 else "exploratory pilot",
                "analytic_shots": model["n_obs"],
                "games": model["cluster_counts"]["game_id"],
                "players": model["cluster_counts"]["player_id"],
                "h1_estimate_feet": model["estimates"]["previous_personal_miss"],
                "h2_estimate_feet": model["estimates"]["post_miss_x_critical"],
            }
        )
    pd.DataFrame.from_records(descriptive_rows).to_csv(tables / "table_2_descriptives.csv", index=False, lineterminator="\n")

    primary = build_primary_table(confirmation)
    pooled = model_map["pooled_eight_season"]["model"]
    for term, label in (("previous_personal_miss", "H1"), ("post_miss_x_critical", "H2")):
        primary.loc[len(primary)] = {
            "analysis": "Eight-season pooled sensitivity",
            "analysis_status": "secondary",
            "term": label,
            "coefficient": term,
            "estimate_feet": pooled["estimates"][term],
            "se_two_way_feet": pooled["two_way_standard_errors"][term],
            "ci_low_feet": pooled["confidence_intervals"][term][0],
            "ci_high_feet": pooled["confidence_intervals"][term][1],
            "p_normal": pooled["p_values_normal"][term],
            "p_display": format_p_value(pooled["p_values_normal"][term]),
            "direction_supported": pooled["estimates"][term] < 0 if term == "previous_personal_miss" else pooled["estimates"][term] > 0,
            "n_obs": pooled["n_obs"],
        }
    primary.to_csv(tables / "table_3_primary_models.csv", index=False, lineterminator="\n")

    robustness_ids = [
        "critical_2min_margin3", "critical_5min_margin3", "critical_5min_margin8",
        "continuous_criticality", "previous_shot_criticality", "stable_critical_status",
        "interval_le_120", "same_stint", "no_timeout", "no_pandemic",
        "include_offensive_rebounds", "exclude_putbacks_only", "period_end_2s",
        "period_end_5s", "margin_leading", "margin_tied", "margin_trailing",
        "q3_placebo", "team_lag", "three_point_secondary", "global_social_replication",
    ]
    robustness = mult.loc[mult["model_id"].isin(robustness_ids)].copy()
    robustness.to_csv(tables / "table_4_secondary_robustness.csv", index=False, lineterminator="\n")

    _figure_sample_flow(confirmation, figures)
    _figure_distance_components(confirmation, figures)
    _figure_forest(mult, meta, figures)
    _figure_continuous(mult, figures)

    coefficients = _all_coefficients(models)
    coefficients.to_csv(supplement / "all_coefficients.csv", index=False, lineterminator="\n")
    anomaly_counts = pd.read_csv(results / "data_anomalies.csv")["category"].value_counts().rename_axis("category").reset_index(name="n")
    anomaly_counts.to_csv(supplement / "anomaly_decisions.csv", index=False, lineterminator="\n")

    confirm_flows = []
    for flow in confirmation["sample_flow"]:
        for step in flow["steps"]:
            confirm_flows.append({"season": flow["season"], **step})
    flow_frame = pd.DataFrame.from_records(confirm_flows)
    flow_frame.to_csv(supplement / "confirmation_exclusion_flow.csv", index=False, lineterminator="\n")

    reml = meta.loc[meta["analysis"].eq("eight_season_h2_random_reml")].iloc[0]
    supplement_text = f"""# Supplementary results

## Analysis integrity

- Sealed held-out confirmation artifact: `results/confirmation_primary.json`.
- Expanded registry: {len(registry):,} unique model outputs; result status counts: {registry['result_status'].value_counts().to_dict()}.
- Fitted models: {len(models)-2:,}; all reported model diagnostics and coefficients are in `all_coefficients.csv`.
- Multiplicity-adjusted target tests: `results/multiplicity_adjusted.csv`.

## Data audit and anomaly handling

The blind field audit is reproduced in `tables/table_1_data_quality.csv`. Duplicate or unmatched keys were emitted as explicit anomalies before modeling. Category counts and the exclusion decision are in `anomaly_decisions.csv`; raw third-party event files are not redistributed.

## Confirmation sample flow

Every fixed-order exclusion for the six held-out seasons is in `confirmation_exclusion_flow.csv`. No model row was silently dropped after the explicit missing-previous-distance exclusion was added before the analysis freeze.

## Cross-season synthesis

The REML H2 estimate was {reml['pooled_effect']:.3f} ft (SE={reml['standard_error']:.3f}), tau-squared={reml['tau_squared']:.4f}, I-squared={reml['i_squared_percent']:.1f}%. Full random- and fixed-effect results plus leave-one-season meta-analyses are in `results/meta_analysis.csv`.

## Registered robustness and falsification tests

All registered target coefficients, raw p-values, Holm/FDR families, and adjusted p-values appear in `tables/table_4_secondary_robustness.csv` and `results/multiplicity_adjusted.csv`. The third-quarter matched-window placebo was registered before output generation. The social-context joint model directly tests teammate-minus-self coefficient differences; it does not infer a difference from separate significance tests.

## Reproduction pointers

The exact expanded registry is `results/model_registry.csv`; model/sample/formula hashes are in `all_coefficients.csv` and `results/all_models.json`. Figure source CSV files sit beside each PNG/SVG and are the exact frames passed to plotting functions.
"""
    (supplement / "supplementary_results.md").write_text(supplement_text, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study-root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    run_reporting(args.study_root.resolve())


if __name__ == "__main__":
    main()
