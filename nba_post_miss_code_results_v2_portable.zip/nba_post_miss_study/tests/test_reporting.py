from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd


STUDY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY_ROOT))

from src.reporting import (  # noqa: E402
    build_primary_table,
    continuous_post_miss_contrast_curve,
    format_p_value,
    write_figure_data,
)


class ReportingTests(unittest.TestCase):
    def test_primary_table_traces_exactly_to_sealed_result(self) -> None:
        payload = {
            "analysis_label": "held_out_confirmation",
            "pooled_model": {"n_obs": 1234},
            "hypotheses": {
                "h1": {"estimate": -1.2, "standard_error_two_way": 0.2, "confidence_interval": [-1.592, -0.808], "p_normal": 1e-8, "direction_supported": True},
                "h2": {"estimate": 0.5, "standard_error_two_way": 0.1, "confidence_interval": [0.304, 0.696], "p_normal": 2e-6, "direction_supported": True},
            },
        }
        table = build_primary_table(payload)
        self.assertEqual(table["analysis_status"].unique().tolist(), ["confirmatory"])
        self.assertEqual(table.loc[table.term.eq("H1"), "estimate_feet"].iloc[0], -1.2)
        self.assertEqual(table.loc[table.term.eq("H2"), "ci_high_feet"].iloc[0], 0.696)
        self.assertEqual(table["n_obs"].unique().tolist(), [1234])

    def test_p_values_are_never_rendered_as_zero(self) -> None:
        self.assertEqual(format_p_value(1e-12), "<.001")
        self.assertEqual(format_p_value(0.03456), ".035")
        self.assertEqual(format_p_value(0.8), ".800")

    def test_figure_data_written_equals_supplied_plot_input(self) -> None:
        frame = pd.DataFrame({"label": ["a", "b"], "estimate": [1.25, -0.5]})
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "figure_data.csv"
            write_figure_data(frame, path)
            observed = pd.read_csv(path)
        pd.testing.assert_frame_equal(observed, frame)

    def test_continuous_post_miss_curve_uses_one_models_covariance(self) -> None:
        model = {
            "predictors": [
                "previous_personal_miss",
                "post_miss_x_continuous_criticality",
            ],
            "estimates": {
                "previous_personal_miss": -1.0,
                "post_miss_x_continuous_criticality": 0.4,
            },
            "covariance": [[0.04, -0.01], [-0.01, 0.09]],
        }

        curve = continuous_post_miss_contrast_curve(model, grid=[0.0, 1.0])

        self.assertEqual(curve["source_model"].unique().tolist(), ["continuous_criticality_six_season"])
        self.assertAlmostEqual(curve.loc[0, "post_miss_distance_contrast_feet"], -1.0)
        self.assertAlmostEqual(curve.loc[1, "post_miss_distance_contrast_feet"], -0.6)
        expected_se = (0.04 + 2 * -0.01 + 0.09) ** 0.5
        self.assertAlmostEqual(curve.loc[1, "standard_error"], expected_se)
        self.assertAlmostEqual(curve.loc[1, "ci_low"], -0.6 - 1.96 * expected_se)
        self.assertAlmostEqual(curve.loc[1, "ci_high"], -0.6 + 1.96 * expected_se)


if __name__ == "__main__":
    unittest.main()
