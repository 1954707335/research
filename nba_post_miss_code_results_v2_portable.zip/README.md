# NBA post-miss study: portable reproduction package

This archive preserves the original freeze manifest and its required relative layout. Do not replace or regenerate `nba_post_miss_study/analysis_freeze.json`.

## Reproduce

1. Extract this archive and keep `SCI_research_design_post_miss_criticality_zh.md` beside the `nba_post_miss_study` folder.
2. Obtain the third-party raw files listed in `nba_post_miss_study/data_manifest.csv` and verify their recorded sizes and SHA-256 hashes.
3. From the extracted top-level directory, run:

   `python3 nba_post_miss_study/run_all.py --raw-dir /absolute/path/to/raw --version-dir /absolute/path/to/new-output`

The original raw NBA-derived files are not included. The preserved `nba_post_miss_study/reproduction_log.txt` records the completed local verification used for the manuscript.
